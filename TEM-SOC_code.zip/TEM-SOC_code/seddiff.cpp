/*!---------------------------------------------------------------------------------
! Purpose: this module governs the production of methane in the sediments, which
!          is from "Numerical modeling of methane emissions from lakes in the permafrost zone" 
!          [Stepanenko et al., 2011] and "Simulating the decadal to millennial scale dynamics 
!          of morphology and sequestered carbon mobilization of two thermokarst lakes in N.W. Alaska" 
!          [Kessler et al., 2012]. The depth-dependence function of N2 is from "Gas transport in a 
!          residual layer of a water basin" [Bazhi et al., 2001]
! 
!
!  added by llc, 09/03/2016
!---------------------------------------------------------------------------------*/

#if !defined(SEDIMENTTHERMAL_H)
  #include "sedimentthermal.hpp"
#endif

void SEDDIFF::sedmain(double Porosity, double damp,double pressure, double wdepth,double suborg,double cmnt,double rootz,double ph, double pcfldcap, double Re)
{
  double gamma = 1.51;
  double Prtot, Prnet, Hch4, Hn2;
  double tmp,depth;
  int ii;

  double x1 = 0.0; //from t1
  double x2 = 86400.0; //to t2
  double eps = 0.1; //accuracy
  double h1 = 300.0; //first time step
  double hmin = 60.0; //minimum time step
  //get production rate
  GetCH4ProductionRate(Pch4, suborg,cmnt,rootz,wm.Tsed,ph, pcfldcap);
  //calculate the ebullition rate of methane
  for(ii=0;ii<NSLAYER;ii++){
    depth = wdepth + wm.Zs[ii];
    /*
      if (m_lakeWaterTopIndex>NWLAYER+1) then
      Ebch4(ii,:) = 0.0_r8
      else if (m_sedIce(ii)>=Porosity) then
      Ebch4(ii,:) = 0.0_r8
     */
    Hch4 = wm.CalcHenrySolubility(wm.gas_ch4,wm.Tsed[ii]);
    Hn2 = wm.CalcHenrySolubility(wm.gas_n2,wm.Tsed[ii]);
    //Eq. (A.1) [Stepanenko et al., 2011]
    Prtot = wm.sedGasCon[ii][wm.sed_n2]/Hn2 + wm.sedGasCon[ii][wm.sed_ch4]/Hch4;
    Prnet = Prtot - wm.Ae * Porosity * (pressure + wm.Roul*wm.G*depth);
    Prnet = FMAX(Prnet, 0.0_r8);
    tmp = (wm.sedGasCon[ii][wm.sed_n2]/Hn2) / (Prtot + wm.inft);
    Ebch4[ii][wm.sed_n2] = Re * tmp * Prnet * Hn2;             // umol/(m3*s)
    Ebch4[ii][wm.sed_ch4] = Re * (1.0 - tmp) * Prnet * Hch4;   // umol/(m3*s)    
  }
  CalcTopMethaneFlux(wdepth);
  CalcSedMethaneDiffusivity(Porosity);
  //2D runge-kutta !
}

void SEDDIFF::preset()
{
  int ii,jj;
  Pch4[:][:] = 0.0;
  Ebch4[:][:] = 0.0;
  Dch4[:] = 0.0;
}

void SEDDIFF::derivs(double x, double con[][], double dcon[][])
{
  double qb[NSGAS],qt[NSGAS],a,b,dC1[NSGAS],dC2[NSGAS];
  int ii,jj, Top_Index, Bottom_Index;
  Top_Index = m_sedWaterTopIndex;
  Bottom_Index = m_sedWaterBtmIndex;
  if(Top_Index > Bottom_Index){
    dcon[:][:] = 0.0;
    return;
  }
  qt[:] = topflux[:];
  qb[:] = 0.0;
  for(ii=0;ii<NSLAYER;ii++){
    if(ii==0){
      a = 0.5*(Dch4[ii] + Dch4[ii+1]);
      dC1[:] = (con[ii+1][:] - con[ii][:]) / (wm.Zs[ii+1] - wm.Zs[ii]);
      dcon[ii][:] = (a*dC1[:] - qt[:]) / (wm.Zs[ii+1] - wm.Zs[ii]) + Pch4[ii][:] - Ebch4[ii][:];
    } 
    else if(ii==NSLAYER-1){
      b = 0.5*(Dch4[ii-1] + Dch4[ii]);
      dC2[:] = (con[ii][:] - con[ii-1][:]) / (wm.Zs[ii] - wm.Zs[ii-1]);
      dcon[ii][:] = (qb[:] - b*dC2[:]) / (wm.Zs[ii] - wm.Zs[ii-1]) + Pch4[ii][:] - Ebch4[ii][:];
    }
    else{
      a = 0.5*(Dch4[ii] + Dch4[ii+1]);
      b = 0.5*(Dch4[ii-1] + Dch4[ii]);
      dC1[:] = (con[ii+1][:] - con[ii][:]) / (wm.Zs[ii+1] - wm.Zs[ii]);
      dC2[:] = (con[ii][:] - con[ii-1][:]) / (wm.Zs[ii] - wm.Zs[ii-1]);
      dcon[ii][:] = (a*dC1[:] - b*dC2[:]) / (0.5*(wm.Zs[ii+1]-wm.Zs[ii-1])) + Pch4[ii][:] - Ebch4[ii][:];
    }
    for(jj=0;jj<NSGAS;jj++){
      if(con[ii][jj]<=0 && dcon[ii][jj]<0) dcon[ii][jj] = 0.0;
    }
  }
          
}
/*
   !------------------------------------------------------------------------------
   !
   ! Purpose: Adjust negative sediment gas concentration (project negative values 
   !          to zero) - "Non-negative solutions of ODEs" (Shampine, L., 2005).
   !
   !-----------------------------------------------------------------------------
 */

void SEDIFF::AdjustNegativeConcentration()
{
  int ii=0;
  int jj=0;
  for(ii=0;ii<NSLAYER;ii++){
    for(jj=0;jj<NSGAS;jj++){
      if(wm.sedGasCon[ii][jj] < 0) wm.sedGasCon[ii][jj] = 0.0;
    }
  }
}

/*
   !------------------------------------------------------------------------------
   !
   ! Purpose: Calculate methane diffusivity in sediments
   !
   !-----------------------------------------------------------------------------
 */

void SEDIFF::CalcSedMethaneDiffusivity(double Porosity)
{
  //  double diffst; //for ice
  int ii;
  for(ii=1;ii<NSLAYER;ii++){
    /* for ice!!
      if (m_sedIce(ii)>=Porosity) then
      diffst = CalcGasDiffusivityInIce(gas_ch4, m_sedTemp(ii))
      Dch4(ii) = diffst*0.66*Porosity 
      else
    */
    Dch4[ii] = 2.0e-9 * 0.66 * Porosity; //[Eq. (8) in Walter 2000]
  }
}

/*
   !------------------------------------------------------------------------------
   !
   ! Purpose: calculate production when there is standing water
   !
   !-----------------------------------------------------------------------------
 */

void SEDIFF::GetCH4ProductionRate(double Pch4[][], double suborg,double cmnt,double rootz,double Tsed[],double ph,double pcfldcap)
{
  int ii;
  for(ii=0;ii<NSLAYER;ii++){
    if ( suborg <= 0.0)  suborg = 0.01;
    ch4dmpro.fsomt = ch4dmpro.EffectOM(ch4dmpro.maxfresh[cmnt], suborg);
    ch4dmpro.fcdist = ch4dmpro.EffectOMD(cmnt, wm.Zs[ii]*100.0, rootz, ch4dmpro.lowb[cmnt]);
    ch4dmpro.fmstt = ch4dmpro.EffectST( Tsed[ii],ch4dmpro.pmethaneq[cmnt], ch4dmpro.proref[cmnt], cmnt);
    ch4dmpro.fpht =  ch4dmpro.EffectPH(ph);	
    ch4dmpro.ehlt = ch4dmpro.RedoxP(0.0, wm.Zs[ii]*100.0, pcfldcap, cmnt, ch4dmpro.lowb[cmnt]);
    ch4dmpro.frxt = ch4dmpro.EffectRX(ch4dmpro.ehlt);
    ch4dmpro.ch4rate[i] = ch4dmpro.MethanePR( ch4dmpro.mgo[cmnt], ch4dmpro.fsomt, ch4dmpro.fcdist,
					      ch4dmpro.fmstt,ch4dmpro.fpht,ch4dmpro.frxt); // uM h-1
    Pch4[ii][wm.sed_ch4]=ch4dmpro.ch4rate[i] * 1000.0 / 3600.0;  //uM hr-1 >> umol/m3/s
    Pch4[ii][wm.sed_n2]=0.0;//no N2 production
  }
}
/*
     !------------------------------------------------------------------------------
   !
   ! Purpose: Generate methane bubble flux from ebullition pool. The bubbles are 
   !          observed around 0.1~0.4 mm in upper sediments ("Hydroacoustic analysis 
   !          of spatial and temporal variability of bottom sediment characteristics 
   !          in Lake Kinneret in relation to water level fluctuation", Ilia Ostrovsky).
   !
   !------------------------------------------------------------------------------
 */
void SEDIFF::CalcSedimentBubbleFlux()
{
  int ii;
  sedflux[:]=0.0;
  
  //  if(wm.lakeWaterTopIndex >= NWLAYER) return;
  for(ii=0;ii<NSLAYER;ii++){
    sedbflux[:]=sedbflux[:]+0.5*(Ebch4[ii][:]+Ebch4[ii+1][:])*(wm.Zs[ii+1]-wm.Zs[ii]);
  }
}

void SEDIFF::CalcSedimentDfflux()
{
  seddflux[:]=topflux[:];
}

/*
   !------------------------------------------------------------------------------
   !
   ! Purpose: Calculate the top boundary methane flux
   !
   !------------------------------------------------------------------------------
 */

void SEDIFF::CalcTopMethaneFlux(double stw)
{
  double concw[NSGAS], concs[NSGAS];
  double Kch4w;
  concw[wm.sed_n2] = waterGasCon[NWLAYER-1][wm.gas_n2];
  concw[wm.sed_ch4] = waterGasCon[NWLAYER-1][wm.gas_ch4];
  concs[wm.sed_n2] = sedGasCon[0][wm.sed_n2];
  concs[wm.sed_ch4] = sedGasCon[0][wm.sed_ch4];
  if(stw >= 10.0){
    Kch4w = 0.65 * 3.8218e-6 + wm.tmpKw[NWLAYER-1];
  }
  else{
    Kch4w = wm.tmpKw[NWLAYER-1];
  }

  // if(wm.lakeWaterTopIndex >= NWLAYER) topflux = 0;
  topflux[:] = Kch4w * (consc[:]-concw[:])/0.1;
}

