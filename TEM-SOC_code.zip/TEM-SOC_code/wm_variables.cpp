/*
All constant and public variables for wetland methane modules

Added by llc 10/18/2016
*/
#if !defined(WM_VARIABLES_H)
#include "wm_variables.hpp"
#endif

void WCH4_V::Initialize(double Porosity)
{

  int ii;
  int jj;
  double pressure,temp;
  for(ii=0;ii<NSLAYER;i++) {
    Tsed[ii] = 25.0+273.15 - 4.0 - 4.0/float(NSLAYER)*ii;
    Twater[ii] = 25.0+273.15 - 4.0/float(NWLAYER)*ii;
  }
  sedGasCon[:][sed_n2]=0.0;
  pressure = P0*GetGasPercentage(gas_ch4);
  for(ii=0;ii<NSLAYER;ii++){
    temp = Tsed[ii];
    sedGasCon[ii][sed_ch4]=CalcEqConc(gas_ch4,temp,pressure)*Porosity;
  }
  for(jj=gas_n2;jj<=gas_nch4;jj++){
    pressure = P0*GetGasPercentage(gas);
    for(ii=0;ii<NWLAYER;ii++){
      temp = Twater[ii];
      waterGasCon[ii][gas]=CalcEQConc(gas,temp,pressure);
    }
    gasExchange[:][:]=0.0;
  }
  Zw[:]=0.0;
  Zs[:]=0.0;
  Az[:]=0.0;
  tmpKw[:]=0.0;
  lakeWaterTopIndex=0;
}

double WCH4_V::CalcSatVP(double T)
{
     double Tc;
     Tc = T - T0;
     if(Tc > 100) {Tc = 100;}
     else if(Tc < -35) {Tc = -35;}
     return 6.112*exp(17.67*Tc/(Tc+243.5));
}

double WCH4_V::CalcSpecificHumidity(double T)
{
     double vp;
     double epsilon=0.622;
     double P0_mb=0.01*P0;
     vp = CalcSatVP(T);
     return epsilon*vp/(P0_mb-(1-epsilon)*vp);
}

double WCH4_V::CalcThermalRadiation(double Ta, double vp, double cloud)
{
     double factor;
     if(cloud<=0.6){factor=0.84-(0.1-9.973e-7*vp)*(1.0-cloud)+3.491e-6*vp;}
     else {factor = 0.87-(0.175-29.92e-7*vp)*(1.0-cloud)+2.693e-6*vp;}
     return factor*Stefan*pow(Ta,4.0);
}

double WCH4_V::CalcLatentHeat(double vp, double Tw, double wind)
{
     double qs, q;
     qs = CalcSpecificHumidity(Tw);
     q = 0.622*vp/(P0*0.01-(1-0.622)*vp);
     return Roua*Lv*Ce*wind*(q-qs);

}

double WCH4_V::CalcSensibleHeat(double Ta, double Tw, double wind)
{
     return Roua*Cpa*Ch*wind*(Ta-Tw);
}

void WCH4_V::CalcEddyDiffusivity(double temp[], double depth[],double wind, double lat,double k_eddy[],double density[],double frequency[])
{
     double vv, ekman, w2,tmp, tmp1, richardson;
     int ii;
     if(wind < 0.1){
       for(ii=0;ii<NWLAYER;ii++) k_eddy[ii] = 0.0;
       return;
     }
     vv = 1.2e-3*wind; //surface friction velocity
     ekman = 6.6*sqrt(sin(fabs(lat)))*pow(wind,-1.84); //a latitudinally dependent parameter
     calcdensity(temp,density);
     calcbvfreq(density,depth,frequency);
     for(ii=0;ii<NWLAYER;ii++){
       tmp = exp(-ekman*depth[ii]) + inft;
       tmp1 = pow(vv,2.0)*pow(tmp,2.0) + inft;
       richardson = 0.05*(-1.0+sqrt(1.0+40.0*frequency[ii]*pow(Karman,2.0)*pow(depth[ii],2.0)/tmp1));
       k_eddy[ii] = (Karman*vv*depth[ii]/prandtl) * tmp / (1.0+37.0*pow(richardson,2.0));
//       printf("Detest, %f,%f,%f,%f,%f,\n",density[ii],frequency[ii],depth[ii],tmp,richardson);//llc test
     }    
}

void WCH4_V::CalcWaterDensity(double temp[],double density[])
{
     int ii;
     for(ii=0;ii<NWLAYER;ii++){
         density[ii] = (1-1.9549e-5*pow(fabs(temp[ii]-T0-4.0),1.68))*Roul;
    //     printf("density, %f,%f,%f,%f,\n",density[ii],temp[ii],T0,Roul);
     }
}

void WCH4_V::CalcBruntVaisalaFreq(double density[],double depth[],double frequency[]) //need to be careful if there is true data
{
     int ii;
     double deltaH;
     for(ii=0;ii<NWLAYER;ii++){
       if(ii == 0){
         deltaH = depth[1] - depth[0];
         frequency[ii] = 2.0*9.8*(density[1]-density[0])/deltaH/(density[1]+density[0]);
       }
       else if(ii == NWLAYER-1){
         deltaH = depth[NWLAYER-1] - depth[NWLAYER-2];
         frequency[ii] = 2.0*9.8*(density[NWLAYER-1]-density[NWLAYER-2])/deltaH/(density[NWLAYER-1]+density[NWLAYER-2]);
       }
       else{
         deltaH = depth[ii+1] - depth[ii-1];
         frequency[ii] = 3.0*9.8*(density[ii+1]-density[ii-1])/deltaH/(density[ii+1]+density[ii]+density[ii-1]);
       }
       frequency[ii] = FMAX(7.0e-5, frequency[ii]);
    //     printf("frequency, %f,\n",deltaH);
     }
     
}

//---------------------------------------------------------------------------
// x - array of size 3
// In case 3 real roots: => x[0], x[1], x[2], return 3
//         2 real roots: x[0], x[1],          return 2
//         1 real root : x[0], x[1] ± i*x[2], return 1
// solve cubic equation x^3 + a*x^2 + b*x + c
int WCH4_V::SolveCubicEquation(double x[], double a, double b, double c)
{
  double a2 = a*a;
  double q  = (a2 - 3.0*b)/9.0; 
  double r  = (a*(2.0*a2-9.0*b) + 27.0*c)/54.0;
  double r2 = r*r;
  double q3 = q*q*q;
  double A,B;
  if(r2<q3) {
    double t=r/sqrt(q3);
    if( t<-1.0) t=-1.0;
    if( t> 1.0) t= 1.0;
    t=acos(t);
    a/=3.0; q=-2.0*sqrt(q);
    x[0]=q*cos(t/3.0)-a;
    x[1]=q*cos((t+2.0*Pi)/3.0)-a;
    x[2]=q*cos((t-2.0*Pi)/3.0)-a;
    return(3);
  } else {
    A =-pow(fabs(r)+sqrt(r2-q3),1./3); 
    if( r<0 ) A=-A;
    B = A==0? 0 : B=q/A;
    a/=3;
    x[0] =(A+B)-a;
    x[1] =-0.5*(A+B)-a;
    x[2] = 0.5*sqrt(3.)*(A-B);
    if(fabs(x[2])<eps) { x[2]=x[1]; return(2); }
    return(1);
  }
}

double WCH4_V::CalcHenrySolubility(int gas, double temp)
{
  double  hi, kc1, kc2, par;
  int indx;
  double output;
  if(gas == gas_n2){
    output = 6.1e-6.0 * exp(-1300.0*(1.0/temp-1.0/298.0));
  }
  else if(gas == gas_o2){
    if (temp>=T0 && temp <= T0 + 50.0){
      indx = int((temp-T0)/5) + 1;
      indx = min(indx, 10);
      par = (temp - T0 - 5.0*indx + 5.0) / 5.0;
      output = (SOLO2[indx+1]*par + SOLO2[indx]*(1-par)) / MasO2 / P0 / Xo2;
    }
    else{
      output = 1.3e-5.0 * exp(-1500.0*(1.0/temp-1.0/298.0));
    }
  }
  else if(gas == gas_co2){
    output = 3.4e-4.0 * exp(-2400.0*(1.0/temp-1.0/298.0));
    hi = pow(10.0,-5.6);       // Concentration of hydrogen ion (Assuming fresh water pH is 5.6)
    kc1 = 4.3e-7.0 * exp(-921.4*(1.0/temp-1.0/298.0));       // rate constant of dissolved CO2 for first dissolution
    kc2 = 4.7e-11.0 * exp(-1787.4*(1.0/temp-1.0/298.0));     // rate constant of dissolved CO2 for second dissolution
    output = output * (1.0+kc1/hi+pow(kc1*kc2/hi,2.0));
  }
  else if(gas==gas_ch4){
    output = 1.3e-5.0 * exp(-1700.0*(1.0/temp-1.0/298.0));
  }
  output = 1.0e6.0 * output;
  return output;
}

double WCH4_V::mean1d(double var[], int begin, int end)
{
  int ii;
  double output=0.0;
  for(ii=begin;ii<=end;ii++){
    output = output + var[ii];
  }
  return output / double(end-begin+1);
}

double WCH4_V::GetGasPercentage(int gas)
{
  if(gas==wm.gas_n2){return wm.Xn2;}
  else if(gas==wm.gas_o2){return wm.Xo2;}
  else if(gas==wm.gas_co2){return wm.Xco2;}
  else if(gas==wm.gas_ch4){return wm.Xch4;}
}

double WCH4_V::CalcEQConc(int gas, double temp, double pressure)
{
  return CalcHenrySolubility(gas,temp)*pressure;
}
/*
   !------------------------------------------------------------------------------
   !
   ! Purpose: Calculate piston velocity from "Bubbles and the air-sea 
   !          exchange of gases in near-saturation conditions" [Woolf et al., 1991].
   !          "Seasonal dynamics of carbon dioxide and methane in two clear-water lakes and two 
   !          bog lakes in northern Wisconsin, U.S.A." [Riera et al., 1999]
   !
   !------------------------------------------------------------------------------
 */
double WCH4_V::CalcPistonVelocity(int gas, double temp, double wind)
{
  double unit = 2.778e-6;
  double Schmidt;
  Schmidt = CalcSchmidtNumber(gas,temp);
  return (2.07+0.215*pow(wind,1.7))*pow(600.0/Schmidt,0.5)*unit;
}
/*
   !------------------------------------------------------------------------------
   !
   ! Purpose: Calculate Schmidt number for N2, O2, CO2 and CH4
   !          Reference: "Relationship between wind-speed and gas-exchange over the 
   !           ocean", R. Wanninkhof, 1992 (N2 and O2) and "Measurement of the diffusion
   !           coefficients of sparingly soluble gases in water", B. Jahne, et al., 1987
   !           (CO2 and CH4).
   !
   !------------------------------------------------------------------------------
 */
double WCH4_V::CalcSchmidtNumber(int gas, double temp)
{
  double T;
  T=temp - T0;
  if(T<0){
    return inf;
  }
  else if(T>30){
    T =30;
  }
  if(gas==wm.gas_n2){return 1970.7-131.45*T+4.139*pow(T,2)-0.052106*pow(T,3);}
  else if(gas==wm.gas_o2){return 1800.6-120.1*T+3.7818*pow(T,2)-0.047608*pow(T,3);}
  else if(gas==wm.gas_co2){return 1911-113.7*T+2.967*pow(T,2)-0.02943*pow(T,3);}
  else if(gas==wm.gas_ch4){return 1898-110.1*T+2.834*pow(T,2)-0.02791*pow(T,3);}
}
