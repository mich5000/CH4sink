/*********************************************************
**********************************************************
waterthermal.hpp
Object describing thermal transport in water, specifically
for wetlands, rivers and lakes. Similar to method of Zeli Tan
2015 JAMES paper. 
Added by L. Liu, June 27 2016

**********************************************************
*********************************************************/
#if !defined(CKRUNGEKUTTA_H)
  #include "ckrungekutta.cpp" //ck runge kutta calculation
#endif

#if !defined(WATERTHERMAL_H)
#define WATERTHERMAL_H
#endif

#if !defined(WM_VARIABLES_H)
  #include "wm_variables.cpp" // variables input
#endif


class WATERTHERMAL : public CKRUNGEKUTTA {

	public:

        WCH4_V wm;
        
        void Wthermalmain(double wdepth,double I0, double wind, double lat, double Ta, double Ts, double prec, double vaporp, double cloud);  
        
        double sed_topflux;

        void testHeatEquation(double x, double temp[], double dtemp[]);
        virtual void derivs(double x, double temp[], double dtemp[]);
        void preset(double wdepth);
        void CalcHeatConductivity(double T[],double Dm[])
        void CalcIncidentSolarRadiation(double I0, double I[],double wdepth);
        void CalcKh(double temp[],double depth[],double wind, double lat,double Kh[]);
        void CalcTopBottomHeatFlux(double Twater[], double Ta, double Ts,double vaporp, double wind, double cloud,double prec);

        double Ia[NWLAYER]; //Absorbed solar energy
        double m_Az[NWLAYER]; //area of lake cross section
        double Cvt[NWLAYER]; //volumetric heat capacity (J/K/m3)
        double Kh[NWLAYER]; //total heat diffusivity (m2/s)
        double btmflux; //bottom boundary heat flux
        double topflux; //top boundary heat flux    


};



