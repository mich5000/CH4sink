
/*********************************************************
**********************************************************
Methane dynamics -- Q. Zhuang, 19/Feb/2003

**********************************************************
*********************************************************/
class CH4DMPRO {

	public:

/******************************************************
			public Functions
******************************************************/
    void    getecdch4pro(ofstream& rflog1);
    void    getch4pro(char ecd[80]);
    void    getch4pro(ofstream& rflog1);
    void    getecdch4pro(char ecd[80]);

  // added for isotope youmi
    void    getecdch4iso(ofstream& rflog1);
    void    getch4iso(char ecd[80]);
    void    getch4iso(ofstream& rflog1);
    void    getecdch4iso(char ecd[80]);

 //   double MethanePR(const double& mgo, const double& fsom, const double& fcdis, const double& fmst,
 //             const double& fph, const double& frx);
    double  MethanePR(const double& mgo,  double fsom,  double fcdis,  double fmst,
               double fph,  double frx);

//    double EffectOM(const double& maxfresh, const double& vegNPP, const double& kc, const double& residsub);
    double EffectOM(const double& maxfresh, const double& vegNPP);

    double EffectOMD(const double& vegtype, const double& depthz, const double& rootd, const double& lowb);
//    double EffectST(double soilt, const double& pch4q10, const double& proref);
    double EffectST( double soilt, double pch4q10,  double proref, const int& vegtype);

    double EffectPH(const double& soilph);
    double EffectRX(const double& ehl);
    double RedoxP(const double& watertalbe, const double& depthz, const double& wfpsl, const int& vegtype,
              const double& lowb);
    double InterpolatST(const double& dst1, const double& dst2,const double& dst3,
                const double& dst4, const double& dst5, const double& dst6,  double x);


/**************************************************************
			Public Variables
**************************************************************/
   double pmethaneq[35];
   double mgo[35], kc[35], oxi_c[35], maxfresh[35], lowb[35];
   double proref[35];
   double prod;
   double pro_para[35][10];//llc for save paras


   double iso_para[35][9]; //added for isotope youmi 
   double alpha_am[35],alpha_hm[35],alpha_mo[35];
   double alpha_tp[35],alpha_te[35],alpha_td[35];

//   double surrunoff[CYCLE][31]; // run off from surface (mm)
//   double qtran; // transpiration water flux (mm h2o/s)
//   double surinfl[CYCLE][31]; // infiltration rate (mm h2o/s)
//   double qseva; // ground surface evaporation rate (mm h2o/s)
//   double bdrai[CYCLE][31]; // assume the drainage is 0.0 at the beginning (mm h2o/s)
//   double unsatthetaWL[10]; // to store the water content for layers of wetland (every 10 mm)

  double suborg[CYCLE][31];
  double tsuborg[3][MAXRTIME][CYCLE][31];
  double annpp;
  double tannpp[MAXRTIME];

  double fsomt;
  double fcdist;
  double fmstt;
  double fpht;
  double frxt;
  double ehlt;
  double ch4rate[400];  // nodes to store CH4
  double intersoilt[400]; // deposit interpolated soil temperatures
};
