
/*********************************************************
**********************************************************
Methane dynamics -- Q. Zhuang, 19/Feb/2003

**********************************************************
*********************************************************/
class CH4DMDIF {

	public:

/******************************************************
			public Functions
******************************************************/
    void    getecdch4dif(ofstream& rflog1);
    void    getch4dif(char ecd[80]);

    void    getch4dif(ofstream& rflog1);

    void    getecdch4dif(char ecd[80]);
    void    premethane();


    double  Diffusivity(const double& sand, const double& silt, const double& clay,  int satyorn);
	void EffdfSM(const double sm[], const double smsat[], const int& nodes);
//    double  CH4flxandCon(const double& ddf, const double& pr, const double& cr, const double& lowb );

    double  CH4flxandCon(const double& ddf, const double& lowb );

    double  ACH4flxandCon(const double& ddf, const double& lowb );

    double  FCH4flxandCon(const double& lowb,const double& watertable, const double& soilt, const double& dt);  //llc for final diffusion


/**************************************************************
			Public Variables
**************************************************************/
//llc for wetland change from 200 to 400
  double ch4con[400]; // CH4 concetration for diffusion   uM
  double ch4con_b[400]; // CH4 concetration for diffusion
  double ch4sc[CYCLE][31]; // mean soil methane concentration from surface to root bottom uM
  double pre_stw; //previous standing water level cm

  double fdf;
  int sat;

  double fdfs[400];
  double sm2dif[400];	//soil moisture effect on diffusitivity
  double ch4flx;
  double ch4ratesat[400];  // for deposit saturation zone ch4 concentration
  double ch4oxirate1[400];
  double ch4oxir[400];//llc add them for diffusion calculation
  double ch4pror[400];
  double ch4ebur[400];
  double ch4disl[400]; //llc dissolve ebbuliation 
  double ch4ebur_p; //llc ebbulitive potential
  double ch4patr[400];
  double ch4poxir[400];
//  double totalflx[CYCLE][31]; // eflux of methane via three transport mechanisms
  double ch4cons[CYCLE][31]; // eflux of methane via three transport mechanisms
  double ch4emis[CYCLE][31]; // eflux of methane via three transport mechanisms
  double ch4tot[CYCLE][31];
  double aoch4;		//atmospheric concentration of ch4, uM / cm^3

// added for isotope model youmi oh
  double d13init[CYCLE][31];
  double d13prod[CYCLE][31];
  double d13oxid[CYCLE][31];
  double d13final[CYCLE][31];
  double mompfrac[CYCLE][31];
  double tpfrac[CYCLE][31];
  double tefrac[CYCLE][31];
  double tdfrac[CYCLE][31];
  double mompfracplt[CYCLE][31];
  double d13oxidplt[CYCLE][31];

};
