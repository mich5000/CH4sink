/* **************************************************************
*****************************************************************
HATMS423.HPP - uses the physical characteristics of the atmosphere
	       as described by TEM, but uses transient CO2, specified
	       every 6 months, from an ASCII file

               20000102 - DWK added compiler directives
*****************************************************************
************************************************************** */

#if !defined(DAATMS423_H)
  #include "daatms423.cpp"    // MPIatms inherits Atmosphere class
#endif

#if !defined(DATCO2DAT423_H)
  #include "datco2dat423.cpp" // MPIatms uses CO2data class
#endif

#if !defined(DATCH4DAT423_H)
  #include "datch4dat423.cpp" // MPIatms uses CH4data class
#endif

// MPIatms also uses the global constants CYCLE and MAXRTIME

#if !defined(DAHATMS423_H)
#define DAHATMS423_H

class MPIatms : public Atmosphere {

  public:

     MPIatms();

/* **************************************************************
		 Public Functions
************************************************************** */

     void loadfosfuel(ofstream& rflog1, const int& RTIME);
     void loadmpitCO2(ofstream& rflog1, const int& totsptime, const int& RTIME);
     void loadmpitCO2(char ifilename[80], const int& totsptime, const int& RTIME);
     void loadmpitCH4(ofstream& rflog1, const int& totsptime, const int& RTIME);
     void loadmpitCH4(char ifilename[80], const int& totsptime, const int& RTIME);


/* **************************************************************
		 Public Variables
************************************************************** */

     double ffuel[MAXRTIME];
     double maxffuel;
     int ffuelyear[MAXRTIME];

};

#endif
