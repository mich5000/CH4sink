/* **************************************************************
finudation.HPP - object to read and write the structure of cultivation intensity
               data from/to files used by the methane
************************************************************** */

#if !defined(FCULT_H)
#define FCULT_H

class Cultdata {

  public:

     Cultdata(void);

/* **************************************************************
                      Public Functions
************************************************************** */

// read data structure.
     int get(ifstream& infile);
     int getdel(FILE* infile);
//write data structure.
     void out(ofstream& ofile, float col, float row, char varname[9], int carea, double icult, char contnent[9]);
     void outdel(ofstream& ofile, float col, float row, char varname[9], int carea, double icult, char contnent[9]);


/* **************************************************************
                     Public Variables
************************************************************** */

     float col;          // column or longitude of grid cell (degrees)
     float row;          // row or latitude of grid cell (degrees)
     char varname[9];    // "ELEV"
     int carea;          // area covered by grid cell (sq. km)
     double icult;        // cultivation of grid cell (m)
     char contnent[9];   // name of continent containing grid cell


  private:

/* **************************************************************
                      Private Variables
************************************************************** */

     int elvend;
     long curpos;
     long lagpos;

};

#endif

