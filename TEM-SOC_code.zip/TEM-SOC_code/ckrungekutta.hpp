/*********************************************************
**********************************************************
ckrungekutta.hpp
Using Cash-Karp parameters for embedded Runge-Kutta Method
to solve ODE and PDE.
Numerical Recipes in C, The Art of Scientific Computing,
Second Edition.
Added by L. Liu, July 1 2016

**********************************************************
*********************************************************/
//from nrutil.hpp
#define FMAX(a,b) ((a) > (b) ? (a) : (b))
#define FMIN(a,b) ((a) < (b) ? (a) : (b))
#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))


#define SAFETY 0.9
#define PGROW -0.2
#define PSHRNK -0.25
#define ERRCON 1.89e-4  //The value ERRCON equals (5/SAFETY) raised to the power (1/PGROW), see use below.
#define MAXSTP 10000
#define TINY 1.0e-30

#if !defined(CKRUNGEKUTTA_H)
#define CKRUNGEKUTTA_H
#endif


class CKRUNGEKUTTA {

	public:
        void rkqs(double y[], double dydx[], int n, double *x, double htry, double eps,
            double yscal[], double *hdid, double *hnext);

        void rkck(double y[], double dydx[], int n, double x, double h,
            double yout[], double yerr[]);

        void odeint(double ystart[], int nvar, double x1, double x2, double eps, double h1,
            double hmin);

        virtual void derivs(double x, double temp[], double dtemp[]) = 0;

};
