
/*********************************************************
**********************************************************
Methane dynamics -- Q. Zhuang, 19/Feb/2003

**********************************************************
*********************************************************/
class CH4DMEBU {

	public:

/******************************************************
			public Functions
******************************************************/
    void    getecdch4ebu(ofstream& rflog1);
    void    getch4ebu(char ecd[80]);
    void    getch4ebu(ofstream& rflog1);
    void    getecdch4ebu(char ecd[80]);

    double threshold(void);
    double CH4ebuR(const double& ch4con, const double& ch4thresh );


/**************************************************************
			Public Variables
**************************************************************/
  double ch4ebuflx[200];
  double ch4thresh;
  double ebuflx[CYCLE][31];
};
