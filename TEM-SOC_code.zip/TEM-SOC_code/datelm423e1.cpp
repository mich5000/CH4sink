/* **************************************************************
*****************************************************************
TELM423.CPP - Runs TEM for a single grid cell

20010418 - Q. Z. Soil thermal model
20020202 Kick added the following in the temwritepred ()
         //strcmp(predname[k],tem.predstr[tem.I_FPC]) == 0
Modified the input and output in terms of time step (daily),  Q. zhuang, 30/Dec/2002
2003/Jan/04 Q Zhuang added hydrological model

*****************************************************************
************************************************************** */


#if !defined(DATELM423E1_H)
  #include "datelm423e1.hpp"
#endif

/* ************************************************************ */


TEMelmnt::TEMelmnt()
{

  col = MISSING;
  row = MISSING;
  carea = -999;
  lowtair = 0;
  noprec = 0;

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************** */

int TEMelmnt::atmsgisin(FILE* fclds, const int& cldflag,
                        FILE* flonlat, const int& lonlatflag,
                        const int& numspin, const int& spintime,
                        const int& RTIME)
{

  int i,j;
  int gisend;
  Clmdata clds;
  Latdata lonlat;

  int days;

  if (clm.tcldsflag == 1)
  {
    gisend = loadteclds(fclds, clds, numspin, spintime, RTIME);
    if (gisend == -1) { return gisend; }
  }
  else
  {
    gisend = clds.getdel(fclds);

    if (gisend == -1)
    {
      col = MISSING;
      row = MISSING;
      return gisend;
    }
    col = clds.col;
    row = clds.row;
    carea = clds.carea;
    for (i = 0; i < CYCLE; i++)
    {
//     const int year = 1992;  // deal with 29 days

     days = daysnumber(i, clds.year);
     for (j =0; j < days; j++)
       {
        if (cldflag == 1) {
             clm.clds[i][j] = clds.mon[i];
        //     clm.clds[i][j] = clds.dat[i][j];
          }
        else {
           clm.nirr[i][j] = clds.mon[i]; }
      //   clm.nirr[i][j] = clds.dat[i][j]; }
       }  // end of days
      }
    strcpy(contnent,clds.contnent);
  }

  if (lonlatflag == 1) { lat = (double) row; }
  else
  {
    gisend = lonlat.getdel(flonlat);
    if (gisend != -1) { lat = lonlat.lat; }
    else
    {
      col = MISSING;
      row = MISSING;
      return gisend;
    }
  }

  return gisend;

};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************** */

void TEMelmnt::atmswritemiss(ofstream fout[NUMATMS], char predname[MAXPRED][9],
                             const int& dyr, const int& natmspred,
                             const double value)
{

  int i;
  int dm;

  int m, days;

  Clmdata atmspred;

  for (i = 0; i < natmspred; i++)
  {
    for (dm = 0; dm < CYCLE; dm++)
    {
      days = daysnumber(dm, ttotyr[dyr][itype]);

      for (m=0; m < days; m++)

      atmspred.dat[dm][m] = value;
    }

	 atmspred.outdel(fout[i], col, row, predname[i], carea, atmstotyr[dyr],
                    atmspred.dat, contnent);
  }

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************** */

void TEMelmnt::atmswritepred(ofstream fout[NUMATMS], char predname[MAXPRED][9],
                             const int& dyr, const int& natmspred)
{

  int i;
  int dm;
  int m,days;

  Clmdata atmspred;

  for (i = 0; i < natmspred; i++)
  {
    if (strcmp(predname[i],clm.predstr[clm.I_PAR]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++) {
       days = daysnumber(dm,ttotyr[dyr][itype]);

       for (m=0; m < days; m++)
       atmspred.dat[dm][m] = clm.par[dm][m]; }
    }
    else if (strcmp(predname[i],clm.predstr[clm.I_NIRR]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++) {
      days = daysnumber(dm,ttotyr[dyr][itype]);
      for (m=0; m < days; m++)
      atmspred.dat[dm][m] = clm.nirr[dm][m]; }
   }
    else if (strcmp(predname[i],clm.predstr[clm.I_GIRR]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++) {
      days = daysnumber(dm,ttotyr[dyr][itype]);
      for (m=0; m < days; m++)
      atmspred.dat[dm][m] = clm.girr[dm][m]; }
    }
    else if (strcmp(predname[i],clm.predstr[clm.I_CLDS]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++) {
      days = daysnumber(dm,ttotyr[dyr][itype]);
      for (m=0; m < days; m++)
      {
      atmspred.dat[dm][m] = clm.clds[dm][m];
       }
      }
    }

	 atmspred.outdel(fout[i], col, row, predname[i], carea, atmstotyr[dyr],
                    atmspred.dat, contnent);
  }
};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

int TEMelmnt::coregerr(ofstream& rflog1, char varname1[9],
                       const float& col1, const float& row1,
                       char varname2[9], const float& col2, const float& row2)
{

  int fatalerr = 0;

  if (col1 != col2 || row1 != row2)
  {
    fatalerr = 1;

    cout << "ERROR:  " << varname1 << " data and ";
    cout << varname2 << "data are not coregistered." << endl;
    cout << "COL = " << col1 << " and ROW = " << row1 << " in ";
    cout << varname1 << " data" << endl;
    cout << "COL = " << col2 << " and ROW = " << row2;
    cout << " in " << varname2 << " data" << endl;

    rflog1 << "ERROR:  " << varname1 << " data and ";
    rflog1 << varname2 << "data are not coregistered." << endl;
    rflog1 << "COL = " << col1 << " and ROW = " << row1 << " in ";
    rflog1 << varname1 << " data" << endl;
    rflog1 << "COL = " << col2 << " and ROW = " << row2 << " in ";
    rflog1 << varname2 << " data" << endl;
  }

  return fatalerr;

};

/* **************************************************************
************************************************************** */


/* *************************************************************
************************************************************** */

void TEMelmnt::GISsetELMNTstate(const int& dcmnt,
                                Temdata initstat[NUMMSAC][MAXSTATE+1])
{

/* **************************************************************
  Function initializes TEM state variables from spatially
explicit data sets
************************************************************** */

  int dm;
  int j, days;
  const int year = 1992;  // to make sure to be able to deal with 29 days of February

  // Initialize ODE carbon, nitrogen, and water state variables

//  tem.y[tem.I_AVLW] = initstat[itype][tem.I_AVLW].dat[CYCLE-1][30];
  tem.y[tem.I_RGRW] = initstat[itype][tem.I_RGRW].dat[CYCLE-1][30];
  tem.y[tem.I_SNWPCK] = initstat[itype][tem.I_SNWPCK].dat[CYCLE-1][30];
  tem.y[tem.I_SGRW] = initstat[itype][tem.I_SGRW].dat[CYCLE-1][30];

  // for 3-box hydrology
  tem.y[tem.I_AVLW1] = initstat[itype][tem.I_AVLW1].dat[CYCLE-1][30];
  tem.y[tem.I_AVLW2] = initstat[itype][tem.I_AVLW2].dat[CYCLE-1][30];
  tem.y[tem.I_AVLW3] = initstat[itype][tem.I_AVLW3].dat[CYCLE-1][30];

  tem.y[tem.I_SM1] = tem.y[tem.I_AVLW1] + tem.soil.wiltpt1;
  tem.y[tem.I_SM2] = tem.y[tem.I_AVLW2] + tem.soil.wiltpt2;
  tem.y[tem.I_SM3] = tem.y[tem.I_AVLW3] + tem.soil.wiltpt3;

  tem.y[tem.I_PCTP1] =  100.0 * tem.y[tem.I_SM1] / tem.soil.totpor1;
  tem.y[tem.I_PCTP2] =  100.0 * tem.y[tem.I_SM2] / tem.soil.totpor2;
  tem.y[tem.I_PCTP3] =  100.0 * tem.y[tem.I_SM3] / tem.soil.totpor3;

// end of adding

  // Initialize monthly carbon, nitrogen, and water pools for element

  for (dm = 0; dm < CYCLE; dm++)
  {
    days = daysnumber(dm, year);
    for (j=0; j < days; j++)
    {

    // Water pools
//    tem.soil.avlh2o[dm][j] = tem.y[tem.I_AVLW];
    tem.soil.rgrndh2o[dm][j] = tem.y[tem.I_RGRW];
    tem.soil.snowpack[dm][j] = tem.y[tem.I_SNWPCK];
    tem.soil.sgrndh2o[dm][j] = tem.y[tem.I_SGRW];
//    tem.soil.moist[dm][j] = tem.y[tem.I_SM];
//    tem.soil.pctp[dm][j] = tem.y[tem.I_PCTP];
//    tem.soil.vsm[dm][j] = tem.y[tem.I_VSM];

     // for 3-box hydrology
    tem.soil.avlh2o1[dm][j] = tem.y[tem.I_AVLW1];
    tem.soil.avlh2o2[dm][j] = tem.y[tem.I_AVLW2];
    tem.soil.avlh2o3[dm][j] = tem.y[tem.I_AVLW3];

    tem.soil.moist1[dm][j] = tem.y[tem.I_SM1];
    tem.soil.moist2[dm][j] = tem.y[tem.I_SM2];
    tem.soil.moist3[dm][j] = tem.y[tem.I_SM3];

    tem.soil.pctp1[dm][j] = tem.y[tem.I_PCTP1];
    tem.soil.pctp2[dm][j] = tem.y[tem.I_PCTP2];
    tem.soil.pctp3[dm][j] = tem.y[tem.I_PCTP3];

//    tem.soil.vsm1[dm][j] = tem.y[tem.I_VSM1];
//    tem.soil.vsm2[dm][j] = tem.y[tem.I_VSM2];
//    tem.soil.vsm3[dm][j] = tem.y[tem.I_VSM3];

    // end of adding

    }
  }
};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************** */

int TEMelmnt::loadteclds(FILE* fclds, Clmdata clds,
                         const int& numspin, const int& spintime,
                         const int& RTIME)
{

  int i;
  int j;
  int k;
  int gisend = 1;
  int dm;
  int dyr;
  int totspin;
  int m,days;

// Get CLDINESS from transient data set

  totspin = numspin * spintime;
  for (i = (totspin+1); i < (RTIME+1); i++)//llc fix
  {
    k = i - (totspin+1);

    if(clds_dflag == 1){gisend = clds.getdel_clm(fclds);} // for daily
    if(clds_dflag == 0){gisend = clds.getdel(fclds);}// monthly

    if (gisend == -1)
    {
      col = MISSING;
      row = MISSING;
      return gisend;
    }

// Determine CLDINESS for equilibrium conditions

    if ( k == 0)
    {
      col = clds.col;
      row = clds.row;
 //     printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!clds data: %f, %f,\n",col,row);  //llc
      carea = clds.carea;
      strcpy(contnent,clds.contnent);
      clm.cldsyear[0] = clds.year - (totspin+1);
      for (j = 0; j < CYCLE; j++)
      {

       days = daysnumber(j, clds.year);
       for (m =0; m < days; m++)
       clm.tclds[0][j][m] = clds.dat[j][m];// for daily & monthly
      }
    }

// Determine CLDINESS for transient conditions

//     printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!clds data: %f, %f,\n",clds.col,clds.row);  //llc

  //  else
   // {
      for (j = 0; j < CYCLE; j++)
      {

      days = daysnumber(j, clds.year);
       for (m =0; m < days; m++)
       {
        clm.tclds[i][j][m] = clds.dat[j][m];// for daily & monthly
   //     printf("i=%i,j=%i,m=%i,sr = %f,\n",i,j,m,clm.tclds[i][j][m]);
       }
      }
      clm.cldsyear[i] = clds.year;
  //  }
  }

// Determine CLDINESS during spin up

  for (i = 0; i < numspin; i++)
  {
    dyr = totspin + 1;
    for (j = 0; j < spintime; j++)
    {
      k = (i * spintime) + j + 1;
      clm.cldsyear[k] = clm.cldsyear[0] + k;
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm, clm.cldsyear[k]);
        for (m =0; m < days; m++)
        {
         clm.tclds[k][dm][m] = clm.tclds[dyr][dm][m]; //llc fix
    //     printf("year=%i,month=%i,days=%i,sr = %f,dyr=%i,\n",clm.cldsyear[k],dm+1,m+1,clm.tclds[k][dm][m],dyr);
         }
      }
     // ++dyr;  //llc fix
    }
  }

  return gisend;

};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************** */

int TEMelmnt::loadtelulc(FILE* flulc, Lulcdata lulc,
                         const int& numspin, const int& spintime,
                         const int& RTIME, int& ftlerr, ofstream& flog1)
{

  int i;
  int j;
  int k;
  int gisend = 1;
  int totspin;

// Get LULC from transient data set

  totspin = numspin*spintime;
  for (i = (totspin+1); i < (RTIME+1); i++) //llc fix
  {
    k = i - (totspin+1);
    gisend = lulc.getdel(flulc);
    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "LULC", lulc.col, lulc.row);

// Determine LULC for equilibrium conditions

    if ( k == 0)
    {
      tem.ag.lulcyear[0] = lulc.year - (totspin+1);
      tem.ag.tstate[0] = lulc.agstate;
      tem.ag.tRAP[0] = lulc.RAP;
    }

// Determine LULC for transient conditions

  //  else
  //  {
      tem.ag.lulcyear[i] = lulc.year;
      tem.ag.tstate[i] = lulc.agstate;
      tem.ag.tRAP[i] = lulc.RAP;
   // }
  }

// Determine LULC during spin up

  for (i = 0; i < numspin; i++)
  {
    for (j = 0; j < spintime; j++)
    {
      k = (i * spintime) + j + 1;
      tem.ag.lulcyear[k] = tem.ag.lulcyear[0] + k;
      tem.ag.tstate[k] = tem.ag.tstate[0];
      tem.ag.tRAP[k] = tem.ag.tRAP[0];
    }
  }

 return gisend;

};


/* *************************************************************
************************************************************** */

// the follow use has been changed, now used as freshorganic matter for methane production

int TEMelmnt::loadtenpp(FILE* fnpp, Temdata npp, const int& maxtype,
                         const int& numspin, const int& spintime,
                         const int& RTIME, int& ftlerr, ofstream& flog1)
{

  int i;
  int j;
  int k;
  int gisend = 1;
  int totspin;
  int days;
  int dm;
  int dyr;
  int m;

  int dv;


// Get NPP from transient data set

  for (dv = 0; dv < maxtype; dv++)
  {

  totspin = numspin*spintime;
  for (i = (totspin+1); i < (RTIME+1); i++) //llc fix
  {
    k = i - (totspin+1);
    gisend = npp.getdel(fnpp);
    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "NPP", npp.col, npp.row);

// Determine NPP for equilibrium conditions

    if ( k == 0)
    {
      for (j = 0; j < CYCLE; j++) {
       days = daysnumber(j, npp.year);
       for (m=0; m < days; m++)
//       tem.atms.tprec[0][j][m] = prec.dat[j][m];
       tem.ch4dmpro.tsuborg[dv][0][j][m] = npp.dat[j][m];
       }
//      tem.atms.precyear[0] = prec.year - totspin;
//      tem.atms.yrtprec[0] = prec.total;
//      if (prec.total <= 0.0) { noprec = 1; }
    }

// Determine NPP for transient conditions

 //   else
 //   {
      for (j = 0; j < CYCLE; j++) {
      days = daysnumber(j, npp.year);
      for (m=0; m < days; m++)
        tem.ch4dmpro.tsuborg[dv][i][j][m] = npp.dat[j][m];
      }
  //      tem.atms.precyear[i] = prec.year;
  //      tem.atms.yrtprec[i] = prec.total;
 //    }
 }

// Get NPP from transient data set
  for (i = 0; i < numspin; i++)
  {
    dyr = totspin + 1;
    for (j = 0; j < spintime; j++)
    {
      k = (i * spintime) + j + 1;
   //   tem.atms.precyear[k] = tem.atms.precyear[0] + k;
   //   tem.atms.yrtprec[k] = tem.atms.yrtprec[dyr];
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm, npp.year);
         for (m=0; m < days; m++)
//         tem.ch4dmpro.tsuborg[k][dm][m] = npp.dat[dm][m];
         tem.ch4dmpro.tsuborg[dv][k][dm][m] = tem.ch4dmpro.tsuborg[dv][dyr][dm][m];
      //  tem.atms.tprec[k][dm][m] = tem.atms.tprec[dyr][dm][m];
      }
     // ++dyr;  //llc fix
    }
  }

  }


  return gisend;

};


/* *************************************************************
************************************************************** */
// input data are in mm
int TEMelmnt::loadteprec(FILE* fprec, Clmdata prec,
                         const int& numspin, const int& spintime,
                         const int& RTIME, int& ftlerr, ofstream& flog1)
{

  int i;
  int j;
  int k;
  int gisend = 1;
  int dm;
  int dyr;
  int totspin;
  int m;

  int days;

// Get PREC from transient data set

  noprec = 0;
  totspin = numspin * spintime;
  for (i = (totspin+1); i < (RTIME+1); i++) //llc test
  {
    k = i - (totspin+1);
    if(prec_dflag == 1) {gisend = prec.getdel_clm(fprec);} // daily version

    if(prec_dflag == 0) {gisend = prec.getdel(fprec);} // monthly version, 07/July/03

    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "PREC", prec.col, prec.row);

// Determine PREC for equilibrium conditions

    if ( k == 0)
    {
      for (j = 0; j < CYCLE; j++) {

       days = daysnumber(j, prec.year);

       for (m=0; m < days; m++)

	 if(prec_dflag == 0) {tem.atms.tprec[0][j][m] = prec.dat[j][m] / tem.atms.daze[j];}   //monthly
       if(prec_dflag == 1) {tem.atms.tprec[0][j][m] = prec.dat[j][m];} //daily

//       tem.atms.tprec[0][j][m] = prec.mon[j];

       }
      tem.atms.precyear[0] = prec.year - (totspin+1);
      tem.atms.yrtprec[0] = prec.total ;
      if (prec.total <= 0.0) { noprec = 1; }
    }

// Determine PREC for transient conditions

//    else
//    {
      for (j = 0; j < CYCLE; j++) {

      days = daysnumber(j, prec.year);
      for (m=0; m < days; m++)
       {
	 if(prec_dflag == 0) { tem.atms.tprec[i][j][m] = prec.dat[j][m] / tem.atms.daze[j]; }  //monthly
	 if(prec_dflag == 1) {tem.atms.tprec[i][j][m] = prec.dat[j][m];} //daily
//       printf("prec=%f,,year=%i,m=%i,\n",prec.dat[j][m],prec.year,j+1);
       }
//      tem.atms.tprec[i][j][m] = prec.mon[j];
       }

      tem.atms.precyear[i] = prec.year;
      tem.atms.yrtprec[i] = prec.total ;
 //   }
  }

// Determine PREC during spin up

  for (i = 0; i < numspin; i++)
  {
    dyr = totspin + 1;
    for (j = 0; j < spintime; j++)
    {
      k = (i * spintime) + j + 1;
      tem.atms.precyear[k] = tem.atms.precyear[0] + k;
      tem.atms.yrtprec[k] = tem.atms.yrtprec[dyr];
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm, tem.atms.precyear[k]);
         for (m=0; m < days; m++)
        tem.atms.tprec[k][dm][m] = tem.atms.tprec[dyr][dm][m];
      }
     // ++dyr;  //llc fix
    }
  }

  return gisend;

};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************** */

int TEMelmnt::loadtetair(FILE* ftair, Clmdata tair,
                         const int& numspin, const int& spintime,
                         const int& RTIME, int& ftlerr, ofstream& flog1)
{

  int i;
  int j;
  int k;
  int gisend = 1;
  int dm;
  int dyr;
  int totspin;
  int m, days;

// Get TAIR from transient data set

  lowtair = 0;
  totspin = numspin * spintime;
  for (i = (totspin+1); i < (RTIME+1); i++) //llc fix
  {
    k = i - (totspin+1);
    if(tair_dflag == 1) {gisend = tair.getdel_clm(ftair);} //daily
    if(tair_dflag == 0) {gisend = tair.getdel(ftair);} //monthly

    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "TAIR", tair.col, tair.row);

// Determine TAIR for equilibrium conditions

    if ( k == 0)
    {
      tem.atms.tairyear[0] = tair.year - (totspin+1);
      tem.atms.mxttair[0] = tair.max;
      if (tair.max < -1.0) { lowtair = 1; }
      for (j = 0; j < CYCLE; j++)
      {
         days = daysnumber(j, tair.year);
        for (m=0; m < days; m++)
         {
	           tem.atms.ttair[0][j][m] = tair.dat[j][m]; //daily & monthly


         }

      }
    }

// Determine TAIR for transient conditions

//    else
//    {
      tem.atms.tairyear[i] = tair.year;
      tem.atms.mxttair[i] = tair.max;
      for (j = 0; j < CYCLE; j++) {
         days = daysnumber(j, tair.year);
         for (m=0; m < days; m++)
         {
	           tem.atms.ttair[i][j][m] = tair.dat[j][m]; //daily & monthly

//         printf("tair=%f,year=%i,mon=%i,d=%i,\n",tair.dat[j][m],tair.year,j+1,m+1);//llc
         }
       }
 //   }
  }
// Determine TAIR during spin up

  for (i = 0; i < numspin; i++)
  {
    dyr = totspin + 1;
    for (j = 0; j < spintime; j++)
    {
      k = (i * spintime) + j + 1;
      tem.atms.tairyear[k] = tem.atms.tairyear[0] + k;
      tem.atms.mxttair[k] = tem.atms.mxttair[dyr];
      for (dm = 0; dm < CYCLE; dm++)
      {
          days = daysnumber(dm, tem.atms.tairyear[k]);
          for (m=0; m < days; m++)
          tem.atms.ttair[k][dm][m] = tem.atms.ttair[dyr][dm][m];
      }
     // ++dyr;  //llc fix
    }
  }

  return gisend;

};

/* *************************************************************
************************************************************** */
//llc for wetland

int TEMelmnt::loadtestw(FILE* fstw, Clmdata stw,
                         const int& numspin, const int& spintime,
                         const int& RTIME, int& ftlerr, ofstream& flog1)
{

  int i;
  int j;
  int k;
  int gisend = 1;
  int dm;
  int dyr;
  int totspin;
  int m, days;

// Get stw from transient data set

  totspin = numspin * spintime;
  for (i = (totspin+1); i < (RTIME+1); i++) //llc fix
  {
    k = i - (totspin+1);
    if(stw_dflag == 1) {gisend = stw.getdel_clm(fstw);} //daily
    if(stw_dflag == 0) {gisend = stw.getdel(fstw);} //monthly
    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "STW", stw.col, stw.row);

// Determine stw for equilibrium conditions

    if ( k == 0)
    {
      tem.atms.stwyear[0] = stw.year - (totspin+1);
      for (j = 0; j < CYCLE; j++)
      {
         days = daysnumber(j, stw.year);
        for (m=0; m < days; m++)
         {
         tem.atms.tstw[0][j][m] = stw.dat[j][m];//daily & monthly

         }

      }
    }

// Determine stw for transient conditions


      tem.atms.stwyear[i] = stw.year;
      for (j = 0; j < CYCLE; j++) {
         days = daysnumber(j, stw.year);
         for (m=0; m < days; m++)
         {
         tem.atms.tstw[i][j][m] = stw.dat[j][m];//daily & monthly
         }
       }
 //   }
  }
// Determine stw during spin up

  for (i = 0; i < numspin; i++)
  {
    dyr = totspin + 1;
    for (j = 0; j < spintime; j++)
    {
      k = (i * spintime) + j + 1;
      tem.atms.stwyear[k] = tem.atms.stwyear[0] + k;
      for (dm = 0; dm < CYCLE; dm++)
      {
          days = daysnumber(dm, tem.atms.stwyear[k]);
          for (m=0; m < days; m++)
          tem.atms.tstw[k][dm][m] = tem.atms.tstw[dyr][dm][m];
      }
     // ++dyr;  //llc fix
    }
  }

  return gisend;

};

/* *************************************************************
************************************************************** */
//llc for wetland

int TEMelmnt::loadtesg_frin(FILE* fsg_frin, Clmdata sg_frin,
                         const int& numspin, const int& spintime,
                         const int& RTIME, int& ftlerr, ofstream& flog1)
{

  int i;
  int j;
  int k;
  int gisend = 1;
  int dm;
  int dyr;
  int totspin;
  int m, days;

// Get sg_frin from transient data set

  totspin = numspin * spintime;
  for (i = (totspin+1); i < (RTIME+1); i++) //llc fix
  {
    k = i - (totspin+1);
    gisend = sg_frin.getdel(fsg_frin); //monthly
    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "frin", sg_frin.col, sg_frin.row);

// Determine sg_frin for equilibrium conditions

    if ( k == 0)
    {
      tem.atms.sg_frinyear[0] = sg_frin.year - (totspin+1);
      for (j = 0; j < CYCLE; j++)
      {
         days = daysnumber(j, sg_frin.year);
        for (m=0; m < days; m++)
         {
         tem.atms.tsg_frin[0][j][m] = sg_frin.dat[j][m];//daily & monthly

         }

      }
    }

// Determine sg_frin for transient conditions


      tem.atms.sg_frinyear[i] = sg_frin.year;
      for (j = 0; j < CYCLE; j++) {
         days = daysnumber(j, sg_frin.year);
         for (m=0; m < days; m++)
         {
         tem.atms.tsg_frin[i][j][m] = sg_frin.dat[j][m];//daily & monthly
         }
       }
 //   }
  }
// Determine sg_frin during spin up

  for (i = 0; i < numspin; i++)
  {
    dyr = totspin + 1;
    for (j = 0; j < spintime; j++)
    {
      k = (i * spintime) + j + 1;
      tem.atms.sg_frinyear[k] = tem.atms.sg_frinyear[0] + k;
      for (dm = 0; dm < CYCLE; dm++)
      {
          days = daysnumber(dm, tem.atms.sg_frinyear[k]);
          for (m=0; m < days; m++)
          tem.atms.tsg_frin[k][dm][m] = tem.atms.tsg_frin[dyr][dm][m];
      }
     // ++dyr;  //llc fix
    }
  }

  return gisend;

};

/* *************************************************************
************************************************************** */

// added for hydrology model

int TEMelmnt::loadvap(FILE* fvap, Clmdata vap,
                           const int& numspin, const int& spintime,
                           const int& RTIME, int& ftlerr, ofstream& flog1)
 {

  int i;
  int j;
  int k;
  int gisend = 1;
  int dm;
  int dyr;
  int totspin;
  int m, days;



// Get vap from transient data set

  lowvap = 0;
  totspin = numspin * spintime;
  for (i = (totspin+1); i < (RTIME+1); i++) {   //llc fix
    k = i - (totspin+1);
    if(vapor_dflag == 1) {gisend = vap.getdel_clm(fvap);}//daily
     	 
    if(vapor_dflag == 0) {gisend = vap.getdel(fvap);} //monthly

    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "VAP", vap.col, vap.row);

// Determine vap for equilibrium conditions

    if ( k == 0) {
      tem.hyd.vapyear[0] = vap.year - (totspin+1);
      tem.hyd.mxtvap[0] = vap.max;
      if (vap.max < -1.0) { lowvap = 1; }
      for (j = 0; j < CYCLE; j++) {

        days = daysnumber(j, vap.year);
        for (m=0; m < days; m++)
         {
	         tem.hyd.tvap[0][j][m] = vap.dat[j][m];//daily & monthly
         }

       }
    }

// Determine vap for transient conditions

//    else {
      tem.hyd.vapyear[i] = vap.year;
      tem.hyd.mxtvap[i] = vap.max;
      for (j = 0; j < CYCLE; j++) {
        days = daysnumber(j, vap.year);
        for (m=0; m < days; m++)
         {
 
	           tem.hyd.tvap[i][j][m] = vap.dat[j][m];//daily  & monthly
//         printf("vap=%f,year=%i,m=%i,\n",vap.dat[j][m],vap.year,j+1);

         }
      }
//    }
  }

// Determine Vap during spin up

  for (i = 0; i < numspin; i++) {
    dyr = totspin + 1;
    for (j = 0; j < spintime; j++) {
      k = (i * spintime) + j + 1;
      tem.hyd.vapyear[k] = tem.hyd.vapyear[0] + k;
      tem.hyd.mxtvap[k] = tem.hyd.mxtvap[dyr];
      for (dm = 0; dm < CYCLE; dm++) {
        days = daysnumber(dm, tem.hyd.vapyear[k]);
        for (m=0; m < days; m++)
       //       tem.hyd.tvap[k][dm] = tem.hyd.tvap[dyr][dm];
         tem.hyd.tvap[k][dm][m] = tem.hyd.tvap[dyr][dm][m];
        }
     // ++dyr;  //llc fix
    }
  }



  return gisend;

};

//addition for reading in LAI 19/02/2002

int TEMelmnt::loadtelai(FILE* flai, Clmdata GISlai,
                         const int& numspin, const int& spintime,
                         const int& RTIME, int& ftlerr, ofstream& flog1)
{

  int i;
  int j;
  int k;
  int gisend = 1;
  int dm;
  int dyr;
  int totspin;
  int days, m;

// Get LAI from transient data set

  lowGISlai = 0;
  totspin = numspin * spintime;
  for (i = (totspin+1); i < (RTIME+1); i++) //llc fix
  {
    k = i - (totspin+1);
    gisend = GISlai.getdel(flai);
    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "LAI", GISlai.col, GISlai.row);

// Determine LAI for equilibrium conditions

    if ( k == 0)
    {
      tem.atms.GISlaiyear[0] = GISlai.year - (totspin+1);
      tem.atms.mxtGISlai[0] = GISlai.max;
      if (GISlai.max < -1.0) { lowGISlai = 1; }
      for (j = 0; j < CYCLE; j++)
      {
        days = daysnumber(j, tem.atms.GISlaiyear[0]);
        for (m=0; m < days; m++)
        tem.atms.tGISlai[0][j][m] = GISlai.dat[j][m];
      }

    }

// Determine LAI for transient conditions

//    else
 //   {
      tem.atms.GISlaiyear[i] = GISlai.year;
      tem.atms.mxtGISlai[i] = GISlai.max;
      for (j = 0; j < CYCLE; j++) {
        days = daysnumber(j, GISlai.year);
        for (m=0; m < days; m++)
        tem.atms.tGISlai[i][j][m] = GISlai.dat[j][m];
        }
//    }
  }
// Determine LAI during spin up

  for (i = 0; i < numspin; i++)
  {
    dyr = totspin + 1;
    for (j = 0; j < spintime; j++)
    {
      k = (i * spintime) + j + 1;
      tem.atms.GISlaiyear[k] = tem.atms.GISlaiyear[0] + k;
      tem.atms.mxtGISlai[k] = tem.atms.mxtGISlai[dyr];
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm, tem.atms.GISlaiyear[k]);
        for (m=0; m < days; m++)
        tem.atms.tGISlai[k][dm][m] = tem.atms.tGISlai[dyr][dm][m];
      }
     // ++dyr;  //llc fix
    }
  }

  return gisend;

};


/* *************************************************************
************************************************************* */

void TEMelmnt::runtem(ofstream& rflog1, char predmap[MAXPRED][9],
                      const int& cldflag, const int& atmsflag,
                      const int& atmsoutfg, int& natmspred,
                      ofstream fsradout[NUMATMS],
                      const int& temflag, const int& kdinflg,
                      int& ntempred, ofstream ftemout[MAXPRED],
                      const int& stateflag,
                      const int& equil, const int& totsptime,
                      const int& RTIME)
{

//  int i;
//  int j;
//  int k;
//  int dt;


  int dm;
  int dyr = 0;
  int wrtyr;
//  int maxtime;
  int m,days;

  // Assignment of "ACCEPT" to tqc added by DWK on 20000719
  int tqc = ACCEPT;
  int qc_data = ACCEPT; // Q. Zhuang to check Airt, prec, Vap data validity, May/15/2003

  qc = ACCEPT;
  tem.totyr = 0;

  if (atmsflag == 1)
  {

// Check cloudiness input for valid data

    for (dm = 0; dm < CYCLE; dm++)
    {
      days = daysnumber(dm, ttotyr[dyr][itype]);
      for (m=0; m < days; m++)
      {
       if (cldflag == 0 && clm.nirr[dm][m] <= -99.0) { qc = 1; }
       if (cldflag == 1 && clm.tcldsflag == 0 && clm.clds[dm][m] <= -99.0)
       {
         qc = 2;
        }
       if (cldflag == 1 && clm.tcldsflag == 1 && clm.tclds[0][dm][m] <= -99.0)
       {
         qc = 3;
       }
     }
   }

   if (qc == ACCEPT)
    {

// Calculate GIRR from POTSCLM model

      clm.yrsumday = 0.0;
	  double temp = 0.0;
      for (dm = 0; dm < CYCLE; dm++)
      {
       days = daysnumber(dm, ttotyr[dyr][itype]);
       for (m=0; m< days; m++)
        {
         clm.girr[dm][m] = clm.xgirr(lat,dm,clm.yrsumday);
// use new approach for calculating daily solar radiation, Q. zhuang
        //clm.girr[dm][m] = clm.xgirr_new(lat,temp);
        }
      }
    }
    else { rflog1 << "cldqc = " << qc << endl; }
  }

  

/* *************************************************************
		BEGIN VEGETATION MOSAIC LOOP
************************************************************* */

  for (itype = 0; itype < maxtype; itype++)
  {
    qc = ACCEPT;

    //Following "if" statement added by DWK on 20000719 to modify
    // the assignment of tem.veg.cmnt
    if (tem.veg.temveg > 0 && tem.veg.temveg < (NUMVEG+1))
    {

  //   printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! %i, %i,\n", tem.veg.cmnt,tem.veg.subtype[mez][itype]);

    tem.veg.cmnt = tem.veg.subtype[mez][itype];

    }
    else { tem.veg.cmnt = 0; }


// Calculate NIRR, CLDINESS and PAR for Equilibrium Conditions with POTSCLM

    if (atmsflag == 1)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
 //	     if (clm.tcldsflag == 1) { clm.clds[dm] = clm.tclds[0][dm]; }
 //	     if (cldflag == 1)

 //       {
 //	       clm.nirr[dm] = clm.xnirr(clm.clds[dm], clm.girr[dm]);
 //       }
     days = daysnumber(dm, ttotyr[dyr][itype]);
     for (m=0; m< days; m++)
      {
      if (clm.tcldsflag == 1)
       if (cldflag == 1) { clm.clds[dm][m] = clm.tclds[0][dm][m]; }
         else { clm.nirr[dm][m] = clm.tclds[0][dm][m]; }
//      else { clm.nirr[dm] = clm.tclds[0][dm] * 2.387; }
//     }
     if (cldflag == 1) {
      clm.nirr[dm][m] = clm.xnirr(clm.clds[dm][m], clm.girr[dm][m]);
      }
     //  JSC 3/15/01 added above from xtem41e for trans radiation
		else
        {
	       clm.clds[dm][m] = clm.mkclds(clm.girr[dm][m], clm.nirr[dm][m]);
        }
	     clm.par[dm][m]  = clm.xpar(clm.clds[dm][m], clm.nirr[dm][m]);
      }
     } // end of days

// Output POTSCLM steady state results to files

      if (atmsoutfg == 1 && itype == 0)
      {
	     dyr = 0;
	     atmswritepred(fsradout, predmap, dyr, natmspred);
      }
    }
   


// Initialize TEM output variables to missing value

    if (temflag == 1)
    {

      tem.microbe.kdsave[itype] = -9.9999;
      if (kdinflg == 1) { tem.microbe.kdc = tem.microbe.kdin[itype]; }

// "Hand-off" POTSCLM equilibrium output and equilibrium input data to TEM

      for (dm = 0; dm < CYCLE; dm++)
      {

       days = daysnumber(dm, ttotyr[dyr][itype]);
       for (m=0; m < days; m++)
        {
	     if (atmsflag == 1)
        {
          tem.atms.nirr[dm][m] = clm.nirr[dm][m];
	       tem.atms.par[dm][m] = clm.par[dm][m];
	     }
	     tem.atms.co2[dm][m] = tem.atms.co2level;

        // Update TAIR with current year data from transient data files
	     if (tem.atms.ttairflag == 1)
        {
          tem.atms.tair[dm][m] = tem.atms.ttair[0][dm][m];
		  if (tem.atms.tair[dm][m] <= MISSING) qc_data = REJECT;

        }
//llc for wetland
        // Update stw with current year data from transient data files
	     if (tem.atms.tstwflag == 1)
        {
          tem.atms.stw[dm][m] = tem.atms.tstw[0][dm][m];
		  if (tem.atms.stw[dm][m] <= MISSING) qc_data = REJECT;

        }

 //llc for wetland
        // Update sg_frin with current year data from transient data files
	     if (tem.atms.tsg_frinflag == 1)
        {
          tem.atms.sg_frin[dm][m] = tem.atms.tsg_frin[0][dm][m];
		  if (tem.atms.sg_frin[dm][m] <= MISSING) qc_data = REJECT;

        }

        // Update PREC with current year data from transient data files
	     if (tem.atms.tprecflag == 1)
        {
          tem.atms.prec[dm][m] = tem.atms.tprec[0][dm][m];
		  if (tem.atms.prec[dm][m] <= MISSING) qc_data = REJECT;

        }

       // Update LAI with current year data from transient data files   //19/02/2002
	     if (tem.atms.tlaiflag == 1)
        {
          tem.atms.GISlai[dm][m] = tem.atms.tGISlai[0][dm][m];
        }

      // added for hydrology model by QZ
       if (tem.hyd.vapflag == 1)
       {
        tem.hyd.vap[dm][m] = tem.hyd.tvap[0][dm][m];
		if (tem.hyd.vap[dm][m] <= MISSING) qc_data = REJECT;

        }

    // if NPP is invalid data
      tem.ch4dmpro.suborg[dm][m] = tem.ch4dmpro.tsuborg[itype][0][dm][m];
   //    printf(" %4.2f", tem.ch4dmpro.suborg[dm][m]);
   //   if (tem.ch4dmpro.suborg[dm][m] <= -MISSING) qc_data = REJECT;

        // Update LULC with current year data from transient data files
   	  if (tem.ag.tlulcflag == 1)
        {
          // if rap is 0 (RAP0flag == 1), then we don't need tpotnpp
	       if(tem.ag.RAP0flag == 0)
          {
  	         tem.ag.potnpp[dm][m] = tem.ag.tpotnpp[itype][0][dm][m];
	       }
          else { tem.ag.potnpp[dm][m] = 0.0; }
	     }
       } // end of days
     }

      if (tem.atms.ttairflag == 1)
      {
        tem.atms.mxtair = tem.atms.mxttair[0];
        if (tem.atms.mxtair < -1.0) { lowtair = 1; }
      }
      if (tem.atms.tprecflag == 1)
      {
        tem.atms.yrprec = tem.atms.yrtprec[0];
        if (tem.atms.yrprec <= 0.0) { noprec = 1; }
      }

      if (tem.atms.tlaiflag == 1)   // 19/02/2002
      {
        tem.atms.yrGISlai = tem.atms.yrtGISlai[0];
        if (tem.atms.yrGISlai <= 0.0) { lowGISlai = 0; }
      }


// Check TEM input for valid data

//      qc = temgisqc(stateflag,tem.soil.pctsilt, tem.soil.pctclay,
//                    tem.veg.cmnt, tem.elev, tem.atms.nirr, tem.atms.par,
//                    tem.atms.tair, tem.atms.mxtair, tem.atms.prec,
//                    tem.atms.yrprec, initstat);


// Check TEM parameters for specific vegetation types

      // If "qc == REJECT", write code of underlying reason to log file
      if (qc != ACCEPT) { rflog1 << "temgisqc = " << qc << endl; }
      else {
     //  qc = tem.ecdqc(tem.veg.cmnt);

       }
    
      // "qc == ACCEPT" condition moved ahead of "qc != ACCEPT".  In addition
      //  "qc != ACCEPT" condition modified to write out grid cells with
      // missing values (or 0.0) to spatially explicit files

// folowing assignment is forcing qz = accept, i.e. avoid to check the data vladity, Q. Zhuang 24/Feb/2003
      qc = ACCEPT;
      if (qc == ACCEPT)
      {

/* *******************************************************************
Start the Terrestrial Ecosystem Model (TEM) for Equilibrium Conditions
******************************************************************* */

 // set up soil properties and time step, added for Darcy's law and Richards Equations
        tem.hydm.set_soil_pro(tem.veg.cmnt); //llc fix
	//      tem.wm.Initialize(tem.soil.pctor/100.0); //llc for wetland

        // To get soil capacity Q. Zhuang, June 07 2003    
//        tem.soil.xtext(tem.veg.cmnt,tem.soil.pctsilt,tem.soil.pctclay);

        tem.soil.hydm_xtext(tem.veg.cmnt,tem.soil.pctsilt,tem.soil.pctclay);

        tem.ch4dmdif.premethane(); //llc fix  for methane concentration in soil

// Initialize TEM parameters to grid cell's vegetation type, soil texture,
//   PET and AET

//	     tem.setELMNTecd(kdinflg,tem.veg.cmnt, tem.soil.psiplusc);
//        tem.setELMNTevap(stateflag, tem.veg.cmnt, tem.atms.pet3, tem.atms.tair, tem.hyd.vap);

// "While" loop to allow adaptive integrator tolerance (i.e. tem.tol) to be
// reduced if chaotic behavior occurs

        tem.ag.state = 0;
        tem.ag.prvstate = 0;

	     for (dyr = 0; dyr < RTIME; dyr++) { tem.qualcon[dyr][itype] = 0; }

	     tem.nattempt = 0;
	     tem.tol = tem.inittol;
	     tem.baseline = tem.initbase;

   // for doing methane, directly go to transient simulations, Q. Zhuang, May/15/2003
    /*
	     while (tem.nattempt < tem.maxnrun)
        {

// Initialize standing stocks of carbon and nitrogen from spatially-explicit
// data sets (i.e. stateflag = 1) or calibration ("ECD") data

	       if (stateflag == 1) {
           GISsetELMNTstate(tem.veg.cmnt, initstat); }
	       else {
           tem.ECDsetELMNTstate(tem.veg.cmnt, tem.soil.psiplusc);
           }
	       tem.setELMNTflux();

// Run TEM until steady state conditions occur (equilibrium)

	       tem.nattempt = tem.equilibrium(itype,tem.tol);

	       if (tem.nattempt < tem.maxnrun) { tem.tol /= 10.0; }
        }

	     outyr = 0;
	     tem.qualcon[outyr][itype] += tem.nattempt;
	     if (tem.nattempt == tem.maxnrun && tem.totyr == tem.maxyears)
        {
	       tem.qualcon[outyr][itype] += 20;
	     }
     */
      } // end of "qc == ACCEPT"


/* *************************************************************
Output TEM steady state results to files.  Assign the baseline equilibrium
conditions to the first year of the output data if a transient analysis is being
conducted.  Otherwise, report the number of years it took to reach an
equilibrium state for local environmental conditions
************************************************************* */

      // (The following code was added 20000718 by DWK and incorporates
      // components from both the former "qc == ACCEPT" and "qc == REJECT"
      // conditions if the eariler code).
     /*
	   if (equil == 0)
      {
        ttotyr[outyr][itype] = tem.startyr - totsptime - 1;
      }
	   else
      {
        if (qc == ACCEPT) { ttotyr[outyr][itype] = tem.totyr; }
        else {

/* ***********************************************************************
 If long-term environmental conditions of the grid cell cannot support the
 terrestrial biota (as indicated by input data), assume no living or dead
 organic matter exists in the grid cell and equilibrium conditions were
 achieved in a single year (i.e., tem.totyr = 1).  Otherwise, assign a missing
 value to flag the grid cell to provide information about potential problems
 with the input data sets.
 *********************************************************************** */

         // initstat[itype][0].ave changed to initstat[itype][tem.I_VEGC].ave by
        //    DWK on 20000214
        // tem.ez changed to tem.veg.cmnt by DWK on 20000214
      /*
          if ((tem.veg.cmnt > 0) && ((noprec == 1) || (lowtair == 1)
             || (stateflag == 1 && initstat[itype][tem.I_VEGC].ave < 0.1
             && initstat[itype][tem.I_VEGC].ave > MISSING)))
          {
	         ttotyr[outyr][itype] = 1;
          }
          else { ttotyr[outyr][itype] = -999; }
        }
      }


      // Write TEM output to spatially explicit data files
      // if (qc == ACCEPT) // i.e., Good data
        if (qc_data == ACCEPT) // i.e., Good data

      {
        // DWK changed dyr to outyr in temwritepred on 20000629
        temwritepred(ftemout,predmap,outyr,itype,ntempred,natmspred);
      }
      else // Something's not right!
      {


         // If "qc == REJECT", write code of underlying reason to log file
        rflog1 << "temecdqc = " << qc << endl;

        // Assign zero to all TEM output variables if long-term environmental
        // conditions cannot support life.

        if ((tem.veg.cmnt > 0) && ((noprec == 1) || (lowtair == 1)
           || (stateflag == 1 && initstat[itype][tem.I_VEGC].ave < 0.1
           && initstat[itype][tem.I_VEGC].ave > MISSING)))
        {

          // tqc is a flag used to assign zero to all TEM variables below for
          // both the initialization and the transient simulations of TEM
          tqc = TQCZEROFLAG;
          temwritemiss(ftemout,predmap,outyr,itype,ntempred,natmspred,ZERO);
        }
        else

      // if the data is invalid, output the variables with missing values, 15/May/2003, Q. Z.
        {
          // Skip TEM if input data and/or parameters are missing
          temwritemiss(ftemout,predmap,outyr,itype,ntempred,natmspred,MISSING);
        }
      } // end of "qc = REJECT"
     */

 	   if (equil == 0)
      {

/* *******************************************************************
                     Begin Transient Conditions
******************************************************************* */

	     tem.microbe.kdsave[itype] = tem.microbe.kd;
	     tem.totyr = tem.startyr - totsptime;

       // Following "if" conditional statement added by DWK on 20000719

       // The following statement is commented by Q. Zhuang, Jan/09/2003
      //  if (tqc == ACCEPT)
      //  {
	   //    tqc = transqc(tem.maxyears,tem.totyr, tem.veg.plant);
     //   }


        dyr = 1;
        outyr = 1;
        tem.totyr = 0;
        tem.baseline = 0;
        tem.wrtyr = -99;
	//	printf("llc test  0225,\n"); //llctest
        while (tem.totyr < tem.endyr)
        {

     
	  //Following "if" statement added by DWK on 20000719
          if (tqc == ACCEPT && qc != ACCEPT) { tqc = qc; }

          // Following "if" statement moved within year loop by DWK on
          // 20000718

	  if (qc_data == ACCEPT) // i.e., Good data, Q. Zhuang
	    //     if (tqc == ACCEPT)
	    {

	      // Calculate NIRR, CLDINESS and PAR for Spin up and Transient Conditions
	      //   with POTSCLM  -- also, hand off NIRR and PAR to TEM

	      if (atmsflag == 1 && clm.tcldsflag == 1)
		{
		  tem.totyr = clm.cldsyear[dyr];
		  for (dm = 0; dm < CYCLE; dm++)
		    {
		      //		          clm.clds[dm] = clm.tclds[dyr][dm];
		      //		          if (cldflag == 1)
		      //               {
		      //		            clm.nirr[dm] = clm.xnirr(clm.clds[dm], clm.girr[dm]);
		      days = daysnumber(dm, ttotyr[dyr][itype]);
		      for (m=0; m < days; m++)
			{
			  if (cldflag == 1) { clm.clds[dm][m] = clm.tclds[dyr][dm][m]; }
			  else { clm.nirr[dm][m] = clm.tclds[dyr][dm][m]; }
			  //            else { clm.nirr[dm] = clm.tclds[dyr][dm] * 2.387; }

			  if (cldflag == 1) {
			    clm.nirr[dm][m] = clm.xnirr(clm.clds[dm][m], clm.girr[dm][m]);
			    // JSC added 3/15/01 for transient radiation input
			  }
			  else
			    {
			      clm.clds[dm][m] = clm.mkclds(clm.girr[dm][m], clm.nirr[dm][m]);
			    }
			  tem.atms.par[dm][m]  = clm.xpar(clm.clds[dm][m], clm.nirr[dm][m]);
			  tem.atms.nirr[dm][m] = clm.nirr[dm][m];
		        } // end of days
		    }
		  
		  // Output POTSCLM transient results to files

		 

		  if (atmsoutfg == 1 && itype == 0)
		    {
		      atmswritepred(fsradout, predmap, dyr, natmspred);
		    }

		}

	     

	      // Run the Terrestrial Ecosystem Model (TEM) under transient conditions
	      //tem.hydm.set_soil_pro(tem.veg.cmnt);
	      //      printf("001dyr = %i, RTIME =%i, toty=%i,endy=%i,\n",dyr,RTIME,tem.totyr,tem.endyr);

	      //     printf("test 001 %i,%i,%i,\n",col,row, dyr); //llctest
 
	      wrtyr = tem.transient(dyr,itype, tem.tol,RTIME);

	     
	      //    printf("test 002 %i,%i,%i,\n",col,row, dyr); //llctest
	      
	      // Output TEM transient results for specified years to files
 
	      if ((wrtyr%tem.diffyr) == 0)
		{
		  ttotyr[outyr][itype] = tem.totyr;
		  temwritepred(ftemout,predmap,outyr,itype,ntempred,natmspred);
		  ++outyr;
		}
	      ++dyr;
	      

	    } // End of tqc = ACCEPT "if" statement
	  else
	    {
	      //   	printf("llc test  02256,\n"); //llctest

	      if (outyr == 1) { rflog1 << "tqc = " << tqc << endl; }
	      tem.totyr = tem.startyr - totsptime - 1
		+ (outyr * tem.diffyr);

	      ttotyr[outyr][itype] =  tem.totyr;
	      // Assign zero to all TEM output variables if initial long-term
	      // environmental conditions were unable to support life.
	      if (tqc == TQCZEROFLAG)
		{
		  temwritemiss(ftemout,predmap,outyr,itype,ntempred,natmspred,ZERO);
    
		}
	      else
		{
		  // Skip TEM if input data and/or parameters are missing
		  temwritemiss(ftemout,predmap,outyr,itype,ntempred,natmspred,MISSING);
   
		}
	      ++outyr;
	    } // End of tqc = REJECT
        } // End of While totyr < endyr
	//    printf("llc test  0226,\n"); //llctest
	   } // End of Transient else
	   //    printf("llc test  0227,\n"); //llctest
    } // End of the Terrestrial Ecosystem Model (TEM)
    //  printf("llc test  0228,\n"); //llctest
  } // End of Vegetation Mosaic Loop
  // printf("llc test  0229,\n"); //llctest

};

/* *************************************************************
************************************************************* */


/* **************************************************************
************************************************************** */

 //modified by QZ for hydrology model
int TEMelmnt::temgisin(ofstream& flog1, int& ftlerr, const int& atmsflag,
		       const int& itype, const int& maxtype,
                       const int& kdinflg, const int& stateflag,
                       FILE* fstxt, FILE*felev, FILE* fph, FILE* ftoc, FILE* fc4, FILE* fwetld, FILE* finuda, FILE* fcult, FILE* fnirr,
                       FILE* fpar, FILE* flai, FILE* ftair, FILE* fstw, FILE* fsg_frin, FILE* fprec, FILE* fvap, FILE* flulc, FILE* fnpp,
                       FILE* fkdin, FILE* fstate[MAXESTAT+7],
		       const int& numspin, const int& spintime,
                       const int& RTIME)  //llc for wetland
{

  int i;
  int gisend = 1;
  int m, days;

  Soildata fao;
  Elevdata elv;
  Wetlanddata wetd; //wetalnd
  Inudadata finud; // fraction induation
  Cultdata fcultd; // cultivation data
  Phdata ph;  // pH data
  Tocdata toc; // toc youmi oh isotope
  C4data c4; // c4 youmi oh isotope

  Clmdata nirr;
  Clmdata par;

  Clmdata GISlai;  // 19/02/2002  Q. Z.

  Clmdata tair;
  Clmdata stw; //llc for wetland
  Clmdata sg_frin; //llc for wetland
  Clmdata prec;
  Lulcdata lulc;
  Temdata npp;
  Temdata leaf;
  KDdata kddat;

  // added for hydrological model  by QZ
  Clmdata vap;


  if (itype == 0)
  {

    noprec = 0;
    lowtair = 0;
    lowGISlai = 0;  // 19/02/2002 Q. Z.

    gisend = fao.getdel(fstxt);
    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "TEXTURE", fao.col, fao.row);
    carea = fao.carea;
    tem.lat=row; //llc added
    tem.soil.pctsand = fao.pctsand; // added for hydrology model by QZ

    tem.soil.pctsilt = fao.pctsilt;
    tem.soil.pctclay = fao.pctclay;
    tem.soil.wsoil = fao.wsoil;
    gisend = elv.getdel(felev);
    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "ELEV", elv.col, elv.row);
    tem.elev = elv.elev;
    // reading wetland
    gisend = wetd.getdel(fwetld);
    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "wet", wetd.col, wetd.row);
    tem.wet = wetd.wet;
    // reading wetland
    gisend = finud.getdel(finuda);
    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "frin", finud.col, finud.row);
    tem.frin = finud.frin;

   // reading cultivation data
    gisend = fcultd.getdel(fcult);
    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "icult", fcultd.col, fcultd.row);
    tem.icult = fcultd.icult;
    // for ph value
    gisend = ph.getdel(fph);
    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "PH", ph.col, ph.row);
    tem.ph = ph.pH;

    // added TOC and C4 for isotope model youmi
    gisend = toc.getdel(ftoc);
    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "TOC", toc.col, toc.row);
    tem.toc = toc.toC;

    gisend = c4.getdel(fc4);
    if (gisend == -1) { return gisend; }
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "C4", c4.col, c4.row);
    tem.c4 = c4.C4;

    if (atmsflag == 0)
    {
      gisend = nirr.getdel(fnirr);
      if (gisend == -1) { return gisend; }
      ftlerr = coregerr(flog1,"TEMVEG", col, row, "NIRR", nirr.col, nirr.row);
      for (i = 0; i < CYCLE; i++) {
      days = daysnumber(i, nirr.year);
      for (m=0; m < days; m++)
      tem.atms.nirr[i][m] = nirr.dat[i][m]; }

      gisend = par.getdel(fpar);
      if (gisend == -1) { return gisend; }
      ftlerr = coregerr(flog1,"TEMVEG", col, row, "PAR", par.col, par.row);
      for (i = 0; i < CYCLE; i++) {
      days = daysnumber(i, par.year);
      for (m=0; m < days; m++)
      tem.atms.par[i][m] = par.dat[i][m]; }
    }
    
    if (tem.atms.ttairflag == 1)
    {
      gisend = loadtetair(ftair, tair, numspin, spintime, RTIME, ftlerr, flog1);
      if (gisend == -1) { return gisend; }
      for (i = 0; i < CYCLE; i++) {
      days = daysnumber(i, tair.year);
      for (m=0; m < days; m++)
      tem.atms.tair[i][m] = tem.atms.ttair[0][i][m];
        }
    }
    else
    {
      gisend = tair.getdel(ftair);

      if (gisend == -1) { return gisend; }
      ftlerr = coregerr(flog1,"TEMVEG", col, row, "TAIR", tair.col, tair.row);
      tem.atms.mxtair = tair.max;

 // lowtair condition added by DWK on 20000214
      if (tem.atms.mxtair < -1.0) { lowtair = 1; }
      for (i = 0; i < CYCLE; i++) {
          days = daysnumber(i, tair.year);
      for (m=0; m < days; m++)

      tem.atms.tair[i][m] = tair.dat[i][m]; }
    }
//llc for wetland =============================================
    if (tem.atms.tstwflag == 1)
    {
      gisend = loadtestw(fstw, stw, numspin, spintime, RTIME, ftlerr, flog1);
      if (gisend == -1) { return gisend; }
      for (i = 0; i < CYCLE; i++) {
      days = daysnumber(i, stw.year);
      for (m=0; m < days; m++)
      tem.atms.stw[i][m] = tem.atms.tstw[0][i][m];
        }
    }
    else
    {
//may add later
    }

    if (tem.atms.tsg_frinflag == 1)
    {
      gisend = loadtesg_frin(fsg_frin, sg_frin, numspin, spintime, RTIME, ftlerr, flog1);
      if (gisend == -1) { return gisend; }
      for (i = 0; i < CYCLE; i++) {
      days = daysnumber(i, sg_frin.year);
      for (m=0; m < days; m++)
      tem.atms.sg_frin[i][m] = tem.atms.tsg_frin[0][i][m];
        }
    }
    else
    {
//may add later
    }
//llc for wetland ============================================= end

    if (tem.atms.tprecflag == 1)
    {
      gisend = loadteprec(fprec, prec, numspin, spintime, RTIME, ftlerr, flog1);
      if (gisend == -1) { return gisend; }
      for (i = 0; i < CYCLE; i++) {
          days = daysnumber(i, prec.year);
      for (m=0; m < days; m++)

      tem.atms.prec[i][m] = tem.atms.tprec[0][i][m]; }
    }
    else
    {
      gisend = prec.getdel(fprec);
      if (gisend == -1) { return gisend; }
      ftlerr = coregerr(flog1,"TEMVEG", col, row, "PREC", prec.col, prec.row);
      tem.atms.yrprec = prec.total;
      if (prec.total <= 0.0) { noprec = 1; }
      for (i = 0; i < CYCLE; i++) {
          days = daysnumber(i, prec.year);
      for (m=0; m < days; m++)

      tem.atms.prec[i][m] = prec.dat[i][m]; }
    }
 // addition for reading in LAI 19/02/2002

   if (tem.atms.tlaiflag == 1)
    {
      gisend = loadtelai(flai, GISlai, numspin, spintime, RTIME, ftlerr, flog1);
      if (gisend == -1) { return gisend; }
      for (i = 0; i < CYCLE; i++) {
          days = daysnumber(i, GISlai.year);
      for (m=0; m < days; m++)  tem.atms.GISlai[i][m] = tem.atms.tGISlai[0][i][m]; }
    }
    else
    {
      gisend = GISlai.getdel(flai);
      if (gisend == -1) { return gisend; }
      ftlerr = coregerr(flog1,"TEMVEG", col, row, "GISlai", GISlai.col, GISlai.row);
      tem.atms.yrGISlai = GISlai.total;
      if (GISlai.total <= 0.0) { lowGISlai = 0; }
      for (i = 0; i < CYCLE; i++) {
          days = daysnumber(i, GISlai.year);
      for (m=0; m < days; m++)

      tem.atms.GISlai[i][m] = GISlai.dat[i][m]; }
    }
  // added for hydrological model

    if (tem.hyd.vapflag == 1) {
      gisend = loadvap(fvap, vap, numspin, spintime, RTIME, ftlerr, flog1);
      if (gisend == -1) { return gisend; }
      for (i = 0; i < CYCLE; i++) {
         days = daysnumber(i, vap.year);
      for (m=0; m < days; m++)
      tem.hyd.vap[i][m] = tem.hyd.tvap[0][i][m]; }
    }
    else {
      gisend = vap.getdel(fvap);
      if (gisend == -1) { return gisend; }
      ftlerr = coregerr(flog1,"TEMVEG", col, row, "VAP", vap.col, vap.row);
      tem.hyd.yrvap = vap.total;
      if (vap.total <= 0.0) { novap = 1; }
      for (i = 0; i < CYCLE; i++) {
          days = daysnumber(i, vap.year);
      for (m=0; m < days; m++)
       tem.hyd.vap[i][m] = vap.dat[i][m];}
          }
  // end of adding
  // load NPP for methane production
   	gisend = loadtenpp(fnpp, npp, maxtype, numspin, spintime, RTIME, ftlerr, flog1);
 //      gisend = npp.getdel(fnpp);
 //   tem.ch4dmpro.tsuborg[dyr][dm][m] = npp.dat[dm][m];
     for (i = 0; i < CYCLE; i++) {
          days = daysnumber(i, npp.year);
          for (m=0; m < days; m++)
           {
            tem.ch4dmpro.suborg[i][m] = tem.ch4dmpro.tsuborg[itype][0][i][m];
//          tem.ch4dmpro.suborg[i][m] = npp.dat[i][m];
//           printf(" %3.2f", tem.ch4dmpro.suborg[i][m]);

           }
        }

      tem.ch4dmpro.annpp = tem.ch4dmpro.tannpp[0]; // annual total NPP

    if (tem.ag.tlulcflag == 1)
    {
      gisend = loadtelulc(flulc, lulc, numspin, spintime, RTIME, ftlerr, flog1);
      if (gisend == -1) { return gisend; }
      tem.ag.state = tem.ag.tstate[0];
      tem.ag.RAP = tem.ag.tRAP[0];

// Note: numspin and spintime removed from function call by D. Kicklighter 990724

      if(tem.ag.RAP0flag == 0)  // only get potnpp if RAP > 0
      {
	gisend = loadtenpp(fnpp, npp, maxtype, numspin, spintime,RTIME, ftlerr, flog1);
      }
      if (gisend == -1) { return gisend; }
    }


  }


  if (kdinflg == 1)
  {
    kddat.getdel(fkdin);
    ftlerr = coregerr(flog1,"TEMVEG", col, row, "KD", kddat.col, kddat.row);
    tem.microbe.kdin[itype] = kddat.kd;
  }

/* Read in initialization data */
  if (stateflag == 1)
  {
    for (i = 0; i < MAXSTATE; i++)
    {
      gisend = initstat[itype][i].getdel(fstate[i]);
      if (gisend == -1) { return gisend; }
      ftlerr = coregerr(flog1,"TEMVEG", col, row, "Initial", initstat[itype][i].col, initstat[itype][i].row);
      if (ftlerr != 0)
      {
	cout  << "Initial data set " << (i+1) << endl;
	flog1 << "Initial data set " << (i+1) << endl;
      }
    }

    tem.veg.prvleafmx[initstat[itype][MAXESTAT+4].subtveg-1] = initstat[itype][MAXESTAT+4].max * 0.01;
    tem.atms.yrpet3 = initstat[itype][MAXESTAT+5].total;
    tem.atms.prvpetmx = initstat[itype][MAXESTAT+5].max;
    tem.atms.yreet3 = initstat[itype][MAXESTAT+6].total;
    tem.atms.prveetmx = initstat[itype][MAXESTAT+6].max;
    for (i = 0; i < CYCLE; i++)
    {
         days = daysnumber(i, npp.year);
      for (m=0; m < days; m++)
       {
        tem.atms.pet3[i][m] = initstat[itype][MAXESTAT+5].dat[i][m];
        tem.veg.unnormleaf[i][m] = initstat[itype][MAXESTAT+4].dat[i][m] * 0.01;
       }
    }
  }

//  for (i = 0; i < RTIME; i++) {
//    flog1 << tem.atms.tairyear[i];
//    for (int dm = 0; dm < CYCLE; dm++) {
//      flog1 << " " << setprecision(1) << tem.atms.ttair[i][dm];
//    }
//    flog1 << endl;
//  }

  return gisend;

};

/* *************************************************************
************************************************************** */


/* * *************************************************************
************************************************************** */

int TEMelmnt::temgisqc(const int& stateflag, const double& pctsilt, const double& pctclay,
		       const int& cmnt, const double& elev, double nirr[CYCLE][31], double par[CYCLE][31],
		       double tair[CYCLE][31], double& mxtair, double prec[CYCLE][31], double& yrprec,
		       Temdata initstat[NUMMSAC][MAXSTATE+1])
{

  int i;
  int qc;

  int m, days;

  int year = 1992;  // to deal with 29 days

  qc = ACCEPT;

  if (pctsilt < 0.0) { return qc = 1; }
  if (pctclay < 0.0) { return qc = 2; }
// Following condition modified by DWK on 20000219
//  if (ez < 0 || ez >= NUMVEG) { return qc = 3; }
  if (cmnt < 1 || cmnt > NUMVEG) { return qc = 3; }
  if (elev <= -999.0) { return qc = 4;}
  if (mxtair < -1.0) { return qc = 5; }
  if (yrprec <= 0.0) { return qc = 6; }


  for (i = 0; i < CYCLE; i++)
  {

      days = daysnumber(i, year);
      for (m=0; m < days; m++)
     {
      if (nirr[i][m] <= -1.0) { return qc = 7; }
      if (par[i][m] <= -1.0) { return qc = 8; }
      if (tair[i][m] <= -99.0) { return qc = 9; }
      if (prec[i][m] <= -1.0) { return qc = 10; }
     }
  }


  if (stateflag == 1)
  {
    for (i = 0; i < (MAXESTAT+5); i++)
    {
      if (initstat[0][i].dat[11][30] <= MISSING) { return qc = (11 + i); }
    }
    if (initstat[0][0].ave < 0.1) { return qc = 17 + MAXESTAT; }
  }

  return qc;

};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************** */

void TEMelmnt::temwritemiss(ofstream fout[MAXPRED], char predname[MAXPRED][9],
                            const int& dyr, const int& itype,
                            const int& ntempred, const int& natmspred,
                            const double value)
{

  int i;
  int k;
  int dm;
  int m, days;

  Temdata tempred;

  for (i = 0; i < ntempred; i++)
  {
    k = i + natmspred;

    for (dm = 0; dm < CYCLE; dm++)
    {

      days = daysnumber(dm, ttotyr[dyr][itype]);
      for (m=0; m < days; m++)
   	tempred.dat[dm][m] = value;
    }

    // Write output data to files

    tempred.outdel(fout[i], col, row, predname[k],
                   tem.veg.temveg, tem.veg.subtype[mez][itype],
                   (100.0 * tem.soil.psiplusc),
                   tem.qualcon[dyr][itype],
                   carea,
                   ttotyr[dyr][itype],
                   tempred.dat,
                   contnent);

  }

};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************** */

void TEMelmnt::temwritepred(ofstream fout[MAXPRED], char predname[MAXPRED][9],
                            const int& dyr, const int& itype,
                            const int& ntempred, const int& natmspred)
{

  int i;
  int k;
  int dm;
  int m, days;

  Temdata tempred;


  for (i = 0; i < ntempred; i++)
  {
    k = i + natmspred;

      

    if (strcmp(predname[k],tem.predstr[tem.I_NPP]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {

      days = daysnumber(dm, ttotyr[dyr][itype]);
      for (m=0; m < days; m++)

    	  tempred.dat[dm][m] = tem.veg.npp[dm][m];
      }
    }
   /*
    else if (strcmp(predname[k],tem.predstr[tem.I_VEGC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.plant[dm][m].carbon;  // VEGC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_SOLC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
          days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.org[dm][m].carbon;  // SOLC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_STRN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
          days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.strctrl[dm][m].nitrogen;  // VSTRUCTN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_STON]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
     days = daysnumber(dm);
          for (m=0; m < days; m++)
  	     tempred.dat[dm][m] = tem.veg.labile[dm][m].nitrogen * 1000.0;  // VSTOREN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_SOLN]) == 0)
    {
    for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm);
      for (m=0; m < days; m++)

     	  tempred.dat[dm][m] = tem.soil.org[dm][m].nitrogen;  // SOILORGN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_AVLN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
          days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.availn[dm][m] * 1000.0;  // AVAILN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_NMIN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
          days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.microbe.netnmin[dm][m] * 1000.0;  // NETNMIN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_NEP]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
          days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.nep[dm][m];  // NEP
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_GPP]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.gpp[dm][m];  // GPP
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_INGPP]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.ingpp[dm][m];  // INGPP
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_INNPP]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.innpp[dm][m];  // INNPP
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_RH]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
      days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.microbe.rh[dm][m];  // RH
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_NLST]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.nlost[dm][m] * 1000.0;  // NLOST
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_NINP]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.ninput[dm][m] * 1000.0;  // NINPUT
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_RVMNT]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.rm[dm][m];  // RVMAINT
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_RVGRW]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.rg[dm][m];  // RVGRWTH
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_GPR]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.gpr[dm][m];  // GPR
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_LTRC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
          days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.ltrfal[dm][m].carbon;  // LTRC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_VNUP]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
          days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.nuptake[dm][m] * 1000.0;  // VEGNUP
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_LTRN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.ltrfal[dm][m].nitrogen * 1000.0;  // LTRN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_MNUP]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.microbe.nuptake[dm][m] * 1000.0;  // MICRONUP
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_VNMBL]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.nmobil[dm][m] * 1000.0;  // VNMOBIL
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_VNRSRB]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.nresorb[dm][m] * 1000.0;  // VNRESORB
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_VSUP]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
          days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.suptake[dm][m] * 1000.0;  // VEGSUP
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_VLUP]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.luptake[dm][m] * 1000.0;  // VEGLUP
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_UNRMLF]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.unnormleaf[dm][m] * 100.0;  // UNRMLEAF
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_LEAF]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
      days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.veg.leaf[dm][m] * 100.0;      // LEAF
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_CNVRTC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.convrtflx[dm][m].carbon;   // CONVERTC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_CNVRTN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.convrtflx[dm][m].nitrogen * 1000.0; // CONVERTN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_PRDF10C]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.formPROD10.carbon / (double) CYCLE; // PRDF10C
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_PRDF10N]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
       days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = (tem.ag.formPROD10.nitrogen / (double) CYCLE) *
                          1000.0; // PRDF10N
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_PRDF100C]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
       days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.formPROD100.carbon / (double) CYCLE; // PRDF100C
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_PRDF100N]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
        days = daysnumber(dm);
      for (m=0; m < days; m++)

      {
	     tempred.dat[dm][m] = (tem.ag.formPROD100.nitrogen / (double) CYCLE) *
                          1000.0; // PRDF100N
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_PROD10C]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.PROD10.carbon; // PROD10C
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_PROD10N]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
           days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.PROD10.nitrogen * 1000.0; // PROD10N
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_PROD100C]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.PROD100.carbon; // PROD100C
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_PROD100N]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.PROD100.nitrogen * 1000.0; // PROD100N
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_PRD10FC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
       days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.PROD10decay.carbon / (double) CYCLE; // PRD10FC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_PRD10FN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
          days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = (tem.ag.PROD10decay.nitrogen / (double) CYCLE) *
                          1000.0; // PRD10FN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_PRD100FC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
      days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.PROD100decay.carbon / (double) CYCLE; // PRD100FC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_PRD100FN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = (tem.ag.PROD100decay.nitrogen / (double) CYCLE) *
                          1000.0; // PRD100FN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_AGNPPC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.npp[dm][m].carbon; // AGNPPC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_AGNPPN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
      days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.npp[dm][m].nitrogen * 1000.0; // AGNPPN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_AGFPRDC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.formPROD1.carbon / (double) CYCLE; // AGFPRODC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_AGFPRDN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
         days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = (tem.ag.formPROD1.nitrogen / (double) CYCLE) *
                          1000.0; // AGFPRODN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_AGFRTN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
       days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.fertn[dm][m] * 1000.0; // AGFERTN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_AGLTRC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
          days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.ltrfal[dm][m].carbon; // AGLTRFC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_AGLTRN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm);
      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.ltrfal[dm][m].nitrogen * 1000.0; // AGLTRFN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_SLASHC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.slash[dm][m].carbon; // SLASHC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_SLASHN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.slash[dm][m].nitrogen; // SLASHN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_AGPRDC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.PROD1.carbon; // AGPRODC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_AGPRDN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.PROD1.nitrogen * 1000.0; // AGPRODN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_AGPRDFC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.PROD1decay.carbon / (double) CYCLE; // AGPRODFC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_AGPRDFN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = (tem.ag.PROD1decay.nitrogen / (double) CYCLE) *
                          1000.0; // AGPRODFN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_TOTFPRDC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.formTOTPROD.carbon / (double) CYCLE; // TOTFPRDC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_TOTFPRDN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = (tem.ag.formTOTPROD.nitrogen / (double) CYCLE) *
                          1000.0; // TOTFPRDN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_TOTPRDC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.TOTPROD.carbon; // TOTPRODC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_TOTPRDN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.TOTPROD.nitrogen * 1000.0; // TOTPRODN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_TOTPRDFC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.TOTPRODdecay.carbon / (double) CYCLE; // TOTPRDFC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_TOTPRDFN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = (tem.ag.TOTPRODdecay.nitrogen / (double) CYCLE) *
                          1000.0; // TOTPRDFN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_TOTEC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.totalc[dm][m]; // TOTEC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_TOTNPP]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.totnpp[dm][m]; // TOTNPP
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_TOTGC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.totalc[dm][m] + tem.ag.TOTPROD.carbon; // TOTGC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_CFLX]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.cflux[dm][m]; // CFLUX
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_SCNVRTC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
    days = daysnumber(dm);      for (m=0; m < days; m++)

      {
	     tempred.dat[dm][m] = tem.ag.sconvrtflx[dm][m].carbon; // SCONVRTC
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_SCNVRTN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.sconvrtflx[dm][m].nitrogen; // SCONVRTN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_NSRTNT]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.ag.nsretent[dm][m]; // NSRETENT
      }
    }
     else if (strcmp(predname[k],tem.predstr[tem.I_VSM]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.vsm[dm][m] * 100.0;      // VSM
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_PET]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.atms.pet[dm][m];
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_EET]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.atms.eet[dm][m];              // EET
      }
    }
      */
     else if (strcmp(predname[k],tem.predstr[tem.I_PET3]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm, ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.atms.pet3[dm][m];
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_EET3]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm, ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.atms.eet3[dm][m];              // EET
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_RAIN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm, ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.atms.rain[dm][m];             // RAIN
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_SNWINF]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
     days = daysnumber(dm, ttotyr[dyr][itype]);     for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.snowinf[dm][m];          // SNOWINF
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_WYLD]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {

    days = daysnumber(dm, ttotyr[dyr][itype]);      for (m=0; m < days; m++)
	     tempred.dat[dm][m] = tem.soil.h2oyld[dm][m];          // H2OYIELD
      }
    }

  // added for hydrology model

  else if (strcmp(predname[k],tem.predstr[tem.I_PCTP1]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {

        days = daysnumber(dm, ttotyr[dyr][itype]);      for (m=0; m < days; m++)
        tempred.dat[dm][m] = tem.soil.pctp1[dm][m];          // PCTP1
      }
    }

  else if (strcmp(predname[k],tem.predstr[tem.I_PCTP2]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {

        days = daysnumber(dm, ttotyr[dyr][itype]);      for (m=0; m < days; m++)
	     tempred.dat[dm][m] = tem.soil.pctp2[dm][m] ;          // PCTP2
      }
    }

  else if (strcmp(predname[k],tem.predstr[tem.I_PCTP3]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
	     tempred.dat[dm][m] = tem.soil.pctp3[dm][m] ;          // PCTP3
      }
    }

  else if (strcmp(predname[k],tem.predstr[tem.I_VSM1]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
	     tempred.dat[dm][m] = tem.soil.vsm1[dm][m] * 100.0;      // VSM1
       }
    }
  else if (strcmp(predname[k],tem.predstr[tem.I_VSM2]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
	     tempred.dat[dm][m] = tem.soil.vsm2[dm][m] * 100.0;      // VSM2
      }
    }
  else if (strcmp(predname[k],tem.predstr[tem.I_VSM3]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
	     tempred.dat[dm][m] = tem.soil.vsm3[dm][m] * 100.0;      // VSM3
      }
    }

   else if (strcmp(predname[k],tem.predstr[tem.I_VSM4]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
	     tempred.dat[dm][m] = tem.soil.vsm4[dm][m] * 100.0;      // VSM4
      }
    }

  else if (strcmp(predname[k],tem.predstr[tem.I_VSM5]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
	     tempred.dat[dm][m] = tem.soil.vsm5[dm][m] * 100.0;      // VSM5
      }
    }

  else if (strcmp(predname[k],tem.predstr[tem.I_VSM6]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
        days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
	     tempred.dat[dm][m] = tem.soil.vsm6[dm][m] * 100.0;      // VSM6
      }
    }

    else if (strcmp(predname[k], tem.predstr[tem.I_INFIL]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
      days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
   	tempred.dat[dm][m] = tem.hydm.surinfl[dm][m];          // infiltration
         }
    }

   else if (strcmp(predname[k], tem.predstr[tem.I_SRUNOFF]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
      days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
   	tempred.dat[dm][m] = tem.hydm.surrunoff[dm][m];          // runoff
         }
    }
   else if (strcmp(predname[k], tem.predstr[tem.I_DRAIN]) == 0) {
       for (dm = 0; dm < CYCLE; dm++) {
       days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
     	tempred.dat[dm][m] = tem.hydm.bdrai[dm][m];          // drainage
         }
    }

    else if (strcmp(predname[k], tem.predstr[tem.I_TRANS]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
     days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
     tempred.dat[dm][m] = tem.hyd.htrans[dm][m];          // Transpiration
         }
    }
    else if (strcmp(predname[k], tem.predstr[tem.I_SEVAP]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
      days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
    	tempred.dat[dm][m] = tem.hyd.soil_evap[dm][m];          // soil surface evaporation
         }
    }
    else if (strcmp(predname[k], tem.predstr[tem.I_SNOWSUB]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
      days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
   	tempred.dat[dm][m] = tem.hyd.snowsub[dm][m];          // snow sublimation
         }
    }
    else if (strcmp(predname[k], tem.predstr[tem.I_SUBCAN]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
     days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
     tempred.dat[dm][m] = tem.hyd.sub_from_canopy[dm][m];          // snow sublimation from canopy
         }
    }
    else if (strcmp(predname[k], tem.predstr[tem.I_WT]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
     days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
     tempred.dat[dm][m] = tem.hydm.watertable[dm][m];          // water table depth (mm)
         }
    }

    else if (strcmp(predname[k], tem.predstr[tem.I_CH4CON]) == 0) 
	{
      for (dm = 0; dm < CYCLE; dm++) 
	  {
		days = daysnumber(dm,ttotyr[dyr][itype]);
		for (m=0; m < days; m++)
		{
			tempred.dat[dm][m] = tem.ch4dmdif.ch4cons[dm][m];          // total ch4 eflux (mg m-2 day-1)
//			cout <<tempred.dat[dm][m]<<",";
         }
//		 cout <<endl;
	  }
    }

    else if (strcmp(predname[k], tem.predstr[tem.I_CH4SC]) == 0)  //llc porewater
	{
      for (dm = 0; dm < CYCLE; dm++) 
	  {
		days = daysnumber(dm,ttotyr[dyr][itype]);
		for (m=0; m < days; m++)
		{
			tempred.dat[dm][m] = tem.ch4dmdif.ch4sc[dm][m];          // uM

			//	 printf("test ch4sc.%i,%i,%i,%f,\n,",dyr,dm,m,tempred.dat[dm][m]);
//			cout <<tempred.dat[dm][m]<<",";
         }
//		 cout <<endl;
	  }
    }

   else if (strcmp(predname[k], tem.predstr[tem.I_CH4EMI]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
     days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
     tempred.dat[dm][m] = tem.ch4dmdif.ch4emis[dm][m];          // total ch4 eflux (mg m-2 day-1)
         }
    }

  else if (strcmp(predname[k], tem.predstr[tem.I_TOTFLX]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
     days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
     tempred.dat[dm][m] = tem.ch4dmdif.ch4tot[dm][m];          // total ch4 eflux (mg m-2 day-1)
         }
    }

 // end of adding

// added for isotope output youmi 

  else if (strcmp(predname[k], tem.predstr[tem.I_D13INIT]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
     days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
     tempred.dat[dm][m] = tem.ch4dmdif.d13init[dm][m];          // isotope values
         }
    }

  else if (strcmp(predname[k], tem.predstr[tem.I_D13PROD]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
     days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
     tempred.dat[dm][m] = tem.ch4dmdif.d13prod[dm][m];          // isotope values
         }
    }

  else if (strcmp(predname[k], tem.predstr[tem.I_D13OXID]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
     days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
     tempred.dat[dm][m] = tem.ch4dmdif.d13oxid[dm][m];          // isotope values
         }
    }

  else if (strcmp(predname[k], tem.predstr[tem.I_D13FINAL]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
     days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
     tempred.dat[dm][m] = tem.ch4dmdif.d13final[dm][m];          // isotope values
         }
    }

  else if (strcmp(predname[k], tem.predstr[tem.I_MOMPFRAC]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
     days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
     tempred.dat[dm][m] = tem.ch4dmdif.mompfrac[dm][m];          // isotope values
         }
    }

  else if (strcmp(predname[k], tem.predstr[tem.I_TPFRAC]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
     days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
     tempred.dat[dm][m] = tem.ch4dmdif.tpfrac[dm][m];          // isotope values
         }
    }

  else if (strcmp(predname[k], tem.predstr[tem.I_TEFRAC]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
     days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
     tempred.dat[dm][m] = tem.ch4dmdif.tefrac[dm][m];          // isotope values
         }
    }

  else if (strcmp(predname[k], tem.predstr[tem.I_TDFRAC]) == 0) {
      for (dm = 0; dm < CYCLE; dm++) {
     days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
     tempred.dat[dm][m] = tem.ch4dmdif.tdfrac[dm][m];          // isotope values
         }
    }




   // for soil temperature
    else if (strcmp(predname[k],tem.predstr[tem.I_TSOIL]) == 0)
     {
      for (dm = 0; dm < CYCLE; dm++)
         {

    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
	        tempred.dat[dm][m] = tem.atms.tsoil[dm][m];          // Tsoil
         }
      }
    else if (strcmp(predname[k],tem.predstr[tem.I_DST5]) == 0)
     {
      for (dm = 0; dm < CYCLE; dm++)
         {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	        tempred.dat[dm][m] = tem.atms.dst5[dm][m];          // Tsoil
         }
      }
   else if (strcmp(predname[k],tem.predstr[tem.I_DST10]) == 0)
     {
      for (dm = 0; dm < CYCLE; dm++)
         {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	        tempred.dat[dm][m] = tem.atms.dst10[dm][m];          // Tsoil
         }
      }
   else if (strcmp(predname[k],tem.predstr[tem.I_DST20]) == 0)
     {
      for (dm = 0; dm < CYCLE; dm++)
         {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	        tempred.dat[dm][m] = tem.atms.dst20[dm][m];          // Tsoil
         }
      }
   else if (strcmp(predname[k],tem.predstr[tem.I_DST50]) == 0)
     {
      for (dm = 0; dm < CYCLE; dm++)
         {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	        tempred.dat[dm][m] = tem.atms.dst50[dm][m];          // Tsoil
         }
      }
   else if (strcmp(predname[k],tem.predstr[tem.I_DST100]) == 0)
     {
      for (dm = 0; dm < CYCLE; dm++)
         {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)
	        tempred.dat[dm][m] = tem.atms.dst100[dm][m];          // Tsoil
         }
      }
   else if (strcmp(predname[k],tem.predstr[tem.I_DST200]) == 0)
     {
      for (dm = 0; dm < CYCLE; dm++)
         {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	        tempred.dat[dm][m] = tem.atms.dst200[dm][m];          // Tsoil
         }
      }
   else if (strcmp(predname[k],tem.predstr[tem.I_FRONTD]) == 0)
     {
      for (dm = 0; dm < CYCLE; dm++)
         {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	        tempred.dat[dm][m] = tem.atms.frontd[dm][m];          // Tsoil
         }
      }
   else if (strcmp(predname[k],tem.predstr[tem.I_THAWBE]) == 0)
     {
      for (dm = 0; dm < CYCLE; dm++)
         {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	        tempred.dat[dm][m] = tem.atms.thawbe[dm][m];          // Tsoil
         }
      }
  else if (strcmp(predname[k],tem.predstr[tem.I_THAWEND]) == 0)
       {
      for (dm = 0; dm < CYCLE; dm++)
         {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	        tempred.dat[dm][m] = tem.atms.thawend[dm][m];          // Tsoil
         }
      }
   // end of soil temperature


    else if (strcmp(predname[k],tem.predstr[tem.I_PCTP]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.pctp[dm][m];
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_SM]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.moist[dm][m];
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_AVLW]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.avlh2o[dm][m];
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_RRUN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.rrun[dm][m];
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_SNWFAL]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.atms.snowfall[dm][m];
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_SNWPCK]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.snowpack[dm][m];
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_SRUN]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.srun[dm][m];
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_RGRW]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.rgrndh2o[dm][m];
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_SGRW]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.sgrndh2o[dm][m];
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_RPERC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.rperc[dm][m];
      }
    }
    else if (strcmp(predname[k],tem.predstr[tem.I_SPERC]) == 0)
    {
      for (dm = 0; dm < CYCLE; dm++)
      {
    days = daysnumber(dm,ttotyr[dyr][itype]);      for (m=0; m < days; m++)

	     tempred.dat[dm][m] = tem.soil.sperc[dm][m];
      }
    }
    //   printf("llc test  0225303,%i,%f,%f,%s,\n",dyr,col,row,predname[k]); //llctest
    // Write output data to files

    if (strcmp(predname[k],tem.predstr[tem.I_VSM]) == 0
        || strcmp(predname[k],tem.predstr[tem.I_PCTP]) == 0
        || strcmp(predname[k],tem.predstr[tem.I_FPC]) == 0
        || strcmp(predname[k],tem.predstr[tem.I_LEAF]) == 0)
    {
      tempred.poutdel(fout[i], col, row, predname[k],
                     tem.veg.temveg, tem.veg.cmnt,
                     (100.0 * tem.soil.psiplusc),
                     tem.qualcon[dyr][itype],
                     carea,
                     ttotyr[dyr][itype],
                     tempred.dat,
                     contnent);
    }
    else
    {
      tempred.outdel(fout[i], col, row, predname[k],
                     tem.veg.temveg, tem.veg.cmnt,
                     (100.0 * tem.soil.psiplusc),
                     tem.qualcon[dyr][itype],
                     carea,
                     ttotyr[dyr][itype],
                     tempred.dat,
                     contnent);
    }
    //  printf("llc test  0225304,%i,\n",dyr); //llctest
    
  }


};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************** */

int TEMelmnt::transqc(int& maxyears, long& totyr, Biomass plant[CYCLE][31])
{

  int i;
  int qc;
  int m, days;

  int year = 1992; // to deal with 29 days

  double sumcarbon = 0.0;
  qc = ACCEPT;

  if (totyr < 0 || totyr >= (long) maxyears) { return qc = 30; }

  for (i = 0; i < CYCLE; i++) {
      days = daysnumber(i,totyr);
      for (m=0; m < days; m++)
        sumcarbon += plant[i][m].carbon;
      }
  // "qc = 31" changed to "qc = TQCZEROFLAG" by DWK on 20000719
  if (sumcarbon <= 0.0) { return qc = TQCZEROFLAG; }

  return qc;

};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************** */

int TEMelmnt::veggisin(ofstream& flog1, int& ftlerr, const int& atmsflag,
		       const int& temflag, FILE* ftveg)
{

  int gisend;

  Vegdata tveg;

  gisend = tveg.getdel(ftveg);
  if (gisend == -1) { return gisend; }

  if (atmsflag == 0)
  {
    col = tveg.col;
    row = tveg.row;
  }
  else
  {
    ftlerr = coregerr(flog1,"CLOUDS", col, row, "TEMVEG", tveg.col, tveg.row);
  }

  strcpy(contnent, tveg.contnent);
  mez = tveg.temveg - 1;
  if (temflag == 1)
  {
    maxtype = tem.veg.numtype[mez];
    tem.veg.temveg = tveg.temveg;
  }
  if (mez < 0 || mez >= NUMVEG)
  {
    mez = 0;  // Added by DWK on 20000219
    maxtype = 1;
  }

  return gisend;

};

