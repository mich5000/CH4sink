/*****************************************************************
Methane Dynamics ---- Methane diffusion
Q. Zhuang, 11/March/2003
/***************************************************************** */

#if !defined(METHANEPLANT_H)
  #include "methaneplant.hpp"
#endif

// removing ch4 rate from soils by plants
double CH4DMPLANT::CH4plR(const double& tveg, const double& froot, const double& fgrow,
                    const double& ch4con )
{
double ch4plflxr;
const double kp  = 0.01; //  h-1

ch4plflxr = kp * tveg * froot * fgrow * ch4con;

//printf("tveg=%f,froot=%f,fgrow=%f,ch4con=%f,\n",tveg , froot , fgrow , ch4con);

 return ch4plflxr;

}

//calculate froot
double CH4DMPLANT::froot(const double& rootd, const double& z)
 {

 double froot;
 double rootdd; //llc
 rootdd = rootd * 1000.0; //convert to mm
 if (z <= rootdd) froot = 2 * (1 - z / rootdd);  //llc fix, rootd unit is meter
 else froot = 0.0;
// printf("z=%f,rootdd=%f,froot=%f,"z,rootdd,froot);
 return froot;

}

//calculate fgrow
double CH4DMPLANT::fgrow(const double& soilt)
 {

 const double amin = 0.0;
 const double a= 4.0;

 double fgrow;
 double tgr;
 double amax;
 double tmat;

 amax = amin + a;
 if (soilt < 5.0) tgr = 2.0;
 else tgr = 7.0;
 tmat = tgr + 10.0;

 if (soilt < tgr) fgrow = amin;
 if (tmat < soilt) fgrow = amax;
 if ((soilt <= tmat) & (soilt >= tgr)) fgrow = amin + a * (1 - pow((tmat - soilt)/ (tmat - tgr), 2.0));

 return fgrow;

}


/*
// get methane production ecd
void CH4DMDIF::getecdch4dif(char ecd[80])
{
  getch4dif(ecd);

}

void CH4DMDIF::getecdch4dif(ofstream& rflog1)
{

  char ecd[80];

  cout << "Enter name of the file with methane oxidation parameter values (.ECD):" << endl;
  fpara >> ecd;

  rflog1 << "Enter name of the file with methane oxidation parameter values (.ECD):";
  rflog1 << ecd << endl << endl;

  getch4dif(ecd);

};

void CH4DMDIF::getch4dif(char ecd[80])
{

  const int NUMVAR = 11;
  char dummy[35][40];
  ifstream infile;
  int i;
  int dcmnt;

  long update[35];

  infile.open(ecd, ios::in);

  if (!infile)
  {
    cerr << "\nCannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  for (i = 0; i < NUMVAR; i++) { infile >> dummy[i]; }
  for (dcmnt = 1; dcmnt < 35; dcmnt++)
  {
  infile >> dummy[dcmnt] >> dummy[dcmnt]>> omax[dcmnt] >> kc[dcmnt]>> och4q10[dcmnt]
            >> ko[dcmnt] >> afp[dcmnt] >> mvmax[dcmnt] >> mvmin[dcmnt] >> mvopt[dcmnt] >> update[dcmnt];

  }
  infile.close();

};


void CH4DMDIF::getch4dif(ofstream& rflog1) {

  const int NUMVAR = 11;
  char dummy[NUMVAR][40];
  ifstream infile;
  int i;
  int dcmnt;
  char ecd[20];

  int update[12];

  infile.open(ecd, ios::in);

  cout << "Enter name of methane oxidation (.ECD) data file with parameter values:" << endl;
  fpara >> ecd;

  rflog1 << "Enter name of methane oxidation(.ECD) data file with parameter values:" << ecd << endl << endl;

  infile.open(ecd, ios::in);

  if (!infile) {
    cerr << "\nCannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  for (i = 0; i < NUMVAR; i++) { infile >> dummy[i]; }
  for (dcmnt = 1; dcmnt < 35; dcmnt++)
  {
  infile >> dummy[0] >> dummy[0]>> omax[dcmnt] >> kc[dcmnt]>> och4q10[dcmnt]
            >> ko[dcmnt] >> afp[dcmnt] >> mvmax[dcmnt] >> mvmin[dcmnt] >> mvopt[dcmnt] >> update[dcmnt];
  }

  infile.close();

};
*/
