/*****************************************************************
Methane Dynamics ---- Methane diffusion
Q. Zhuang, 11/March/2003
/***************************************************************** */

#if !defined(METHANEEBU_H)
  #include "methaneebu.hpp"
#endif

//double CH4DMEBU::threshold(const double cmin, const double& punveg)
double CH4DMEBU::threshold(void)

 {

 double const cmin = 500.0; // 500 u M for totatly vegetated site
 double const punveg = 0.01; // percent of vegetated area of the site

 double ch4thresh;
// See Walter et al., 2001

  ch4thresh = cmin * ( 1 + punveg * 0.01);

 return ch4thresh;

}


double CH4DMEBU::CH4ebuR(const double& ch4con, const double& ch4thresh )

{
// times 24.0 to consider the conentration at the static state, then compared to threshold concentration
 const double ke = 1.0; // unit h-1
 double ch4ebuflx;
 double fsmzt;

  if (ch4con >= ch4thresh) fsmzt = 1.0;
  else fsmzt = 0.0;

  ch4ebuflx = ke * fsmzt * (ch4con  - ch4thresh); 

//  printf(" %3.2f", ch4ebuflx);

 return ch4ebuflx;

}


/*
// get methane production ecd
void CH4DMDIF::getecdch4dif(char ecd[80])
{
  getch4dif(ecd);

}

void CH4DMDIF::getecdch4dif(ofstream& rflog1)
{

  char ecd[80];

  cout << "Enter name of the file with methane oxidation parameter values (.ECD):" << endl;
  fpara >> ecd;

  rflog1 << "Enter name of the file with methane oxidation parameter values (.ECD):";
  rflog1 << ecd << endl << endl;

  getch4dif(ecd);

};

void CH4DMDIF::getch4dif(char ecd[80])
{

  const int NUMVAR = 11;
  char dummy[35][40];
  ifstream infile;
  int i;
  int dcmnt;

  long update[35];

  infile.open(ecd, ios::in);

  if (!infile)
  {
    cerr << "\nCannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  for (i = 0; i < NUMVAR; i++) { infile >> dummy[i]; }
  for (dcmnt = 1; dcmnt < 35; dcmnt++)
  {
  infile >> dummy[dcmnt] >> dummy[dcmnt]>> omax[dcmnt] >> kc[dcmnt]>> och4q10[dcmnt]
            >> ko[dcmnt] >> afp[dcmnt] >> mvmax[dcmnt] >> mvmin[dcmnt] >> mvopt[dcmnt] >> update[dcmnt];

  }
  infile.close();

};


void CH4DMDIF::getch4dif(ofstream& rflog1) {

  const int NUMVAR = 11;
  char dummy[NUMVAR][40];
  ifstream infile;
  int i;
  int dcmnt;
  char ecd[20];

  int update[12];

  infile.open(ecd, ios::in);

  cout << "Enter name of methane oxidation (.ECD) data file with parameter values:" << endl;
  fpara >> ecd;

  rflog1 << "Enter name of methane oxidation(.ECD) data file with parameter values:" << ecd << endl << endl;

  infile.open(ecd, ios::in);

  if (!infile) {
    cerr << "\nCannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  for (i = 0; i < NUMVAR; i++) { infile >> dummy[i]; }
  for (dcmnt = 1; dcmnt < 35; dcmnt++)
  {
  infile >> dummy[0] >> dummy[0]>> omax[dcmnt] >> kc[dcmnt]>> och4q10[dcmnt]
            >> ko[dcmnt] >> afp[dcmnt] >> mvmax[dcmnt] >> mvmin[dcmnt] >> mvopt[dcmnt] >> update[dcmnt];
  }

  infile.close();

};
*/
