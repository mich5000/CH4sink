/* **************************************************************
*****************************************************************
ATMS423.HPP - object describes physical characteristics of the
	      atmosphere

           - modified from atms41d.hpp by DWK 20000102


2001048 - Q. Z. Soil thermal model
20080117 - J.T. added transient atmospheric methane concentrations
*****************************************************************
************************************************************** */

// Class uses global constants CYCLE and MAXRTIME

#if !defined(DAATMS423_H)
#define DAATMS423_H
class Atmosphere
{

  public:

     Atmosphere();

/* **************************************************************
		 Public Functions
************************************************************** */


     void precsplt(double& prec, double& tair, double& rain, double& snowfall);
     double petjh(const double& nirr, const double& tair, const int& dm);
     // this is for 3-layer model
     double new_petjh(const double& nirr, const double& tair, const int& dm);
     double xeet(const double& rain, const double& snowinf, const double& pet, const double& avlh2o, const double& awcapmm, const int& dm);



/* **************************************************************
		 Public Variables
************************************************************** */

// Gaseous components of air

     double initco2;               // initial CO2 concentration (ppmv)
     double co2level;              // constant CO2 concentration (ppmv)
     double co2[CYCLE][31];            // variable CO2 concentration (ppmv)
     double tco2[MAXRTIME][CYCLE][31]; // transient CO2 concentration (ppmv)
     long co2year[MAXRTIME];       // year of CO2 data

	 double initch4;
	 double ch4level;
	 double ch4[CYCLE][31];
	 double tch4[MAXRTIME][CYCLE][31]; //transient CH4 concentration (uM)
	 long ch4year[MAXRTIME];

 //  Light Variables

     double girr[CYCLE][31];        // Gross Irradiance (cal/(sq. cm * day))
     double nirr[CYCLE][31];        // Net Irradiance   (cal/(sq. cm * day))
     double nirr1[CYCLE][31];        // Net Irradiance   (cal/(sq. cm * day))
     double par[CYCLE][31];         // Photosynthetically Active Radiation
     double par1[CYCLE][31];         // Photosynthetically Active Radiation
				      // (cal/(sq.cm * day))

    double GISlai[CYCLE][31];  // LAI (m3/m3) from GIS and remote sensing data 19/02/2002 Q. Z.
    double tGISlai[MAXRTIME][CYCLE][31];  // LAI from GIS and remote sensing data 19/02/2002 Q. Z.
    long GISlaiyear[MAXRTIME];  // LAI from GIS and remote sensing data 19/02/2002 Q. Z.
    double yrGISlai;             // Annual sum of total LAI
    double yrtGISlai[MAXRTIME];

    double mxGISlai;             // Maximum monthly LAI
    double mxtGISlai[MAXRTIME];

 //   Evapotranspiration Variables

     double pet[CYCLE][31];         // Potential Evapotranspiration (mm)
     double eet[CYCLE][31];         // Estimated Actual Evapotranspiration (mm)

	 // added for three-layer hydrological model, Q. Zhuang, 05/Jan/2003
     double pet3[CYCLE][31];         // Potential Evapotranspiration (mm) for three-layer model
     double eet3[CYCLE][31];         // Estimated Actual Evapotranspiration (mm) for three-layer model

//   Climatic Variables

     double tair[CYCLE][31];        // Surface Air Temperature (degrees C)
     double ttair[MAXRTIME][CYCLE][31];
     long tairyear[MAXRTIME];       // year of air temperature data

//llc for wetland
     double stw[CYCLE][31];        // standing water
     double tstw[MAXRTIME][CYCLE][31];
     long stwyear[MAXRTIME];       // year of standing water

  //llc for wetland
     double sg_frin[CYCLE][31];        // inundation
     double tsg_frin[MAXRTIME][CYCLE][31];
     long sg_frinyear[MAXRTIME];       

     double frontd[CYCLE][31],thawbe[CYCLE][31],thawend[CYCLE][31]; // front frozen depth
     double tsoil[CYCLE][31];       // Top 20cm soil temperature (degrees C)
     double dst5[CYCLE][31],dst10[CYCLE][31],dst20[CYCLE][31],dst50[CYCLE][31],dst100[CYCLE][31],dst200[CYCLE][31]; // for different depth soil temperature

     double clds[CYCLE][31];        // Cloudiness (%)
     double tclds[MAXRTIME][CYCLE][31];
     long cldsyear[MAXRTIME];       // year of cloudiness data

 //    double sun[CYCLE];         // percent sunshine duration

     double  prec[CYCLE][31];       // Total Precipitation (mm)
     double  tprec[MAXRTIME][CYCLE][31];
     long precyear[MAXRTIME];       // year of precipitation data

     double  snowfall[CYCLE][31];   // Snow (mm)
     double  rain[CYCLE][31];       // Rainfall (mm)

     double prevtair;           // Previous Month's Air Temperature
				//   (degrees C)
     double prev2tair;          // Previous 2 Month's Air Temperature
				//   (degrees C)

     double prvpetmx;           // Maximum PET of previous year
     double prveetmx;           // Maximum EET of previous year

     double avetair;            // Mean annual air temperature (degrees C)
     double mxtair;             // Maximum monthly air temperature (degrees C)
     double mxttair[MAXRTIME];
     double yrprec;             // Annual sum of total precipitation (mm)
     double yrtprec[MAXRTIME];
     double yrrain;             // Annual sum of rainfall (mm)
     double yrpet;              // Annual sum of potential evapotranspiration (mm)
     double yreet;              // Annual sum of estimated actual evapotranspiration (mm)
     double yrsnowfall;         // Annual sum of snow

  // added for 3-layer model
     double yrpet3;              // Annual sum of potential evapotranspiration (mm)
     double yreet3;              // Annual sum of estimated actual evapotranspiration (mm)

     double yrfrontd,yrthawbegin,yrthawend; // for soil thermal model
     double yrtsoil; // for soil temperature
     double yrdst5; // for soil temperature
     double yrdst10; // for soil temperature
     double yrdst20; // for soil temperature
     double yrdst50; // for soil temperature
     double yrdst100; // for soil temperature
     double yrdst200; // for soil temperature

     int tco2flag;
     int ttairflag;
     int tstwflag; //llc for wetland
  int tsg_frinflag; //llc for wetland
     int tprecflag;
     int tcldsflag;
     int tlaiflag;  //flag for LAI, to read in GIS data or not
	 int tch4flag;

 // private:      // changed private into public by Q. Z. for soil thermal model

/* **************************************************************
		      Private Variables
************************************************************** */

     double daze[CYCLE];          // number of days per month
     // the above variable will not be useful for the daily version, Q. Zhuang
};

#endif
