/*
  All constant and public variables for wetland methane modules

  Added by llc 10/18/2016
*/

#if !defined(WM_VARIABLES_H)
#define WM_VARIABLES_H
#endif

class WCH4_V{

public:

  double CalcSatVP(double T);
  double CalcSpecificHumidity(double T);
  double CalcThermalRadiation(double Ta, double vp, double cloud);
  double CalcLatentHeat(double vp, double Tw, double wind);
  double CalcSensibleHeat(double Ta, double Tw, double wind);
  void CalcEddyDiffusivity(double temp[], double depth[],double wind, double lat,double k_eddy[],double density[],double frequency[]);
  void CalcWaterDensity(double temp[],double density[]);
  void CalcBruntVaisalaFreq(double density[],double depth[],double frequency[]);
  int SolveCubicEquation(double x[], double a, double b, double c);
  double CalcHenrySolubility(int gas, double temp);
  double mean1d(double var[], int begin, int end);
  double GetGasPercentage(int gas);
  double CalcPistonVelocity(int gas, double temp, double wind);
  double CalcSchmidtNumber(int gas, double temp);
  
  double sedGasCon[NSLAYER][NSGAS];  //sediment gas profile
  double waterGasCon[NWLAYER][NGAS];  //water gas profile
  double gasExchange[NWLAYER][NGAS];
  double Twater[NWLAYER];  //water temperature profile
  double Tsed[NSLAYER];  //sediment temperature profile
  void Initialize(double Porosity);
  double Zw[NWLAYER]; //deepth of each layer m
  double Zs[NSLAYER]; //deepth of each layer m
  double Az[NWLAYER]; //area of lake cross section
  double tmpKw[NWLAYER]; // temporary water diffusivity vector (m2/s)
  int lakeWaterTopIndex; //lake free water top index
  static int matter_water;
  static int matter_soil;
  static int sed_ch4;
  static int sed_n2;
  static int gas_ch4;
  static int gas_n2;
  static int gas_o2;
  static int gas_co2;
  static double Roul;
  static double Roui;
  static double Cpl;
  static double Cpi;
  static double T0;
  static double e8;// Real infinitestimal value
  static double inft; //Infinitesimal number
  static double inf; //Infinite number
  static double Karman;
  static double prandtl;
  static double Kpt;
  static double Kw0;
  static double Ki0;
  static double Pi;
  static double P0;
  static double Roua;
  static double Lv;
  static double Ce;
  static double Cpa;
  static double Ch;
  static double Elw;
  static double Stefan;
  static double eps;
  static double MasN2;
  static double MasO2;
  static double MasCO2;
  static double MasCH4;
  static double Xn2;
  static double Xo2;
  static double Xco2;
  static double Xch4;
  static double SOLO2[11]; //O2 solubility from Engineering toolbox (mg/L)
  static double Ae;
  static double G;
  static double Gastol[4]; //tolerance of water gas concentration (unit: umol/m3)
  static double Tor;//  CH4 oxidation Reference temperature (K)
};

int WCH4_V::matter_water = 0;
int WCH4_V::matter_water = 1;
int WCH4_V::sed_ch4 = 1;
int WCH4_V::sed_n2 = 0;
int WCH4_V::gas_ch4 = 3;
int WCH4_V::gas_n2 = 0;
int WCH4_V::gas_o2 = 1;
int WCH4_V::gas_co2 = 2;
double WCH4_V::Roul = 1000.0;
double WCH4_V::Roui = 931.0;
double WCH4_V::Cpl = 4200.0;
double WCH4_V::Cpi = 2100.0;
double WCH4_V::T0 = 273.15;
double WCH4_V::e8 = 1.0e-8;
double WCH4_V::inft = 1.0e-30;
double WCH4_V::inf = 1.0e30;
double WCH4_V::Karman= 0.4;
double WCH4_V::prandtl= 1.0;
double WCH4_V::Kpt= 0.25;
double WCH4_V::Kw0=0.558;
double WCH4_V::Ki0=2.2156;
double WCH4_V::Pi=3.1415926;
double WCH4_V::P0=1.01325e5;
double WCH4_V::Roua=1.225;
double WCH4_V::Lv=2.26e6;
double WCH4_V::Ce=1.75e-3;
double WCH4_V::Cpa=1.006e3;
double WCH4_V::Ch=1.75e-3;
double WCH4_V::Elw=0.97;
double WCH4_V::Stefan=5.6704e-8;
double WCH4_V::eps=1e-14;
double WCH4_V::MasN2=28.0;
double WCH4_V::MasO2=32.0;
double WCH4_V::MasCO2=44.0;
double WCH4_V::MasCH4=16.0;
double WCH4_V::Xn2=0.78;
double WCH4_V::Xo2=0.21;
double WCH4_V::Xco2=380.0e-6;
double WCH4_V::Xch4=1800.0e-9;
double WCH4_V::SOLO2[11] = {14.6,12.8,11.3,10.1,9.1,8.3,7.6,7,6.5,6,5.6};
double WCH4_V::Ae=0.4;
double WCH4_V::G=9.8;
double WCH4_V::Gastol[4] = {0.1,0.1,0.01,0.0001};
double WCH4_V::Tor = 267.65;

