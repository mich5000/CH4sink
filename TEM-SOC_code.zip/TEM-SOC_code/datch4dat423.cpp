/* **************************************************************
DATCH4DAT423.CPP - object to read and write the structure of transient
               atmospheric CH4 data from/to files used by the
               Terrestrial Ecosystem Model (TEM)

              20080118 J.T created the file
************************************************************** */

#if !defined(DATCH4DAT423_H)
  #include "datch4dat423.hpp"
#endif

/* *************************************************************
************************************************************* */

CH4data::CH4data(void)
{

  ch4end = 1;
  lagpos = -99;
  curpos = 0;

};

/* **************************************************************
                    Public Functions
************************************************************** */

int CH4data::get(ifstream& infile)
{

  lagpos = infile.tellg();

  infile >> year >> mch4;

  infile.seekg(0, ios::cur);
  curpos = infile.tellg();

  if (curpos < (lagpos + 5)) { ch4end = -1; }

  return ch4end;

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

int CH4data::getdel(FILE* infile)
{

  ch4end = fscanf(infile, "%f,%lf", &year, &mch4);

  return ch4end;

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

void CH4data::out(ofstream& ofile, float& year, double& mch4)
{

  ofile.setf(ios::fixed,ios::floatfield);
  ofile.setf(ios::showpoint);
  ofile.precision(1);

  ofile << year << ' ';
  ofile << setprecision(4) << mch4;
  ofile << endl;


};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

void CH4data::outdel(ofstream& ofile, float& year, double& mch4)
{

  ofile.setf(ios::fixed,ios::floatfield);
  ofile.setf(ios::showpoint);
  ofile.precision(1);

  ofile << year << ",";
  ofile << setprecision(4) << mch4;
  ofile << endl;

};

