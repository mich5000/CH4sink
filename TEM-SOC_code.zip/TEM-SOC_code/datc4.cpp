/* **************************************************************
datph.CPP - object to read and write the structure of pH
               data from/to files
************************************************************** */

#if !defined(DATC4_H)
  #include "datc4.hpp"
#endif

/* *********************************************************** */

C4data::C4data(void)
{

  elvend = 1;
  lagpos = -99;
  curpos = 0;

};

/* **************************************************************
                    Public Functions
************************************************************** */

/* *************************************************************
************************************************************* */

int C4data::get(ifstream& infile)
{

  lagpos = infile.tellg();

  infile >> col >> row;
  infile >> varname;
  infile >> carea;
  infile >> C4;
  infile >> contnent;

  infile.seekg(0, ios::cur);
  curpos = infile.tellg();

  if (curpos < (lagpos + 10)) { elvend = -1;}

  return elvend;

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

int C4data::getdel(FILE* infile)
{

  elvend = fscanf(infile,"%f,%f, %s ,%d,%lf, %s",
                  &col,&row,varname,&carea,&C4,contnent);
                 
  return elvend;

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

void C4data::out(ofstream& ofile, float col, float row, char varname[9],
                   int carea, double C4, char contnent[9])
{

  ofile.setf(ios::fixed,ios::floatfield);
  ofile.setf(ios::showpoint);
  ofile.precision(1);

  ofile << col << ' ' << row << ' ';
  ofile << varname << ' ';
  ofile << setprecision(0) << carea << ' ';
  ofile << setprecision(1) << C4 << ' ';
  ofile << contnent;
  ofile << endl;

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

void C4data::outdel(ofstream& ofile, float col, float row, char varname[9],
                      int carea, double C4, char contnent[9])
{

  ofile.setf(ios::fixed,ios::floatfield);
  ofile.setf(ios::showpoint);
  ofile.precision(1);

  ofile << col << "," << row << ", ";
  ofile << varname << " ,";
  ofile << setprecision(0) << carea << ",";
  ofile << setprecision(1) << C4 << ", ";
  ofile << contnent;
  ofile << endl;

};

