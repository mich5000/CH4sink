/*********************************************************
**********************************************************
sedimentthermal.hpp
Object describing thermal transport in sediment below water, specifically
for wetlands, rivers and lakes. Similar to method of Zeli Tan
2015 JAMES paper. 
Added by L. Liu, July 18 2016

**********************************************************
*********************************************************/
#if !defined(CKRUNGEKUTTA_H)
#include "ckrungekutta.cpp" //ck runge kutta calculation
#endif

#if !defined(SEDIMENTTHERMAL_H)
#define SEDIMENTTHERMAL_H
#endif

#if !defined(WM_VARIABLES_H)
#include "wm_variables.cpp" // variables input
#endif


class SEDTHERMAL : public CKRUNGEKUTTA {

public:

  WCH4_V wm;

  void Sedmain(double Ttop,double Rous, double Cps, double Porosity, double Kss, double seddepth);

  virtual void derivs(double x, double temp[], double dtemp[]);
  void CalcSedTopBottomHeatFlux(double Ttop);
  double CalcHeatConductivity(double T, double theta, double itheta, double Kss, double Farouki);
  void preset(double Porosity, double seddepth);
  double Ks[NSLAYER]; //total heat diffusivity (m2/s)
  double Cvt[NSLAYER]; //volumetric heat capacity (J/K/m3)
  double btmflux; //bottom boundary heat flux
  double topflux; //top boundary heat flux
  double Farouki; 

};





