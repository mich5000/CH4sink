/*****************************************************************
Methane Dynamics ---- Methane oxidation within production soils
Q. Zhuang, 01/NOv/2003
/***************************************************************** */

#if !defined(PMETHANEOXI_H)
  #include "pmethaneoxi.hpp"
#endif

// Methane oxidation occurred between the soil surface and the water table
// the soil column is devided as 1 cm depth interval
double PCH4DMOXI::MethaneOR(const double& omax, const double& fmc, const double& foxy, const double& fst,
              const double& fsm, const double& frx, const double& fct )
 {
 double methaneor; // rate of methane oxidation rate at depth z and time t
// double omax; maximum methane oxidation rate, uMh-1; 5-50 [Dunfield et al., 1993; Knoblauch, 1994
// Krumholz et al., 1995; Moore and Dalva, 1997; Sundh et al., 1994; Watson et al., 1997]
// Walter et al. 2000 set omax as 20 uMh-1

  methaneor = omax * fmc * foxy * fst * fsm * frx * fct;
  
 return methaneor;
 }

// Effects of methane concentration to methanotrophic reaction
double PCH4DMOXI::EffectMC(const double& ch4con, const double& kc)
{
 double fmc;
 // Kc is Michaelis-Menten coefficient. (Walter et al., 2000; Bender and Conrad, 1992)
 // Walter et al. 2000 set kc as 5uM
 // ch4con is soil methane concentration at depth z and time t

 fmc = ch4con / (kc + ch4con);

 return fmc;
}

// Effects of oxygen concentration to oxidation
double PCH4DMOXI::EffectOXY(const double& oxyc, const double& ko)
{

 double foxy;
 double kk;
// Ko is Michaelis-Menten coefficient, typical value ranged from 37 to 200 uM as concentration
// oxyc denotes the oxygen concentration in the soil
 kk = ko * 32 / pow(10,3);
 foxy = oxyc / (kk + oxyc);

 return foxy;
}

// Effects of soil temperature to methanogenesis
double PCH4DMOXI::EffectST(const double& soilt, const double& och4q10, const double& oxiref)
{
  double fst;
 // double tref = 23.0; // reference soil temperature for methanogenesis,
 // TSOIL(z,t) is the soil temperature at depth z and time t.
 // tref is the reference soil temperature (oC) (e.g. 23oC).
 //och4q10  is a coefficient with a constant, Walter et al., set it as 2.0; the values is between 1.4 and 2.1 according to
 //Dunfield et al., 1993; Knoblauch, 1994

  fst = pow (och4q10, (soilt - oxiref) / 10.0);
   if (soilt < 0.0) fst =0.0;  // to limit the oxidation 20 Oct 2003

  return fst;

}

//soil moisture on methane oxidation
/*
// Potter et al., 1993; Ridgwell et al., 1999
double CH4DMOXI::EffectSM(const double& rainthrough, const double& snowmelt, const double& et, const double& soilm)
{
// rainthrough, rain throughfall
//snowmelt, snow melt
//et, evaporatranspiration
//soilm, soil moisture

 double fsm;
 double temp;
 double ratio;
 temp = rainthrough + snowmelt + soilm;
 ratio = temp / et;

 if (ratio > 1.0) fsm =1.0;
 else fsm = ratio;

 return fsm;

}
*/
// Similar to TEM for the heterotrophic respiration Tian et al.,
double PCH4DMOXI::EffectSM(const double& mvmin, const double& mvmax, const double& mvopt, const double& soilm)
 {

 double fsm;
 double temp1;
 double temp2;
 temp1 = (soilm - mvmin) * ( soilm - mvmax);
 temp2 = pow( (soilm - mvopt), 2.0);
 fsm = temp1 / (temp1 - temp2);

 return fsm;

 }


// Effects of soil redox potential to methanotrophy
// Follow Zhang et al., 2001
double PCH4DMOXI::EffectRX(const double& ehl)
{
 double frx;

 if ((ehl <= -100.0) && (ehl >= -200))  frx = 0.0075 * ehl + 1.5;
 if ((ehl > -100.0) && (ehl <= 200.0))  frx = 0.00083 * ehl + 0.833;
 if ((ehl > 200) && (ehl <= 600)) frx = 1.0;

 return frx;
}

//effects of agricultural intensification
//According to Ridgwell et al., 1999
double PCH4DMOXI::EffectCT(const double& icul)
{
 double fct;
 double temp;
// ICUL is the fractional intensity of cultivation (Matthews, 1983)
 if ((icul >5) || (icul < 1)) temp = 0.0;
 else
  {
    if (icul ==1) temp = 0.0;
    if (icul ==2) temp = 0.2;
    if (icul ==3) temp = 0.5;
    if (icul ==4) temp = 0.75;
    if (icul ==5) temp = 1.0;
 }
 fct = 1.0 - 0.75 * temp;

 return fct;
}

// calculate the oxygen concentration
void PCH4DMOXI::oxygenC(const double& afp, const double& lowb)

{
// double afp; // air filled porosity of the soil;
 const int MAXN = 400; //maximum nodes
 int nodes; // number of nodes, which is related to low boundary (lowb)
 const double x = 0.001; // depth step 10mm or 1cm
 const double aoc = 280.0; // atmospheric oxygen concentration (280 gm-3)
 const double k_zero = 0.01; // the atmospheric boundary layer conductance (k(0))
 const double d0 = 0.0000177; // binary diffusion coefficients for O2 (m2s-1) (Campbell, 1977)
 const double cb = 0.90; // constant b, Sallam et al., 1984
 const double cm = 2.36; // constant m, Sallam et al., 1984
 const double azs = 0.0005; // soil surface O2 uptake rate

 double a[MAXN],b[MAXN],c[MAXN], d[MAXN], u[MAXN];
 double k[MAXN]; // conductivity
 double co[MAXN]; //concentration
 double z[MAXN]; //depth
 double df[MAXN];//diffusion
 int i;

 nodes = int (ceil(lowb / 10.0));

 z[0] = 0.0;

 for (i = 0; i < nodes+1; i++)
  {
   z[i+1] = z[i] + x;
  }

 k[0] = k_zero;
 co[0] = aoc;

 for (i =1; i < nodes+1; i++)
  {
//   z[i+1] = z[i] + x;
   df[i] = d0 * cb * pow(afp,cm);
   u[i] = azs * exp(-z[i] / 0.3) * (z[i+1] -z[i-1])/2.0;
   if (i < nodes+1) k[i] = df[i] / (z[i+1] - z[i]);
   else k[i] =0.0;
   a[i+1] = -k[i];
   b[i] = k[i-1] + k[i];
   c[i] = -k[i];
   d[i] = u[i];
  }

  d[1] = d[1] + k[0] * co[0];
  for (i=1; i < nodes; i++)
   {
    c[i] = c[i] /b[i];
    d[i] = d[i] / b[i];
    b[i+1] = b[i+1] -a[i+1]*c[i];
    d[i+1] = d[i+1] -a[i+1]*d[i];
    }

  co[nodes]= d[nodes]/b[nodes];

  for (i = nodes; i > 0; i--)
   {
    co[i] = d[i] - c[i] * co[i+1];
//    co[i] = co[i] / (32.0 * pow(10,3));   // coverse gm-3 to M;  (32 * pow(10,3) g / pow(10,6)cm = 1 M
//    co[i] = co[i] * pow(10,6); //converse M to micro M (uM)
    oxygenc[i] = co[i];

   }
}


// get methane production ecd
void PCH4DMOXI::getecdch4oxi(char ecd[80])
{
  getch4oxi(ecd);

}

void PCH4DMOXI::getecdch4oxi(ofstream& rflog1)
{

  char ecd[80];

  cout << "Enter name of the file with methane p-oxidation parameter values (.ECD):" << endl;
  fpara >> ecd;

  rflog1 << "Enter name of the file with methane p-oxidation parameter values (.ECD):";
  rflog1 << ecd << endl << endl;

  getch4oxi(ecd);

};

void PCH4DMOXI::getch4oxi(char ecd[80])
{

  const int NUMVAR = 12;
  char dummy[35][40];
  ifstream infile;
  int i;
  int dcmnt;

  long update[35];

  infile.open(ecd, ios::in);

  if (!infile)
  {
    cerr << "\nCannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  for (i = 0; i < NUMVAR; i++) { infile >> dummy[i]; }
  for (dcmnt = 1; dcmnt < 15+1; dcmnt++) //LLC for calibrated parameters
  {
  infile >> dummy[dcmnt] >> dummy[dcmnt]>> omax[dcmnt] >> kc[dcmnt]>> och4q10[dcmnt]
            >> ko[dcmnt] >> afp[dcmnt] >> mvmax[dcmnt] >> mvmin[dcmnt] >> mvopt[dcmnt] >> oxiref[dcmnt] >> update[dcmnt];
  
  poxi_para[dcmnt][1]=omax[dcmnt];//LLC for calibrated parameters
  poxi_para[dcmnt][2]=kc[dcmnt];
  poxi_para[dcmnt][3]=och4q10[dcmnt];
  poxi_para[dcmnt][4]=ko[dcmnt];
  poxi_para[dcmnt][5]=afp[dcmnt];
  poxi_para[dcmnt][6]=mvmax[dcmnt];
  poxi_para[dcmnt][7]=mvmin[dcmnt];
  poxi_para[dcmnt][8]=mvopt[dcmnt];
  poxi_para[dcmnt][9]=oxiref[dcmnt];
  }
  infile.close();

};


void PCH4DMOXI::getch4oxi(ofstream& rflog1) {

  const int NUMVAR = 12;
  char dummy[NUMVAR][40];
  ifstream infile;
  int i;
  int dcmnt;
  char ecd[20];

  int update[12];

  infile.open(ecd, ios::in);

  cout << "Enter name of methane p-oxidation (.ECD) data file with parameter values:" << endl;
  fpara >> ecd;

  rflog1 << "Enter name of methane p-oxidation(.ECD) data file with parameter values:" << ecd << endl << endl;

  infile.open(ecd, ios::in);

  if (!infile) {
    cerr << "\nCannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  for (i = 0; i < NUMVAR; i++) { infile >> dummy[i]; }
  for (dcmnt = 1; dcmnt < 15+1; dcmnt++) //LLC for calibrated parameters
  {
  infile >> dummy[0] >> dummy[0]>> omax[dcmnt] >> kc[dcmnt]>> och4q10[dcmnt]
            >> ko[dcmnt] >> afp[dcmnt] >> mvmax[dcmnt] >> mvmin[dcmnt] >> mvopt[dcmnt] >> oxiref[dcmnt] >> update[dcmnt];
    poxi_para[dcmnt][1]=omax[dcmnt];//LLC for calibrated parameters
  poxi_para[dcmnt][2]=kc[dcmnt];
  poxi_para[dcmnt][3]=och4q10[dcmnt];
  poxi_para[dcmnt][4]=ko[dcmnt];
  poxi_para[dcmnt][5]=afp[dcmnt];
  poxi_para[dcmnt][6]=mvmax[dcmnt];
  poxi_para[dcmnt][7]=mvmin[dcmnt];
  poxi_para[dcmnt][8]=mvopt[dcmnt];
  poxi_para[dcmnt][9]=oxiref[dcmnt];
  }

  infile.close();

};

