/* **************************************************************
*****************************************************************
TELM423.HPP - Runs TEM for a single grid cell

Modifications:
   Q. Zhuang, Daily version, STM and HM Jan/04/2003
*****************************************************************
************************************************************** */

//Modules representing climate and TEM

#if !defined(DAPOTCLM423_H)
  #include "dapotclm423e.cpp"       // TEMelmnt uses the Potsclm class
#endif

#if !defined(DATTEM423E1_H)
  #include "dattem423e1.cpp"      // TEMelmnt uses the TTEM class
#endif

//Modules describing the interface with spatially explicit data sets

#if !defined(DATCLMDAT423_H)
  #include "datclmdat423.cpp"  //TEMelmnt uses the Clmdata class
#endif

#if !defined(DATVEGDAT423_H)
  #include "datvegdat423.cpp"  //TEMelmnt uses the Vegdata class
#endif

#if !defined(DATSOLDAT423_H)
  #include "datsoldat423.cpp"  //TEMelmnt uses the Soildata class
#endif

#if !defined(DATELVDAT423_H)
  #include "datelvdat423.cpp"  //TEMelmnt uses the Elevdata class
#endif

// for wetland and fraction inudation
#if !defined(WETLAND_H)
  #include "wetland.cpp"  //TEMelmnt uses the wetland class
#endif

#if !defined(finudation_H)
  #include "finudation.cpp"  //TEMelmnt uses the fraction inundation class
#endif

#if !defined(fcult_H)
  #include "fcult.cpp"  //TEMelmnt uses the cultivation class
#endif

// added for reading pH value
#if !defined(DATPH_H)
  #include "datph.cpp"  //TEMelmnt uses the Phdata class
#endif

// added for isotope youmi oh
#if !defined(DATTOC_H)
  #include "dattoc.cpp"  //TEMelmnt uses the Phdata class
#endif

#if !defined(DATC4_H)
  #include "datc4.cpp"  //TEMelmnt uses the Phdata class
#endif


#if !defined(DALULCDAT423_H)
  #include "dalulcdat423.cpp"  //TEMelmnt uses the Lulcdata class
#endif

#if !defined(DATTEMDAT423_H)
  #include "dattemdat423.cpp"  //TEMelmnt uses the Temdata class
#endif

#if !defined(DATKDDAT423_H)
  #include "datkddat423.cpp"   //TEMelmnt uses the KDdata class
#endif

#if !defined(DALATDAT423_H)
  #include "dalatdat423.cpp"   //TEMelmnt uses the Latdata class
#endif

#ifndef DATELM423E1_H
#define DATELM423E1_H

// Following global constant added by DWK on 20000719 to flag
// when long-term environmental conditions of a grid cell cannot
// support life
const int TQCZEROFLAG = 31;

class TEMelmnt {

  public:

     TEMelmnt();

/* *************************************************************
		 Public Function Declarations
************************************************************* */

     int atmsgisin(FILE* fclds, const int& cldflag, FILE* flonlat,
                   const int& lonlatflag, const int& numspin,
                   const int& spintime, const int& RTIME);
     void atmswritemiss(ofstream fout[NUMATMS], char predname[MAXPRED][9],
                        const int& dyr, const int& natmspred,
                        const double value);
     void atmswritepred(ofstream fout[NUMATMS], char predname[MAXPRED][9],
                        const int& dyr, const int& natmspred);
     void GISsetELMNTstate(const int& ez, Temdata initstat[NUMMSAC][MAXSTATE+1]);
     void runtem(ofstream& rflog1, char predmap[MAXPRED][9],
                 const int& cldflag, const int& atmsflag,
                 const int& atmsoutfg, int& natmspred,
                 ofstream fsradout[NUMATMS],
                 const int& temflag, const int& kdinflg,
                 int& ntempred, ofstream ftemout[MAXPRED],
                 const int& stateflag,
                 const int& equil, const int& totsptime,
                 const int& RTIME);

    //added fvap for hydrology model by QZ

     int temgisin(ofstream& flog1, int& ftlerr, const int& atmsflag,
		  const int& itype, const int& maxtype, const int& kdinflg,
                  const int& stateflag,
		  FILE* fstxt, FILE*felev, FILE* fph, FILE* ftoc, FILE* fc4, FILE* fwetld, FILE* finuda, FILE* fcult, FILE* fnirr, FILE* fpar, FILE* flai,
		  FILE* ftair, FILE* fstw,FILE* fsg_frin, FILE* fprec, FILE* fvap, FILE* flulc, FILE* fnpp,
                  FILE* fkdin, FILE* fstate[MAXSTATE+1],
		  const int& numspin, const int& spintime, const int& RTIME);  //llc for wetland
        void temwritemiss(ofstream fout[MAXPRED], char predname[MAXPRED][9],
                            const int& dyr, const int& itype,
                            const int& natmspred, const int& ntempred,
                            const double value);
     void temwritepred(ofstream fout[MAXPRED], char predname[MAXPRED][9],
                       const int& dyr, const int& itype,
                       const int& ntempred, const int& natmspred);
     int veggisin(ofstream& flog1, int& ftlerr, const int& atmsflag,
		  const int& temflag, FILE* ftveg);

     float col;
     float row;
     int lonlatflag;
     int clds_dflag;//llc
     int tair_dflag;
     int prec_dflag;
     int vapor_dflag;
     int stw_dflag;
     double lon;
     double lat;
     int carea;
     char contnent[9];

     int mez;
     int maxtype;

     int outyr;
     int itype;

     long atmstotyr[MAXRTIME];
     long ttotyr[MAXRTIME][NUMMSAC];

     Potsclm clm;
     TTEM tem;


/* *************************************************************
		 Private Function Declarations
************************************************************* */

  private:

     int coregerr(ofstream& rflog1, char varname1[9], const float& col1,
		  const float& row1, char varname2[9], const float& col2,
		  const float& row2);
     int loadteclds(FILE* fclds, Clmdata clds, const int& numspin,
                    const int& spintime, const int& RTIME);
     int loadtelulc(FILE* flulc, Lulcdata lulc, const int& numspin,
                    const int& spintime, const int& RTIME, int& ftlerr,
		    ofstream& flog1);
//     int loadtenpp(FILE* fnpp, Temdata npp, const int& maxtype,
//                   const int& RTIME, int& ftlerr, ofstream& flog1);

     int loadtenpp(FILE* fnpp, Temdata npp, const int& maxtype,
                         const int& numspin, const int& spintime,
                         const int& RTIME, int& ftlerr, ofstream& flog1);

     int loadteprec(FILE* fprec, Clmdata prec, const int& numspin,
                    const int& spintime, const int& RTIME, int& ftlerr,
		    ofstream& flog1);

               // addition for reading in LAI 19/02/2002
     int loadtelai(FILE* flai, Clmdata GISlai, const int& numspin,
                    const int& spintime, const int& RTIME, int& ftlerr,
		    ofstream& flog1);

     int loadtetair(FILE* ftair, Clmdata tair, const int& numspin,
                    const int& spintime, const int& RTIME, int& ftlerr,
		    ofstream& flog1);

     int loadtestw(FILE* fstw, Clmdata stw, const int& numspin,
                    const int& spintime, const int& RTIME, int& ftlerr,
		    ofstream& flog1); //llc for wetland

       int loadtesg_frin(FILE* fsg_frin, Clmdata sg_frin, const int& numspin,
                    const int& spintime, const int& RTIME, int& ftlerr,
		    ofstream& flog1); //llc for wetland

// added for hydrological model

     int loadvap(FILE* fvap, Clmdata vap, const int& numspin,
                  const int& spintime, const int& RTIME, int& ftlerr,
		    ofstream& flog1);

     int temgisqc(const int& stateflag, const double& pctsilt,
                  const double& pctclay, const int& cmnt, const double& elev,
                  double nirr[CYCLE][31], double par[CYCLE][31],
		  double tair[CYCLE][31], double& mxtair,
                  double prec[CYCLE][31], double& yrprec,
		  Temdata initstat[NUMMSAC][MAXSTATE+1]);
     int transqc(int& maxyears, long& totyr, Biomass plant[CYCLE][31]);


// *************************************************************

     Temdata initstat[NUMMSAC][MAXSTATE+1];

     int qc;
     int lowtair;
     int noprec;

           //added for hydrological model
     int lowvap;
     int novap;
     int lowGISlai; // for LAI 19/02/2002


};

#endif

