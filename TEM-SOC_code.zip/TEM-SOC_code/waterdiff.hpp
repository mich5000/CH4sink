/*
!---------------------------------------------------------------------------------
! Purpose: this module governs the concentration of four gases (N2, O2, CO2, CH4) 
!          in the water, which is mainly from Tang's thesis and "Numerical modeling
!          of methane emissions from lakes in the permafrost zone" [V. Stepanenko, 2011]
!
!---------------------------------------------------------------------------------
 */
#if !defined(WATERDIFF_H)
#include "WATERDIFF.hpp"
#endif

#if !defined(CKRUNGEKUTTA_H)
#include "ckrungekutta.cpp" //ck runge kutta calculation
#endif

#if !defined(WM_VARIABLES_H)
#include "wm_variables.cpp" // variables input
#endif

class WATERDIFF : public CKRUNGEKUTTA {
public:
  double Kg[NWLAYER];//gas diffusivity (eddy+molecular)
  double Kt[NGAS];//gas transfer velocity
  double Rox[NWLAYER][NGAS];//gas oxidation (umol/(m3*s)
  double Vax_CH4[NWLAYER];//gas oxidation auxiliary vector
  double srfflux[NGAS];// gas surface flux
  double btmflux[NGAS];// gas bottom flux
  double oxyratio; //trophic ratio
  int oxycline; // oxycline index
  
};
