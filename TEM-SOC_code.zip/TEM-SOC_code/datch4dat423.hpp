/* **************************************************************
TCH4DAT423.HPP - object to read and write the structure of transient
	       CH4 data from/to files used by the
	       Terrestrial Ecosystem Model (TEM)

               20080118 J.T created this file

************************************************************** */

#if !defined(DATCH4DAT423_H)
#define DATCH4DAT423_H

class CH4data {

  public:

     CH4data(void);

/* **************************************************************
		    Public Functions
************************************************************** */

     int get(ifstream& ifile);
     int getdel(FILE* infile);
     void out(ofstream& ofile, float& year, double& bch4);
     void outdel(ofstream& ofile, float& year, double& bch4);

/* **************************************************************
		     Public Variables
************************************************************** */

     float year;        // year at beginning of year
     double mch4;        // atmospheric CH4 concentration in July (uM)


  private:

/* **************************************************************
		      Private Variables
************************************************************** */

     int ch4end;
     long curpos;
     long lagpos;


};

#endif

