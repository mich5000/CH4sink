/*
!---------------------------------------------------------------------------------
! Purpose: this module governs the concentration of four gases (N2, O2, CO2, CH4) 
!          in the water, which is mainly from Tang's thesis and "Numerical modeling
!          of methane emissions from lakes in the permafrost zone" [V. Stepanenko, 2011]
!
!---------------------------------------------------------------------------------
 */
#if !defined(WATERDIFF_H)
#include "WATERDIFF.hpp"
#endif
void WATERDIFF::watermain(double wdepth,double trophic,double wind, double pressure,double Qch4,double OQ10, double Kch4, double Ko2)
{
  int ii;
  double temp;
  preset(wdepth,trophic);
  Kg[:]=wm.tmpKw[:];
  /*
      if (lake_info%icehole==0) then
         Kg(1:m_lakeWaterTopIndex-1) = 2.0e-11_r8
      else
         Kg(1:m_lakeWaterTopIndex-1) = Kw0/Roul/Cpl
      end if
   */
  
  //upwelling turbulence
  if(wdepth > 10.0){
    for(ii=0;ii<NWLAYER;ii++){
      Kg[ii]=Kg[ii]+3.8218e-6*(0.65+wdepth-wm.Zw[ii]);
    }
  }
  temp = (wm.Twater[0]+wm.Twater[1])/2.0;
  /*
      if (lake_info%icehole==1) then
         temp = max(temp, T0)
      end if
   */
  for(ii=wm.gas_n2;ii<wm.gas_ch4;ii++){
    Kt[ii] = CalcPistonVelocity(gas,temp,wind);
  }
  GenGasOxidationAuxiliaryVector(Qch4,OQ10);
  CalcGasOxidationChangeRate(wm.waterGasCon,Kch4,Ko2);
  CalcDiffusiveFlux(wm.waterGasCon, srfflux,pressure);
  CalcBottomUpwellingFlux(Porosity);
    //2D runge-kutta 
}

void WATERDIFF::preset(double wdepth,double trophic)
{
  Rox[:][:]=0.0;
  Vax_CH4[:]=0.0;
  Kt[:]=0.0;
  Kg[:]=0.0;
  srfflux=0.0;
  btmflux=0.0;
  DeriveOxyclineIndex(wdepth);
  CalcChlorophyllRatio(trophic);
}

void WATERDIFF::derivs(double x, double con[][], double dcon[][])
{
  double qt[NGAS],qb[NGAS],gain[NGAS],dc1[NGAS],dc2[NGAS];
  double a,b;
  int ii,jj;
  /*
      if (m_lakeWaterTopIndex>NWLAYER+1) then
         dcon = 0.0_r8
         return
      end if
   */
  qt[:] = srfflux[:];
  qb[:] = btmflux[:];
  for(ii=0;ii<NWLAYER;ii++){
    gain[:] = Rox[ii][:] + wm.gasExchange[ii][:];
    if(ii==1){
      a = (0.5*(Kg[ii+1]+Kg[ii])) * (0.5*(wm.Az[ii+1]+wm.Az[ii]));
      dc1[:] = (con[ii+1][:]-con[ii][:]) / (wm.Zw[ii+1]-wm.Zw[ii]);
      dcon[ii][:] = (a*dc1[:] - qt[:]*wm.Az[ii]) / (wm.Zw[ii+1]-wm.Zw[ii]) / wm.Az[ii] + gain[:];
    }
    else if(ii==NWLAYER+1){
      b = (0.5*(Kg[ii-1]+Kg[ii])) * (0.5*(wm.Az[ii-1]+wm.Az[ii]));
      dc2[:] = (con[ii][:]-con[ii-1][:]) / (wm.Zw[ii]-wm.Zw[ii-1]);
      dcon[ii][:] = (qb[:]*wm.Az[ii] - b*dc2[:]) / (wm.Zw[ii]-wm.Zw[ii-1]) / wm.Az[ii] + gain[:];
    }
    else{
      a = (0.5*(Kg[ii+1]+Kg[ii])) * (0.5*(wm.Az[ii+1]+wm.Az[ii]));
      b = (0.5*(Kg[ii]+Kg[ii-1])) * (0.5*(wm.Az[ii-1]+wm.Az[ii]));
      dc1[:] = (con[ii+1][:]-con[ii][:]) / (wm.Zw[ii+1]-wm.Zw[ii]);
      dc2[:] = (con[ii][:]-con[ii-1][:]) / (wm.Zw[ii]-wm.Zw[ii-1]);
      dcon[ii][:] = 2.0 * (a*dc1[:] - b*dc2[:]) / (wm.Zw[ii+1]-wm.Zw[ii-1]) / wm.Az[ii] + gain[:];
    }
    for(jj=0;jj<NGAS;jj++){
      if(con[ii][jj] <=0 && dcon[ii][jj] < 0) dcon[ii][jj] = 0.0;
    }
  }
}

/*
   !------------------------------------------------------------------------------
   !
   ! Purpose: Adjust negative dissolved gas concentrations (project negative values to zero).
   !          ("Non-negative solutions of ODEs", Shampine, L., 2005).
   !
   !------------------------------------------------------------------------------
 */
void WATERDIFF::AdjustNegativeConcentrations()
{
  for(ii=0;ii<NWLAYER;ii++){
    for(jj=0;jj<NGAS;jj++){
      if(wm.waterGasCon[ii][jj] < 0) wm.waterGasCon[ii][jj] = 0.0;
    }
  }
}

/*
   !------------------------------------------------------------------------------
   !
   ! Purpose: Calculate gas oxidation rate by MichaelisMenten kinetics - 
   !          http://en.wikipedia.org/wiki/Michaelis%E2%80%93Menten_kinetics.
   !          BOD concentration refers to "Dissolved oxygen model for regional lake 
   !          analysis" (Stefan et al., 1994).
   !
   !------------------------------------------------------------------------------
 */
void WATERDIFF::CalcGasOxidationChangeRate(double con[][],double Kch4, double Ko2)
{
  double con_ch4,con_o2,redox_ch4;
  int ii;
  Rox[:][wm.gas_n2] = 0.0;
  for(ii=0;ii<NWLAYER;ii++){
    con_ch4 = con[ii][wm.gas_ch4];
    con_o2 = con[ii][wm.gas_o2];
    if (con_ch4<wm.Gastol[wm.gas_ch4]){
      redox_ch4 = 0.0;
    }
    else{
      redox_ch4 = Vax_CH4[ii] * (con_ch4 / (Kch4+con_ch4)) * (con_o2 / (Ko2+con_o2));
    }
    Rox[ii][wm.gas_ch4] = -redox_ch4;
    Rox[ii][wm.gas_o2] = -2.0*redox_ch4;
    Rox[ii][wm.gas_co2] = redox_ch4;
  }
}

void WATERDIFF::GenGasOxidationAuxiliaryVector(double Qch4, double OQ10)
{
  double temp;
  int ii, top;
  /*
      if (lake_info%icehole==1) then
         top = 1
      else
         top = m_lakeWaterTopIndex
         Vax_CH4(1:top-1) = 0.0_r8
      end if
   */
  top=0; // consider only no ice situation
  for(ii=top;ii<NWLAYER;ii++){
    temp = FMAX(m_waterTemp[ii], wm.T0);
    if (ii>=oxycline){
      Vax_CH4[ii] = Qch4 * (pow(OQ10,0.1*(temp-wm.Tor))) * oxyratio;
    }
    else{
      Vax_CH4[ii] = Qch4 * (pow(OQ10,0.1*(temp-wm.Tor)));
    }
  }
}

double WATERDIFF::CalcChorophyllRatio(double trophic)
{
  double TSI = 30.6;
  double chl;
  chl = exp((trophic-1)*TSI/9.81);
  return 1.0/chl;  
}

/*
   !------------------------------------------------------------------------------
   !
   ! Purpose: Calculate gas flux via diffusive transfer
   !      The surface gas concentration is calculated from the top 20 cm layers
   !      (Schubert et al., 2012).
   !
   !------------------------------------------------------------------------------
 */
void WATERDIFF::CalcDiffusiveFlux(double con[][], double flux[],double pressure0)
{
  double percentage, Ceq, pressure;
  double temp, concentration;
  int gas, htop, ltop;
/*
      if (m_lakeWaterTopIndex>NWLAYER+1) then
         flux = 0.0_r8
         return
      end if
 */
  htop = 0;
  ltop = FMIN(htop+2,NWLAYER-1);
  temp = wm.mean1d(wm.Twater,htop,ltop);
  /*
      if (lake_info%icehole==1) then
         temp = max(temp, T0)      
      end if
   */
  for(gas = wm.gas_n2;gas<=wm.gas_ch4;gas++){
    percentage =wm.GetGasPercentage(gas);
    pressure = percentage*pressure0;
    concnetration = wm.mean(con[:][gas], htop,ltop);
    Ceq = wm.CalcEQConc(gas,temp,pressure);
    flux[gas] = Kt[gas]*(concentration-Ceq);
  }   
}

void WATERDIFF::CalcBottomUpwellingFlux(double Porosity)
{
  double cch4w,cch4s;
  double cn2s,cn2w,co2w;
  double Dgas;
  /*
          if (m_lakeWaterTopIndex<=NWLAYER+1) btmflux = 0.0
   */
  cch4s = wm.sedGasCon[0][wm.sed_ch4];
  cch4w = wm.waterGasCon[NWLAYER-1][wm.gas_ch4];
  cn2s = wm.sedGasCon[0][wm.sed_n2];
  cn2w = wm.waterGasCon[NWLAYER-1][wm.gas_n2];
  co2w = wm.waterGasCon[NWLAYER-1][wm.gas_o2];
  Dgas = 2.0e-9*0.66*Porosity;
  btmflux[wm.gas_ch4] = Kg[WLAYER-1] * (cch4s-cch4w) / 0.1;
  btmflux[wm.gas_co2] = 0.0;
  btmflux[wm.gas_o2] = -Dgas * co2w / 0.1;
  btmflux[wm.gas_n2] = Kg[NWLAYER-1] * (cn2s - cn2w) / 0.1;
}


void WATERDIFF::GetCH4OxidationRate(double rates[])
{
  rates[:] = -Rox[:][wm.gas_ch4];
}

/*
   !------------------------------------------------------------------------------
   !
   ! Purpose: Derive the index of oxycline from temperature gradient
   !
   !------------------------------------------------------------------------------
 */
void WATERDIFF::DeriveOxyclineIndex(double wdepth)
{
  if(wdepth >= 10.0){
    oxycline = NWLAYER-1-NWLAYER/2;
  }
  else{
    oxycline = NWLAYER;
  }
}
