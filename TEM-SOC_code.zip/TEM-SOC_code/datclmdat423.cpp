/* *************************************************************
TCLMDAT423.CPP - object to read and write the structure of the
                climate data from files used by the Terrestrial
                Ecosystem Model (TEM)

Need to modify the input and output for Daily time step, Q. Zhuang 19/Nov/2002

************************************************************* */
#if !defined(DATCLMDAT423_H)
  #include "datclmdat423.hpp"
#endif

Clmdata::Clmdata(void)
{

  clmend = 1;
  lagpos = -99;
  curpos = 0;

};

/* **************************************************************
                    Public Functions
************************************************************** */

int Clmdata::get(ifstream& ifile)
{

  lagpos = ifile.tellg();

  ifile >> col >> row;
  ifile >> varname;
  ifile >> carea;
  ifile >> year;
//  infile >> month;
  ifile >> total;
  ifile >> max;
  ifile >> ave;
  ifile >> min;

  for (int i = 0; i < CYCLE; i++) { ifile >> mon[i]; }

  ifile >> contnent;

  ifile.seekg(0, ios::cur);
  curpos = ifile.tellg();

  if (curpos < (lagpos + 10)) { clmend = -1; }

  return clmend;

};

/* *************************************************************
************************************************************* */

int Clmdata::getdel(FILE* ifile)
{

  int j;
  int m, days;

//  for (j=0; j< 12; j++)
//   {
//   days = daysnumber(j);
//   for (m=0; m < days; m++)
//   dat[j][days] =0.0;
//   }

  clmend = fscanf(ifile, "%f,%f, %s ,%d,%ld,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf, %s",
                  &col, &row, varname, &carea, &year, &total, &max, &ave, &min,
                  mon+0, mon+1, mon+2, mon+3, mon+4, mon+5,
                  mon+6, mon+7,mon+8, mon+9, mon+10, mon+11, contnent);


  for (j=0; j< 12; j++)
   {
   days = daysnumber(j, year);
   for (m=0; m < days; m++)
    {
    dat[j][m] = mon[j];
    }
   }
 }

/* *************************************************************
************************************************************* */

int Clmdata::getdel_clm(FILE* ifile)
{

  int j;
  int m, days;


  int  i;
  for (j=0; j< 12; j++)
     {
        clmend = fscanf(ifile, "%f,%f, %s ,%d,%ld,%ld,%lf,%lf,%lf,%lf",
                  &col, &row, varname, &carea, &year, &month, &total, &max, &ave, &min);
//       printf("%f,%f,%s,%d,%ld,%ld,%lf,%lf,%lf,%lf  \n", col, row, varname, carea, year, month, total, max, ave, min); //llc

        switch (j)
         {
           case 0:
           case 2:
           case 4:
           case 6:
           case 7:
           case 9:
           case 11:
                  for (i=0; i <31; i++)
                 {
                  clmend = fscanf(ifile,",%lf", &dat[j][i]);
     //             printf("  %.2f,", dat[j][i]);
                 }
                 clmend = fscanf(ifile,", %s", contnent);
    //             getch();
                  break;
           case 3:
           case 5:
           case 8:
           case 10:
                  for (i=0; i <30; i++) clmend = fscanf(ifile,",%lf", &dat[j][i]);
                       clmend = fscanf(ifile,", %s", contnent);
                  break;
           case 1:
                  if ( (fmod(double(year - 1992), 4.0) == 0.0 && fmod(double(year), 100.0) != 0.0 )
                      || (fmod(double(year), 400.0) == 0.0) ) { m = 29;}
                  else m = 28;
                  for (i=0; i <m; i++) clmend = fscanf(ifile,",%lf", &dat[j][i]);
                     clmend = fscanf(ifile,", %s", contnent);
                                          break;
//           default:
         }
      }

  return clmend;

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

/* *************************************************************
************************************************************* */

void Clmdata::out(ofstream& ofile, float col, float row, char varname[9],
                  int carea, long year, double dat[CYCLE][31], char contnent[9])
{

  int j;
  double predtotl;
  double predmax;
  double predave;
  double predmin;

  int m, days;


  predtotl = 0.0;
  predmax   = -900000.0;
  predmin   =  900000.0;

  for (j = 0; j < CYCLE; j++) {
    days = daysnumber(j, year);
     for (m=0; m < days; m++)
      {
      if (dat[j][m] > predmax) { predmax = dat[j][m]; }
      if (dat[j][m] < predmin) { predmin = dat[j][m]; }
      predtotl += dat[j][m];
     }    // end of days
   }

  predave = predtotl / (double) CYCLE;
  if (predtotl <= (MISSING*CYCLE)) { predtotl = MISSING; }

  for (int i =0; i < CYCLE; i++)
   {
    days = daysnumber(i, year);
    for (m=0; m< days; m++)
    {
    ofile.setf(ios::fixed,ios::floatfield);
    ofile.setf(ios::showpoint);
    ofile.precision(1);

    ofile << col << ' ' << row << ' ';
    ofile << varname << ' ';
    ofile << setprecision(0) << carea << ' ';
    ofile << year << ' ';

    ofile << setprecision(1) << predtotl << ' ';
    ofile << predmax << ' ';
    ofile << setprecision(2) << predave << ' ';
    ofile << setprecision(1) << predmin << ' ';

    ofile << dat[i][m] << ' ';

   ofile << contnent << endl;
  } // end of days
 } // end of i =CYCLE
};


/* *************************************************************
************************************************************* */

/* *************************************************************
************************************************************* */


void Clmdata::outdel(ofstream& ofile, float col, float row, char varname[9],
                     int carea, long year, double dat[CYCLE][31], char contnent[9])
{

  int j;
  double predtotl;
  double predmax;
  double predave;
  double predmin;
  int m, days;

  predtotl = 0.0;
  predmax   = -900000.0;
  predmin   =  900000.0;

  for (j = 0; j < CYCLE; j++) {

    days = daysnumber(j, year);
     for (m=0; m < days; m++)
      {

    if (dat[j][m] > predmax) { predmax = dat[j][m]; }
    if (dat[j][m] < predmin) { predmin = dat[j][m]; }
    predtotl += dat[j][m];
    } // end of days
  }

  predave = predtotl / (double) CYCLE;
  if (predtotl <= (MISSING*CYCLE)) { predtotl = MISSING; }

  for (int i =0; i < CYCLE; i++)
   {
    days = daysnumber(i, year);
    for (m=0; m< days; m++)
    {
   ofile.setf(ios::fixed,ios::floatfield);
   ofile.setf(ios::showpoint);
   ofile.precision(1);

   ofile << col << "," << row << ", ";
   ofile << varname << " ,";
   ofile << setprecision(0) << carea << ",";
   ofile << year << ",";
   ofile << setprecision(1) << predtotl << ",";
   ofile << predmax << ",";
   ofile << setprecision(2) << predave << ",";
   ofile << setprecision(1) << predmin << ",";

  ofile << dat[i][m] << ",";

  ofile << " " << contnent;
  ofile << endl;
  } // end of days
 }  // end of i =CYCLE
};


/* *************************************************************
************************************************************* */

void Clmdata::pctout(ofstream& ofile, float col, float row, char varname[9],
                     int carea, long year, double dat[CYCLE][31], char contnent[9])
{

  int j;
  double predtotl;
  double predmax;
  double predave;
  double predmin;
  int m, days;

  predtotl = 0.0;
  predmax   = -900000.0;
  predmin   =  900000.0;

  for (j = 0; j < CYCLE; j++) {

     days = daysnumber(j, year);
     for (m=0; m < days; m++)
      {
    if (dat[j][m] > predmax) predmax = dat[j][m];
    if (dat[j][m] < predmin) predmin = dat[j][m];
    predtotl += dat[j][m];
   }
  }

  predave = predtotl / (double) CYCLE;
  if (predtotl <= (MISSING*CYCLE)) predtotl = MISSING;

  for (int i =0; i < CYCLE; i++)
   {
    days = daysnumber(i, year);
    for (m=0; m< days; m++)
    {
    ofile.setf(ios::fixed,ios::floatfield);
    ofile.setf(ios::showpoint);
    ofile.precision(1);

   ofile << col << ' ' << row << ' ';
   ofile << varname << ' ';
   ofile << setprecision(0) << carea << ' ';
   ofile << year << ' ';

   ofile << setprecision(2) << predtotl << ' ';
   ofile << predmax << ' ';
   ofile << predave << ' ';
   ofile << predmin << ' ';

   ofile << dat[i][m] << ' ';

   ofile << contnent;
   ofile << endl;
  } // end of days
 }  //e end of month
};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

void Clmdata::poutdel(ofstream& ofile, float col, float row, char varname[9],
                      int carea, long year, double dat[CYCLE][31], char contnent[9])
{

  int j;
  double predtotl;
  double predmax;
  double predave;
  double predmin;
  int m, days;

  predtotl = 0.0;
  predmax   = -900000.0;
  predmin   =  900000.0;

  for (j = 0; j < CYCLE; j++) {
    days = daysnumber(j, year);
     for (m=0; m < days; m++)
      {
      if (dat[j][m] > predmax) { predmax = dat[j][m]; }
      if (dat[j][m] < predmin) { predmin = dat[j][m]; }
      predtotl += dat[j][m];
     }
  }

  predave = predtotl / (double) CYCLE;
  if (predtotl <= (MISSING*CYCLE)) predtotl = MISSING;

  for (int i =0; i < CYCLE; i++)
   {
    days = daysnumber(i, year);
    for (m=0; m< days; m++)
    {

   ofile.setf(ios::fixed,ios::floatfield);
   ofile.setf(ios::showpoint);
   ofile.precision(1);

   ofile << col << "," << row << ", ";
   ofile << varname << " ,";
   ofile << setprecision(0) << carea << ",";
   ofile << year << ",";

   ofile << setprecision(2) << predtotl << ",";
   ofile << predmax << ",";
   ofile << predave << ",";
   ofile << predmin << ",";

   ofile << dat[i][m] << ",";

   ofile << " " << contnent;
   ofile << endl;
  } // end of days
 }
};
