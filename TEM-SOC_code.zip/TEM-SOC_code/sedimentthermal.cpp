/*********************************************************
**********************************************************
sedimentthermal.hpp
Object describing thermal transport in sediment below water, specifically
for wetlands, rivers and lakes. Similar to method of Zeli Tan
2015 JAMES paper. 
Added by L. Liu, July 18 2016

**********************************************************
*********************************************************/
#if !defined(SEDIMENTTHERMAL_H)
#include "sedimentthermal.hpp"
#endif



void SEDTHERMAL::Sedmain(double Ttop, double Rous, double Cps, double Porosity, double Kss, double seddepth)
{
  int ii;
  double temp, ice, theta;
  double x1 = 0.0; //from t1
  double x2 = 86400.0; //to t2
  double eps = 0.1; //accuracy
  double h1 = 300.0; //first time step
  double hmin = 60.0; //minimum time step
  preset(Porosity, seddepth);
  for(ii=0;ii<NSLAYER;ii++){
    temp = wm.Tsed[ii];
    ice = 0.0;
    theta = Porosity - ice;
    Cvt[ii] = Cps*Rous*(1.0-Porosity) + wm.Cpl*wm.Roul*(Porosity-ice) + wm.Cpi*wm.Roui*ice; 
    Ks[ii] = CalcHeatConductivity(temp,theta,ice, Kss,Farouki)/Cvt[ii];
  }
  CalcSedTopBottomHeatFlux(Ttop);
  odeint(wm.Tsed, NSLAYER, x1, x2, eps, h1, hmin);
}

void SEDTHERMAL::preset(double Porosity, double seddepth)
{
  int i;
  double dz = seddepth/float(NSLAYER);
  for(i=0;i<NSLAYER;i++){
    Ks[i] = 0.0;
    Cvt[i] = 0.0; 
    wm.Zs[i] = (i+1.0)*dz;       
  }   
  double x[3];
  int max_r = wm.SolveCubicEquation(x,-1.5, 0.0, 0.5*Porosity);
  for(i=0;i<max_r;i++){
    if(x[i] >= 0.0 && x[i] <= 1.0){
      Farouki = x[i];
      break;
    }
  }
}

double SEDTHERMAL::CalcHeatConductivity(double T, double theta, double itheta, double Kss, double Farouki)
{
  double c1=0.55,c2=0.8,c3=3.07,c4=0.13,c5=4.0;
  double f1=13.05, f2=1.06;
  double temp, f;
  temp = T - wm.T0;
  //      printf("Farouki=%f,e8=%f,Temp=%f,\n",Farouki,e8,temp);
  if (temp < wm.e8 && temp > -wm.e8){
    f = theta + (1+f1*pow(itheta,f2))*itheta;
    return c1 + c2*theta - (c1-c4)*exp(-pow(c3*f,c5));
  }
  else if (temp > wm.e8){
    return wm.Kw0*pow(Farouki,2.0) + Kss*pow((1.0-Farouki),2.0) + Kss*wm.Kw0*(2.0*Farouki-2.0*pow(Farouki,2.0))/(Kss*Farouki+wm.Kw0*(1.0-Farouki));
  }
  else {
    return wm.Ki0*pow(Farouki,2.0) + Kss*pow((1.0-Farouki),2.0) + Kss*wm.Ki0*(2.0*Farouki-2.0*pow(Farouki,2.0))/(Kss*Farouki+wm.Ki0*(1.0-Farouki));
  }
}

void SEDTHERMAL::CalcSedTopBottomHeatFlux(double Ttop)
{
  btmflux = 0.0;
  topflux = Ttop; 
}


void SEDTHERMAL::derivs(double x, double temp[], double dtemp[])
{
  double qb,qt,dT1,dT2;
  double theta,a,b;
  int ii; 
  qb = btmflux; 
  qt = topflux; 
  //     for(ii=0;ii<NSLAYER;ii++){
  //     printf("=======sediment!!_insideequ=%f,%f,\n",m_Zs[ii],Ks[ii]);
  //     printf("Tsed[%i]=%f,\n",ii,temp[ii]);
  //     }
  for(ii=0;ii<NSLAYER;ii++) {
    if(ii == 0) {
      a = 0.5*(Ks[ii]+Ks[ii+1]);
      dT1 = (temp[ii+1]-temp[ii]) / (wm.Zs[ii+1]-wm.Zs[ii]);
      dtemp[ii] = (a*dT1-qt) / (wm.Zs[ii+1]-wm.Zs[ii]);
      //   printf("top%f,%f,%f,%f,%f,\n",a,dT1,qt,dtemp[ii],temp[ii]); //llc test
    }
    else if(ii == NSLAYER-1){
      b = 0.5*(Ks[ii-1]+Ks[ii]);
      dT2 = (temp[ii]-temp[ii-1]) / (wm.Zs[ii]-wm.Zs[ii-1]);
      dtemp[ii] = (qb-b*dT2) / (wm.Zs[ii]-wm.Zs[ii-1]);
      //   printf("bot%f,%f,%f,%f,%f,\n",b,dT2,qb,dtemp[ii],temp[ii]); //llc test
    }
    else {
      a = 0.5*(Ks[ii+1]+Ks[ii]);
      b = 0.5*(Ks[ii-1]+Ks[ii]);
      dT1 = (temp[ii+1]-temp[ii]) / (wm.Zs[ii+1]-wm.Zs[ii]);
      dT2 = (temp[ii]-temp[ii-1]) / (wm.Zs[ii]-wm.Zs[ii-1]);
      dtemp[ii] = (a*dT1-b*dT2) / (0.5*(wm.Zs[ii+1]-wm.Zs[ii-1]));
      //    printf("%f,%f,%f,%f,%f,%f,\n",a,b,dT1,dT2,dtemp[ii],temp[ii]); //llc test
    }
  }
  //     printf(",,\n");
}

