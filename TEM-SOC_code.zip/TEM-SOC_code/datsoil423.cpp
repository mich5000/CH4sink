/* **************************************************************
*****************************************************************
TSOIL423.CPP - object describing general characteristics of soil
            - modified by DWK on 20000102
*****************************************************************
************************************************************** */

#if !defined(DATSOIL423_H)
  #include "datsoil423.hpp"
#endif

/* **************************************************************
************************************************************** */

Tsoil4::Tsoil4(void)
{

  text  = -99;
  wsoil = -99;

};

/* **************************************************************
************************************************************** */


/* **************************************************************
************************************************************** */

void Tsoil4::getecd(ofstream& rflog1)
{

  char ecd[80];

  cout << "Enter name of the soil (.ECD) data file with parameter values: ";
  cout << endl;
  fpara >> ecd;

  rflog1 << "Enter name of the soil (.ECD) data file with parameter values: ";
  rflog1 << ecd << endl;

  getecd(ecd);

};

/* *************************************************************
************************************************************* */


/* **************************************************************
************************************************************** */

void Tsoil4::getecd (char ecd[80])
{

  char dummy[12];
  ifstream infile;

  long update;

  infile.open(ecd, ios::in);

  if (!infile)
  {
    cerr << "\nCannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  infile >> dummy >> dummy >> dummy;
  infile >> dummy >> pctpora >> update;
  infile >> dummy >> pctporb >> update;
  infile >> dummy >> fldcapa >> update;
  infile >> dummy >> fldcapb >> update;
  infile >> dummy >> wiltpta >> update;
  infile >> dummy >> wiltptb >> update;

  infile.close();

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

void Tsoil4::getrootz(ofstream& rflog1)
{

  char ecd[80];

  cout << "Enter name of the data file containing the rooting depths:";
  cout << endl;
  cout << "               (e.g., ROOTZVEG.ECD)" << endl;
  fpara >> ecd;

  rflog1 << "Enter name of the data file containing the rooting depths:";
  rflog1 << endl;
  rflog1 << "               (e.g., ROOTZVEG.ECD)" << endl;
  rflog1 << ecd << endl;

  getrootz(ecd);

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

void Tsoil4::getrootz(char ecd[80])
{

  const int NUMVAR = 7;
  char dummy[NUMVAR][10];
  ifstream infile;

  int i;
  int dcmnt;
  int  rootveg[MAXCMNT];
  long update[MAXCMNT];
  char vegname[MAXCMNT][31];

  infile.open(ecd, ios::in);

  if (!infile)
  {
    cerr << "\nCannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  for (i = 0; i < NUMVAR; i++) { infile >> dummy[i]; }
  for (dcmnt = 1; dcmnt < MAXCMNT; dcmnt++)
  {
    infile >> rootveg[dcmnt] >> vegname[dcmnt];
    infile >> rootza[dcmnt] >> rootzb[dcmnt] >> rootzc[dcmnt];
    infile >> minrootz[dcmnt] >> update[dcmnt];
  }

  infile.close();

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

void Tsoil4::lake(double& tair,double& prec,double& rain,double& snowfall,
       		  double& pet, double& eet, int& dm, int& m)
{

  rgrndh2o[dm][m] = 0.0;
  sperc[dm][m] = 0.0;
  snowpack[dm][m] = 0.0;
  sgrndh2o[dm][m] = 0.0;
  moist[dm][m] = 0.0;

  if (tair >= -1.0)
  {
   rain = prec;
    snowfall = 0.0;
  }
  else
  {
    rain = 0.0;
    snowfall = prec;
  }

  eet = pet;
  h2oyld[dm][m] = prec - pet;

};

/* *************************************************************
************************************************************* */
 // added for 3-layer hydrology model, Q. Zhuang
void Tsoil4::percol_hydm(double& rainthrough, double& snowthrough, double& trans1,
     double& trans2,double& trans3, double& avlh2o1, double& avlh2o2,
     double& avlh2o3, double& lyperc1, double& lyperc2,const int& dm, const int& m)
 {

 double extra1, extra2,extra3, extra;
 double recharge;

 extra = 0.0;
 extra1= 0.0;
 extra2= 0.0;
 extra3= 0.0;

 rperc[dm][m]= 0.0;
 sperc[dm][m]= 0.0;

 rperc1[dm][m]= 0.0;
 sperc1[dm][m]= 0.0;

 rperc2[dm][m]= 0.0;
 sperc2[dm][m]= 0.0;

 rperc3[dm][m]= 0.0;
 sperc3[dm][m]= 0.0;

 recharge = rainthrough + snowthrough;

 if (recharge <= 0.0) { recharge = 0.001; }

 if ( (avlh2o1 + rainthrough + snowthrough -lyperc1 - trans1) > awcapmm1) {
	  extra1 = rainthrough + snowthrough + avlh2o1 - lyperc1 - trans1 - awcapmm1;  // trans1 is an evaporation not transpiration because of moss

 if ( avlh2o2+lyperc1- trans2 - lyperc2 > awcapmm2) {
 extra2 = avlh2o2+lyperc1 - trans2 -awcapmm2 - lyperc2;
 }

 if ( avlh2o3+lyperc2- trans3  > awcapmm3) {
 extra3 = avlh2o3+lyperc2 - trans3 -awcapmm3;
 }

  extra=extra1+extra2+extra3;

  sperc1[dm][m]=snowthrough * extra1/recharge;
  sperc2[dm][m]=snowthrough * extra2/recharge;
  sperc3[dm][m]=snowthrough * extra3/recharge;

  rperc1[dm][m]= rainthrough * extra1 / recharge;
  rperc2[dm][m]= rainthrough * extra2 / recharge;
  rperc3[dm][m]= rainthrough * extra3 / recharge;

//  sperc[dm][m] = snowthrough * extra / recharge;
//  rperc[dm][m] = rainthrough * extra / recharge;
 }
};

/* *************************************************************
************************************************************* */

void Tsoil4::percol(double& rain, double& snowinf, double& eet,
                    double& avlh2o, const int& dm, const int& m)
{

  double extra;
  double recharge;
  sperc[dm][m] = 0.0;
  rperc[dm][m] = 0.0;

  recharge = rain + snowinf;
  if (recharge <= 0.0) { recharge = 0.001; }
  if ((avlh2o + rain + snowinf - eet) > awcapmm)
  {
    extra = rain + snowinf + avlh2o - awcapmm - eet;
    sperc[dm][m] = snowinf * extra / recharge;
    rperc [dm][m] = rain * extra / recharge;
  }

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************** */

double Tsoil4::rrunoff(const double& rgrndh2o, const double& rperc)
{

  double rrunof;

  rrunof = 0.5 * (rgrndh2o + rperc);

  return rrunof;

};


// modified for the three-layer model, rgrndh2o is storage water runoff from moss layer
// for rainfall runoff
double Tsoil4::new_rrunoff(const double& rgrndh2o, const double& rperc1)
       {

  double rrunof;

  rrunof = 0.5 * (rgrndh2o + rperc1);

  return rrunof;

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************** */

void Tsoil4::showecd(void)
{

  cout << endl << "                   SOIL CHARACTERISTICS OF SITE";
  cout << endl << endl;
  printf("PSAND    = %5.2lf      PSILT = %5.2lf      PCLAY = %5.2lf\n",
         pctsand, pctsilt, pctclay);

  printf("POROSITY = %5.2lf   PCFLDCAP = %5.2lf   PCWILTPT = %5.2lf\n",
         pctpor, pcfldcap, pcwiltpt);

};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************** */

double Tsoil4::snowmelt(const double& elev, const double& tair,
                        const double& prevtair, const double& snowpack)
{

  double snowflux = 0.0;

  if (tair >= -1.0)
  {
    if (elev <= 500.0) { snowflux = snowpack;}
    else
    {
      if (prevtair < -1) { snowflux = 0.5 * snowpack; }
      else { snowflux = snowpack; }
    }
  }

  return snowflux;

};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************** */

double Tsoil4::srunoff(const double& elev, const double& tair,
                       const double& prevtair, const double& prev2tair,
                       const double& sgrndh2o, const double& sperc)
{

  double srunof = 0.0;

  if (tair >= -1.0)
  {
    if (prevtair < -1.0) { srunof = 0.1 * (sgrndh2o + sperc); }
    else
    {
      if (prev2tair < -1)
      {
	if (elev <= 500.0) { srunof = 0.5 * (sgrndh2o + sperc); }
	else { srunof = 0.25 * (sgrndh2o + sperc); }
      }
      else { srunof = 0.5 * (sgrndh2o + sperc); }
    }
  }

  return srunof;

};

// added for 3-layer hydrological model
// for snow runoff from snow storage
//similar to monthly process temporarily ?
double Tsoil4::new_srunoff(const double& elev, const double& tair,
                       const double& prevtair, const double& prev2tair,
                       const double& sgrndh2o, const double& sperc1)
{

  double srunof = 0.0;

  if (tair >= -1.0)
  {
    if (prevtair < -1.0) { srunof = 0.1 * (sgrndh2o + sperc1); }
    else
    {
      if (prev2tair < -1)
      {
	if (elev <= 500.0) { srunof = 0.5 * (sgrndh2o + sperc1); }
	else { srunof = 0.25 * (sgrndh2o + sperc1); }
      }
      else { srunof = 0.5 * (sgrndh2o + sperc1); }
    }
  }

  return srunof;

};

/* *************************************************************
************************************************************* */
// added for 3-layer hydrological model, Q. Zhuang, 05/Jan/2003

void Tsoil4::hydm_xtext(int& ez, double& pctsilt, double& pctclay)
 {
 double rootmin;
 double rootmx;

  totpor = fldcap = wiltpt = MISSING;
  awcapmm =  MISSING;

  rootmin = 99.9;
  rootmx = -999.9;

  totpor1 = fldcap1 = wiltpt1 = -999.9;
  totpor2 = fldcap2 = wiltpt2 = -999.9;
  totpor3 = fldcap3 = wiltpt3 = -999.9;

  awcapmm1 =  -999.9;
  awcapmm2 =  -999.9;
  awcapmm3 =  -999.9;

  psiplusc = (pctsilt + pctclay) * 0.01;

  if (psiplusc < 0.01) { psiplusc = 0.01; }

// unit is meter

  rootz = (rootza[ez] * pow(psiplusc, 2.0)) + (rootzb[ez] * psiplusc) + rootzc[ez];

  if (rootz < minrootz[ez]) { rootz = minrootz[ez]; }

  if (rootz< rootmin) {rootmin= rootz;}
  if (rootz> rootmx) { rootmx=rootz;}

  dpwbox1 = rootz * 0.1;  // a thin layer (surface laler 0.1m for the first root zone, maybe the moss, Desborough, 1997
  dpwbox2 = rootz * 0.7; // needed to reconsider it
  dpwbox3 = rootz * 0.2; // mineral account for 20%

  pctpor = (pctpora * psiplusc) + pctporb;
  pcfldcap = (fldcapa * psiplusc) + fldcapb;
  pcwiltpt = (wiltpta * psiplusc) + wiltptb;

  totpor1  = rootz * 0.1 * pctpor * 10.0 ;
  fldcap1  = rootz * 0.1 * pcfldcap * 10.0;
  wiltpt1  = rootz * 0.1 * pcwiltpt * 10.0;

  totpor2  = rootz * 0.8 * pctpor * 10.0 ;
  fldcap2  = rootz * 0.8 * pcfldcap * 10.0;
  wiltpt2  = rootz * 0.8 * pcwiltpt * 10.0;

  totpor3  = rootz * 0.2 * pctpor * 10.0 * 5;
  fldcap3  = rootz * 0.2 * pcfldcap * 10.0;
  wiltpt3  = rootz * 0.2 * pcwiltpt * 10.0;

  totpor  = rootz * pctpor * 10.0;
  fldcap  = rootz * pcfldcap * 10.0;
  wiltpt  = rootz * pcwiltpt * 10.0;

  awcapmm1 = fldcap1 - wiltpt1;
  awcapmm2 = fldcap2 - wiltpt2;
  awcapmm3 = fldcap3 - wiltpt3;

  awcapmm = fldcap - wiltpt;  // estimate capacity for daily hydrological model

};

/* *************************************************************
************************************************************** */

void Tsoil4::xtext(int& cmnt, double& pctsilt, double& pctclay)
{

  totpor = fldcap = wiltpt = MISSING;
  awcapmm =  MISSING;

  psiplusc = (pctsilt + pctclay) * 0.01;
  if (psiplusc < 0.01) { psiplusc = 0.01; }

  rootz = (rootza[cmnt] * pow(psiplusc, 2.0)) + (rootzb[cmnt] * psiplusc)
          + rootzc[cmnt];
  if (rootz < minrootz[cmnt]) { rootz = minrootz[cmnt]; }

  pctpor = (pctpora * psiplusc) + pctporb;
  pcfldcap = (fldcapa * psiplusc) + fldcapb;
  pcwiltpt = (wiltpta * psiplusc) + wiltptb;

  totpor  = rootz * pctpor * 10.0;
  fldcap  = rootz * pcfldcap * 10.0;
  wiltpt  = rootz * pcwiltpt * 10.0;

  awcapmm = fldcap - wiltpt;

};

