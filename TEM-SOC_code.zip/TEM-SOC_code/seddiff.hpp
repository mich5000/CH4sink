/*!---------------------------------------------------------------------------------
! Purpose: this module governs the production of methane in the sediments, which 
!          is from "Numerical modeling of methane emissions from lakes in the permafrost zone" 
!          [Stepanenko et al., 2011] and "Simulating the decadal to millennial scale dynamics 
!          of morphology and sequestered carbon mobilization of two thermokarst lakes in N.W. Alaska" 
!          [Kessler et al., 2012]. The depth-dependence function of N2 is from "Gas transport in a 
!          residual layer of a water basin" [Bazhi et al., 2001]
! 
!
! added by L.Liu, 09/03/2016
!---------------------------------------------------------------------------------*/

#if !defined(CKRUNGEKUTTA_H)
  #include "ckrungekutta.cpp" //ck runge kutta calculation
#endif

#if !defined(SEDDIFF_H)
#define SEDDIFF_H
#endif

#if !defined(WM_VARIABLES_H)
  #include "wm_variables.cpp" // variables input
#endif

// for methane production
#if !defined(METHANEPRO_H)
  #include "methanepro.cpp" // TTEM inherits Odeint4 class
#endif

class SEDDIFF : public CKRUNGEKUTTA {


public:

  virtual void derivs(double x, double con[][], double dcon[][]);
  void AdjustNegativeConcentration();
  void sedmain(double Porosity, double damp,double pressure, double wdepth,double suborg,double cmnt,double rootz,double ph, double pcfldcap, double Re);
  void preset();
  void CalcSedMethaneDiffusivity(double Porosity);
  void GetCH4ProductionRate(double Pch4[][], double suborg,double cmnt,double rootz,double Tsed[],double ph,double pcfldcap);
  void CalcSedimentBubbleFlux();
  void CalcSedimentDfflux();
  void CalcTopMethaneFlux(double stw);

  CH4DMPRO ch4dmpro;  // for methane production
  WCH4_V wm;
  double Pch4[NSLAYER][NSGAS];
  double Ebch4[NSLAYER][NSGAS];
  double Dch4[NSLAYER];
  double sedbflux[NSGAS];
  double seddflux[NSGAS];
  double topflux[NSGAS];
  double m_sedWaterTopIndex;
  double m_sedWaterBtmIndex;


};
