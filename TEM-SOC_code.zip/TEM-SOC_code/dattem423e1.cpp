/* *************************************************************
****************************************************************
TTEM423.CPP - Terrestrial Ecosystem Model Version 4.2
****************************************************************
31/Dec/2002 Q. Zhuang Daily version
03/Jan/2003 Q. Zhuang added new hydrological model
****************************************************************
************************************************************** */

#ifndef DATTEM423E1_H
  #include "dattem423e1.hpp"
#endif


/* *********************************************************** */

TTEM::TTEM() : Odeint4()
{

  nfert = 1.00000;
  tol = inittol;
  totyr = -99;

// Identify potential output variables from TEM
// Ecosystem water pools ****************************************
// groundwater pool resulting from rainfall
  strcpy(predstr[I_RGRW],"RGRNDH2O");
  strcpy(predstr[I_SNWPCK],"SNOWPACK");  // snowpack
  // groundwater pool resulting from snow melt
  strcpy(predstr[I_SGRW],"SGRNDH2O");

  strcpy(predstr[I_WT], "WATERTBL");
  strcpy(predstr[I_CH4CON], "CH4CON");
  strcpy(predstr[I_CH4EMI], "CH4EMI");
  strcpy(predstr[I_TOTFLX], "CH4TOT");

  strcpy(predstr[I_CH4SC], "CH4SC"); //llc for soil concentration

  // *** the following are pools for 3-box hydrology
  strcpy(predstr[I_AVLW1], "AVAIL1");
  strcpy(predstr[I_AVLW2], "AVAIL2");
  strcpy(predstr[I_AVLW3], "AVAIL3");

  strcpy(predstr[I_SM1], "SOILH21");
  strcpy(predstr[I_SM2], "SOILH22");
  strcpy(predstr[I_SM3], "SOILH23");

  strcpy(predstr[I_PCTP1],"PCTP1");
  strcpy(predstr[I_PCTP2],"PCTP2");
  strcpy(predstr[I_PCTP3],"PCTP3");

  strcpy(predstr[I_VSM1],"VSM1");
  strcpy(predstr[I_VSM2],"VSM2");
  strcpy(predstr[I_VSM3],"VSM3");
  strcpy(predstr[I_VSM4],"VSM4");
  strcpy(predstr[I_VSM5],"VSM5");
  strcpy(predstr[I_VSM6],"VSM6");

  strcpy(predstr[I_TSOIL],"TSOIL");
  strcpy(predstr[I_DST5],"DST5");
  strcpy(predstr[I_DST10],"DST10");
  strcpy(predstr[I_DST20],"DST20");
  strcpy(predstr[I_DST50],"DST50");
  strcpy(predstr[I_DST100],"DST100");
  strcpy(predstr[I_DST200],"DST200");
  strcpy(predstr[I_FRONTD],"FRONTD");
  strcpy(predstr[I_THAWBE],"THAWBE");
  strcpy(predstr[I_THAWEND],"THAWEND");

  //added for isotope model youmi oh
  strcpy(predstr[I_D13INIT],"D13INIT");
  strcpy(predstr[I_D13PROD],"D13PROD");
  strcpy(predstr[I_D13OXID],"D13OXID");
  strcpy(predstr[I_D13FINAL],"D13FINAL");
  strcpy(predstr[I_MOMPFRAC],"MOMPFRAC");
  strcpy(predstr[I_TPFRAC],"TPFRAC");
  strcpy(predstr[I_TEFRAC],"TEFRAC");
  strcpy(predstr[I_TDFRAC],"TDFRAC");
  //strcpy(predstr[I_MOMPFRACPLT],"MOMPFRACPLT");
  //strcpy(predstr[I_D13OXIDPLT],"D13OXIDPLT");

 // Water fluxes *************************************************

  strcpy(predstr[I_RAIN],"RAIN");        // rainfall

  strcpy(predstr[I_RRUN],"RRUN");        // runoff of rainwater
  strcpy(predstr[I_SNWFAL],"SNOWFALL");  // snowfall

 // infiltration into the soil of water from snowmelt
  strcpy(predstr[I_SNWINF],"SNOWINF");

  strcpy(predstr[I_SRUN],"SRUN");        // runoff of snowmelt
  strcpy(predstr[I_WYLD],"H2OYIELD");    // water yield

  strcpy(predstr[I_PET3],"PET3");          // potential evapotranspiration
  strcpy(predstr[I_EET3],"EET3");          // estimated evapotranspiration

  strcpy(predstr[I_INFIL],"INFIL");    // Infiltration from surface
  strcpy(predstr[I_SRUNOFF],"SRUNOFF");    // Runoff from surface
  strcpy(predstr[I_DRAIN],"DRAIN");    // Drainage, sub-surface runoff
  strcpy(predstr[I_TRANS],"TRANS");    // transpiration of canopy
  strcpy(predstr[I_SEVAP],"SEVAP"); // soil surface evaporation
  strcpy(predstr[I_SNOWSUB],"SNSUB"); // snow sublimation from ground
  strcpy(predstr[I_SUBCAN],"SUBCAN"); // snow sublimation from canopy
};


/* **************************************************************
************************************************************** */
//Rh and Nmin removed by CFD 20000616

int TTEM::boundcon(double ptstate[], double err[], double& ptol)
{

  int test = ACCEPT;

  if (err[I_RGRW]  > fabs(ptol * ptstate[I_RGRW]))
  {
    return test = temkey(I_RGRW)+1;
  }
  if (err[I_SNWPCK]  > fabs(ptol * ptstate[I_SNWPCK]))
  {
    return test = temkey(I_SNWPCK)+1;
  }
  if (err[I_SGRW]  > fabs(ptol * ptstate[I_SGRW]))
  {
    return test = temkey(I_SGRW)+1;
  }

  if (err[I_RPERC1]  > fabs((ptol) * ptstate[I_RPERC1]))
  {
    return test = temkey(I_RPERC1)+1;
  }

  if (err[I_EET3]  > fabs((ptol) * ptstate[I_EET3]))
  {
    return test = temkey(I_EET3)+1;
  }


  if (err[I_AVLW1]  > fabs(ptol * ptstate[I_AVLW1]))
  {
    return test = temkey(I_AVLW1)+1;
  }

    if (err[I_AVLW2]  > fabs(ptol * ptstate[I_AVLW2]))
  {
    return test = temkey(I_AVLW2)+1;
  }
    if (err[I_AVLW3]  > fabs(ptol * ptstate[I_AVLW3]))
  {
    return test = temkey(I_AVLW3)+1;
  }

  return test;

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

void TTEM::delta(const int& dm, const int& m, double pstate[], double pdstate[])
{

//   nfert = 1.0000000;

 // added for canopy hydrology model
   pdstate[I_EET3] = atms.eet3[dm][m];

   pdstate[I_INFIL] = hydm.surinfl[dm][m];
   pdstate[I_SRUNOFF] = hydm.surrunoff[dm][m];
   pdstate[I_DRAIN] = hydm.bdrai[dm][m];

   pdstate[I_TRANS] = hyd.htrans[dm][m];
   pdstate[I_SEVAP] = hyd.soil_evap[dm][m];
   pdstate[I_SNOWSUB] = hyd.snowsub[dm][m];
   pdstate[I_SUBCAN] = hyd.sub_from_canopy[dm][m];
   pdstate[I_WT] = hydm.watertable[dm][m];

//   pdstate[I_TFLX] = ch4dmdif.totalflx[dm][m];
   pdstate[I_CH4CON] = ch4dmdif.ch4cons[dm][m];
   pdstate[I_CH4EMI] = ch4dmdif.ch4emis[dm][m];
   pdstate[I_TOTFLX] = ch4dmdif.ch4tot[dm][m];

   pdstate[I_CH4SC] = ch4dmdif.ch4sc[dm][m];//llc porewater

 // for soil temperature
   pdstate[I_TSOIL] = atms.tsoil[dm][m];
   pdstate[I_DST5] = atms.dst5[dm][m];
   pdstate[I_DST10] = atms.dst10[dm][m];
   pdstate[I_DST20] = atms.dst20[dm][m];
   pdstate[I_DST50] = atms.dst50[dm][m];
   pdstate[I_DST100] = atms.dst100[dm][m];
   pdstate[I_DST200] = atms.dst200[dm][m];
   pdstate[I_FRONTD] = atms.frontd[dm][m];
   pdstate[I_THAWBE] = atms.thawbe[dm][m];
   pdstate[I_THAWEND] = atms.thawend[dm][m];

   //isotope youmi oh
   pdstate[I_D13INIT] = ch4dmdif.d13init[dm][m];
   pdstate[I_D13PROD] = ch4dmdif.d13prod[dm][m];
   pdstate[I_D13OXID] = ch4dmdif.d13oxid[dm][m];
   pdstate[I_D13FINAL] = ch4dmdif.d13final[dm][m];
   pdstate[I_MOMPFRAC] = ch4dmdif.mompfrac[dm][m];
   pdstate[I_TPFRAC] = ch4dmdif.tpfrac[dm][m];
   pdstate[I_TEFRAC] = ch4dmdif.tefrac[dm][m];
   pdstate[I_TDFRAC] = ch4dmdif.tdfrac[dm][m];
   //pdstate[I_MOMPFRACPLT] = ch4dmdif.mompfracplt[dm][m];
   //pdstate[I_D13OXIDPLT] = ch4dmdif.d13oxidplt[dm][m];

 };

/* *************************************************************
************************************************************** */

void TTEM::ECDsetELMNTstate(const int& dcmnt, const double& psiplusc)
{

  int dyr;
  int dm;
  int m;
  int days;

  int year = 1992;

  for (dm = 0; dm < CYCLE; dm++)
  {
    days = daysnumber(dm, year);
    for (m=0; m < days; m++)
     {

    soil.vsm1[dm][m] = hydm.h2osoi[0];
	 if (soil.vsm1[dm][m] <= 0.0) {
	 soil.vsm1[dm][m] = 0.001;
    }

    soil.vsm2[dm][m] = hydm.h2osoi[1];
	 if (soil.vsm2[dm][m] <= 0.0) {
	 soil.vsm2[dm][m] = 0.001;
    }

    soil.vsm3[dm][m] = hydm.h2osoi[2];
	 if (soil.vsm3[dm][m] <= 0.0) {
	 soil.vsm3[dm][m] = 0.001;
    }

    soil.vsm4[dm][m] = hydm.h2osoi[3];
	 if (soil.vsm4[dm][m] <= 0.0) {
	 soil.vsm4[dm][m] = 0.001;
    }

    soil.vsm5[dm][m] = hydm.h2osoi[4];
	 if (soil.vsm5[dm][m] <= 0.0) {
	 soil.vsm5[dm][m] = 0.001;
    }

    soil.vsm6[dm][m] = hydm.h2osoi[5];
	 if (soil.vsm6[dm][m] <= 0.0) {
	 soil.vsm6[dm][m] = 0.001;
    }

    y[I_VSM1] = soil.vsm1[dm][m];
    y[I_VSM2] = soil.vsm2[dm][m];
    y[I_VSM3] = soil.vsm3[dm][m];
    y[I_VSM4] = soil.vsm4[dm][m];
    y[I_VSM5] = soil.vsm5[dm][m];
    y[I_VSM6] = soil.vsm6[dm][m];

 // The following is set up for methane production, pctp will be between 0 - 1

    y[I_PCTP1] = soil.pctp1[dm][m] =  soil.vsm1[dm][m] / (soil.totpor1 / 100.0);
    y[I_PCTP2] = soil.pctp2[dm][m] =  soil.vsm2[dm][m] / (soil.totpor2 / 100.0);
    y[I_PCTP3] = soil.pctp3[dm][m] =  soil.vsm3[dm][m] / (soil.totpor3 / 100.0);

//    y[I_SM1] = y[I_MOIST1] = soil.moist1[dm][m] = (soil.awcapmm1 + soil.wiltpt1);
//    y[I_SM2] = y[I_MOIST2] = soil.moist2[dm][m] = (soil.awcapmm2 + soil.wiltpt2);
//    y[I_SM3] = y[I_MOIST3] = soil.moist3[dm][m] = (soil.awcapmm3 + soil.wiltpt3);
//    y[I_PCTP1] = soil.pctp1[dm][m] = 100.0 * soil.moist1[dm][m] / soil.totpor1;
//    y[I_PCTP2] = soil.pctp2[dm][m] = 100.0 * soil.moist2[dm][m] / soil.totpor2;
//    y[I_PCTP3] = soil.pctp3[dm][m] = 100.0 * soil.moist3[dm][m] / soil.totpor3;

    y[I_AVLW1] = soil.avlh2o1[dm][m] = soil.awcapmm; // assume the available water in one-box soil

//    y[I_AVLW2] = soil.avlh2o2[dm][m] = soil.awcapmm2;
//    y[I_AVLW3] = soil.avlh2o3[dm][m] = soil.awcapmm3;

   }  // end of days
 }

};


/* *************************************************************
************************************************************* */

int TTEM::equilibrium(const int& itype, double& tol)
{

  int dyr = 0;

  setPrevState(prevy,y);

  totyr = 0;
  endeq = 0;
  intflag = 0;
  initFlag = 0;
  while ((dyr < runsize) && (endeq < 2))
  {
    endeq = stepyr(dyr,itype,intflag,tol);

    ++dyr;
    ++totyr;

 // Reset product fluxes and pools to zero

    ag.resetPROD();

// Check to see if steady state conditions have been reached.

    if (dyr >= strteq && endeq == 0)
    {
      if (wtol >= fabs(atms.yrrain + atms.yrsnowfall - atms.yreet3 - soil.yrh2oyld))
      {
	     endeq = 1;
      }
    }
  }


  if (endeq == 2)
  {
    nattempt = maxnrun;
    initFlag = 1;
  }

  if (dyr >= runsize && endeq < 2) { ++nattempt; initFlag =1; // Assuming at equllirium
                                   }

  return nattempt;

};
/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

void TTEM::getenviron(const int& dm, const int& m, const int& dyr)
{

  double z;
  double depthz;
  int satzone;
  long int i;
  double totalthickness;
  int totalnodes;

 //   printf("vegt=%i,\n",veg.cmnt);

    // Determine if daily precipitation occurs as rain or snow
    atms.precsplt(atms.prec[dm][m],atms.tair[dm][m],atms.rain[dm][m],atms.snowfall[dm][m]);

   if (atms.GISlai[dm][m] == 0.0) atms.GISlai[dm][m] = 0.01;  // for drbugging Q. Z.
   if (atms.GISlai[dm][m] < 0.0) atms.GISlai[dm][m] = 0.5;  // to deal with non-data grid cells
   veg.lai[dm][m] = atms.GISlai[dm][m]; // for calibration version

  // hyd.hvpd[dm][m] = 10; // 20gm-3 will result in the close of stomatal need to reconsider
  // Determine monthly potential evapotranspiration
  // hyd.vap[dm][m] = atms.vap[dm][m]; // assign static vapor pressure to hyd.vap[dm] instead of using transient data, need to figure out a way to deal with this conflict
   hyd.vaporpressure[dm][m] = hyd.vap[dm][m]/10.0;  //use CRU data sets, converse to kpa
   hyd.vpd(hyd.vaporpressure[dm][m], atms.tair[dm][m]);

   hyd.rainthrough[dm][m] = hyd.intercept(atms.rain[dm][m], hyd.inter_coef[veg.cmnt],dm, m);
   soil.avlh2o1[dm][m] = 2000.0 * (hydm.h2osoi[0] + hydm.h2osoi[1] + hydm.h2osoi[2] + hydm.h2osoi[3] + hydm.h2osoi[4]
                          + hydm.h2osoi[5])/6.0;

//   soil.avlh2o1[dm][m] =  soil.awcapmm + hyd.rainthrough[dm][m];
//   soil.avlh2o2[dm][m] =  soil.awcapmm + hyd.rainthrough[dm][m];

   hyd.canopy_water[dm][m] = hyd.prec_to_canopy[dm][m];

   hyd.drad(veg.lai[dm][m], hyd.EXT[veg.cmnt], atms.nirr[dm][m], dm, m);

   hyd.hLWP[dm][m] =  hyd.LWP(soil.avlh2o1[dm][m], soil.fldcap, soil.pctsand, soil.pctclay, soil.pctsilt);

   hyd.hpa[dm][m] = hyd.densityA(atms.tair[dm][m]);
   hyd.hlv[dm][m] = hyd.latentV(atms.tair[dm][m]);

  //rainfall is changed to rainthrough fall due to interception
  //  atms.rain[dm][m] = hyd.rainthrough[dm][m];

   hyd.Gs[dm][m] = hyd.CanopyConductance(veg.lai[dm][m], hyd.gmax[veg.cmnt],
           atms.tair[dm][m], hyd.vpdeficit, hyd.hLWP[dm][m],
           hyd.vpd_close[veg.cmnt],hyd.vpd_open[veg.cmnt], hyd.psi_close[veg.cmnt], hyd.psi_open[veg.cmnt]);

   hyd.htrans[dm][m] = hyd.penmanmonteith_new(atms.tair[dm][m], hyd.hdrad[dm][m], hyd.hpa[dm][m],
             hyd.vpdeficit, hyd.hlv[dm][m], hyd.Gs[dm][m], veg.lai[dm][m]);

   hyd.potevap_surface[dm][m] = hyd.evaporation_layer1(atms.tair[dm][m],
                                 hyd.hpa[dm][m],hyd.hlv[dm][m],hyd.vpdeficit, hyd.surfacerad[dm][m]);

 // consider only the precipitation flux reaching the soil
 // check for precipitation >= potential evaporation

//   	if (hyd.rainthrough[dm][m] >= hyd.potevap_surface[dm][m])
//         	hyd.soil_evap[dm][m] = hyd.potevap_surface[dm][m];
//   	else	hyd.soil_evap[dm][m] = 0.0;

  	hyd.soil_evap[dm][m] = hyd.potevap_surface[dm][m];

 //snow intercept
    if (soil.snowpack[dm][m] > 0.0) {
          hyd.sub_from_canopy[dm][m] = hyd.sublimation_canopy(veg.lai[dm][m],
              hyd.hdrad[dm][m], atms.tair[dm][m], soil.snowpack[dm][m], dm, m);
          if (hyd.sub_from_canopy[dm][m] == 0.0)  hyd.sub_from_canopy[dm][m] = 0.001; // to protect
     }

    soil.snowthrough[dm][m] = hyd.snowthroughfall[dm][m];

//llc!!
    
    hyd.snowmelt[dm][m] = hyd.snowmelt_srad(hyd.hdrad[dm][m], atms.tair[dm][m], t_snowpack);

 // sublimation from ground snow
    hyd.snowsub[dm][m] = hyd.snowsublimation_ground(soil.snowthrough[dm][m], atms.tair[dm][m], hyd.surfacerad[dm][m]);

 // snowpack is updated to snowthroug[dm][m]
    t_snowpack = t_snowpack + soil.snowthrough[dm][m]-hyd.snowsub[dm][m]-hyd.snowmelt[dm][m];;
    soil.snowpack[dm][m] = t_snowpack;
        if (soil.snowpack[dm][m] < 0.0) { soil.snowpack[dm][m] = 0.0; }
        if (t_snowpack < 0.0) { t_snowpack = 0.0; }

 // the estimate of actual evapotranspiration
    atms.eet3[dm][m] = hyd.htrans[dm][m] + hyd.sub_from_canopy[dm][m] + hyd.soil_evap[dm][m] + hyd.snowsub[dm][m];

 // the following is the original one to estimate the potential evapotranspiration
    atms.pet3[dm][m] = atms.new_petjh(atms.nirr[dm][m], atms.tair[dm][m], dm);
    if (atms.pet3[dm][m] <= 0.0) { atms.pet3[dm][m] = 0.001; }

 // deal with soil hydrological dynamics
    hydm.surrunoff[dm][m] = hydm.surfacerunoff(hyd.snowmelt[dm][m],hyd.rainthrough[dm][m],hydm.h2osoi[0],
            hydm.b1[veg.cmnt], hydm.ksat1[veg.cmnt], hydm.thetasat1[veg.cmnt], hydm.presat1[veg.cmnt],
            hydm.thick1[veg.cmnt]);
   hydm.surinfl[dm][m] = hydm.infiltration(hydm.surrunoff[dm][m], hyd.snowmelt[dm][m],hyd.rainthrough[dm][m]);

 // calculate soil water content and sub-surafce runoff (drainage)
    hydm.qtran = hyd.htrans[dm][m];
    hydm.qseva = hyd.soil_evap[dm][m];
 //  hydm.bdrai[dm][m] = hydm.qdrai[dm][m];

 // for general soil
    hydm.main_soil(hydm.nsl, hyd.htrans[dm][m], hydm.surinfl[dm][m], hyd.soil_evap[dm][m], hydm.bdrai[dm][m], hydm.dtsoi, atms.tsoil[dm][m]);
    // printf("%i,%i,%i,%i,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f, \n",dyr,dm,m,hydm.nsl,hyd.htrans[dm][m], hydm.surinfl[dm][m], hyd.soil_evap[dm][m], hydm.bdrai[dm][m], hydm.dtsoi, atms.tsoil[dm][m],hydm.h2osoi[0], hydm.h2osoi[1],hydm.h2osoi[2],hydm.h2osoi[3], hydm.h2osoi[4],hydm.h2osoi[5]); //llc test
 // for wetland soil to estimate water table and water content for the peatland soil

//    printf("%f,%f,%f,\n",hydm.qtran, hydm.qseva, hydm.qdraimax[veg.cmnt]); //llc

    //************************************************************************************************llc if have transient watertable

    if(atms.stw[dm][m] < -990.0 || atms.tstwflag == 0){hydm.flag_wt=0;}
    else{hydm.flag_wt=1;}

      if(hydm.flag_wt == 1){
	if(atms.stw[dm][m] <= 0.0) {hydm.watertable[dm][m] = -atms.stw[dm][m]; // llc, should be mm!! but some one I use cm input should be noticed
	 hydm.stw = 0.0;
	}
	else{ hydm.watertable[dm][m]=0.0;
	      hydm.stw = atms.stw[dm][m];
	}
	
      }
      else{
      hydm.watertable[dm][m] = 999.0; //llc for initail wt
      hydm.stw = 0.0; //llc for soil moisture
      }
    //*************************************************************************************************
//    if((dyr == 21 || dyr == 22) && (dm > 6) && (hydm.stw <= 0.0001)){
//    if((wet >= 1) && (wet <= 5)) hydm.wetlandTAWA(0.0, hyd.snowmelt[dm][m],hydm.qtran, hydm.qseva, dm, m, atms.tsoil[dm][m],
//   soil.pctsand, soil.pctsilt, soil.pctclay, 100.0);
//    } //llc for Jinsha test!!!
//    else
//    {
      //  if((wet >= 1) && (wet <= 5))
     if((frin > 0 && frin <= 10000)) hydm.wetlandTAWA(hyd.rainthrough[dm][m], hyd.snowmelt[dm][m],hydm.qtran, hydm.qseva, dm, m, atms.tsoil[dm][m],
    soil.pctsand, soil.pctsilt, soil.pctclay, hydm.qdraimax[veg.cmnt]);
//    }

    if(hydm.flag_wt == 1){
	if(atms.stw[dm][m] < 0.0) {hydm.watertable[dm][m] = -atms.stw[dm][m]; // llc, should be mm!! but some one I use cm input should be noticed
	 hydm.stw = 0.0;
	}
	else{ hydm.watertable[dm][m]=0.0;
	      hydm.stw = atms.stw[dm][m];
	}
	
    } //llc for stw input


 // get interpolated soil temperatures for each 1 cm depth
   for ( i = 0; i < 400; i++)
    {
 //     double z = i+1;
 //     ch4dmpro.intersoilt[i] = ch4dmpro.InterpolatST(atms.dst5[dm][m],atms.dst10[dm][m],atms.dst20[dm][m], atms.dst50[dm][m],atms.dst100[dm][m], atms.dst200[dm][m], z);

        ch4dmpro.intersoilt[i] = atms.tsoil[dm][m];


 //initilization
      ch4dmdif.ch4ratesat[i] = 0.0;
      ch4dmdif.ch4oxirate1[i] = 0.0;
      ch4dmdif.fdfs[i] = 0.0;

    }

// calculate the soil mositure at each 1 cm
    totalthickness = hydm.thick1[veg.cmnt] + hydm.thick2[veg.cmnt] + hydm.thick3[veg.cmnt]
                           + hydm.thick4[veg.cmnt] + hydm.thick5[veg.cmnt] + hydm.thick6[veg.cmnt] ;
//llc for wetland
    z = 0.0;
	totalnodes = ceil(totalthickness / 10 );
    for (i = 0; i < totalnodes; i++)
    {
      z = i+1.0;
      hydm.intersoilm[i] = hydm.InterpolatSM1(hydm.h2osoi[0], hydm.h2osoi[1],hydm.h2osoi[2],
                hydm.h2osoi[3], hydm.h2osoi[4],hydm.h2osoi[5], z, veg.cmnt);
	  	hydm.intersoilsatsm[i] = hydm.InterpolatSMSat(z, veg.cmnt);
      if ((frin > 0 && frin <= 10000)) hydm.intersoilsatsm[i] = 0.9;  //llc added for wetland saturation, attention
      if (hydm.intersoilm[i] < 0.0) hydm.intersoilm[i] = 0.01;
    //  printf("water:sm=%f, ssm=%f \n",hydm.intersoilm[i],hydm.intersoilsatsm[i]); //llc
     }

 // Calculate methane production rate at wetland --- with daily time step
 // Need to specify the grid cell is either wetland or upland, in the upland there is only methane oxidation occurred; in wetland there will be methanogenesis and oxidation below and above water
 //  1. forested bog, 2. nonforested bog, 3. forested swamp, 4. nonforested swamp, 5. alluvial formations, Matthews, 1987.

   if ((frin < 0 || frin > 10000))  // upland
      {
	double fnsoc; //added for yonsei nov 2020 youmi oh

     // methane diffusion to the soil for methanotrophy
		ch4dmdif.EffdfSM(hydm.intersoilm, hydm.intersoilsatsm, totalnodes);
		ch4dmdif.sat = 0;
		ch4dmdif.fdf = ch4dmdif.Diffusivity(soil.pctsand, soil.pctsilt, soil.pctclay, ch4dmdif.sat);
		ch4dmdif.ch4flx = ch4dmdif.CH4flxandCon(ch4dmdif.fdf, ch4dmpro.lowb[veg.cmnt]);
    // oxidation occurred between surface and low boundary for each 1 cm
		ch4dmoxi.consp = 0.0;

		depthz = 0.0;
	 
		for ( i = 0; i < int (ch4dmpro.lowb[veg.cmnt] /10.0); i++)
		{
			ch4dmoxi.fmct = ch4dmoxi.EffectMC(ch4dmdif.ch4con[i], ch4dmoxi.kc[veg.cmnt]);
			ch4dmoxi.oxygenC(ch4dmoxi.afp[veg.cmnt], ch4dmpro.lowb[veg.cmnt]);
			ch4dmoxi.foxyt = ch4dmoxi.EffectOXY(ch4dmoxi.oxygenc[i], ch4dmoxi.ko[veg.cmnt]);
			ch4dmoxi.fstt = ch4dmoxi.EffectST(ch4dmpro.intersoilt[i], ch4dmoxi.och4q10[veg.cmnt], ch4dmoxi.oxiref[veg.cmnt]);
    // using soil moisture for each 1 cm to drive the process
			ch4dmoxi.fsmt = ch4dmoxi.EffectSM(ch4dmoxi.mvmin[veg.cmnt], ch4dmoxi.mvmax[veg.cmnt], ch4dmoxi.mvopt[veg.cmnt],
			hydm.intersoilm[i]);

			depthz = (i+1) * 10.0;
			ch4dmpro.ehlt = ch4dmpro.RedoxP(hydm.watertable[dm][m], depthz, soil.pcfldcap, veg.cmnt, ch4dmpro.lowb[veg.cmnt]);
			ch4dmoxi.frxt = ch4dmoxi.EffectRX(ch4dmpro.ehlt);

	      ch4dmoxi.fctt = ch4dmoxi.EffectCT(icult);

		  ch4dmoxi.ch4oxirate[i] = ch4dmoxi.MethaneOR(ch4dmoxi.omax[veg.cmnt], ch4dmoxi.fmct, ch4dmoxi.foxyt, ch4dmoxi.fstt,
                  ch4dmoxi.fsmt,ch4dmoxi.frxt, ch4dmoxi.fctt );
		
		//added SOC function for Yonsei nov 2020 youmi oh
		//fnsoc = 0.04*toc+0.1;
		//fnsoc = 0.0367*toc+0.3007; //feb 2021 soilgrid 5-15cm
		fnsoc = (6.1431*toc)/(92.5389+toc); // feb 2021 soilgrid 5-15cm

		ch4dmoxi.ch4oxirate[i]=ch4dmoxi.ch4oxirate[i]*fnsoc;


     		ch4dmdif.ch4oxirate1[i] = ch4dmoxi.ch4oxirate[i];
     // consumption at the upland soils
		ch4dmoxi.consp = ch4dmoxi.consp + ch4dmoxi.ch4oxirate[i];

        
//              ch4dmoxi.oxiref[veg.cmnt], ch4dmoxi.omax[veg.cmnt], ch4dmdif.ch4oxirate1[i]);
		} // end for for
	
  // by considering oxidation, the acutual ch4 was uptaked into soil (mg m-2 day-1)
		ch4dmdif.ch4flx = ch4dmdif.ACH4flxandCon(ch4dmdif.fdf, ch4dmpro.lowb[veg.cmnt]);

    if (ch4dmdif.ch4flx < 0.0) ch4dmdif.ch4flx = 0.0;
    if (atms.tsoil[dm][m] < -1.0) ch4dmdif.ch4flx = 0.0; // assume under lower temperature (< -1.0), there is no consumption

    ch4dmdif.ch4cons[dm][m] = ch4dmdif.ch4flx;
    ch4dmdif.ch4emis[dm][m] = 0.0;

    if ((ch4dmdif.ch4cons[dm][m] < -999999.9) || (ch4dmdif.ch4cons[dm][m] > 999999.9))
       ch4dmdif.ch4cons[dm][m] = -999999.9;

    //upland flag for isotem youmi oh
    ch4dmdif.d13init[dm][m]=-99999.0;
    ch4dmdif.d13prod[dm][m]=-99999.0;
    ch4dmdif.d13oxid[dm][m]=-99999.0;
    ch4dmdif.d13final[dm][m]=-99999.0;
    ch4dmdif.mompfrac[dm][m]=-99999.0;
    ch4dmdif.tpfrac[dm][m]=-99999.0;
    ch4dmdif.tefrac[dm][m]=-99999.0;
    ch4dmdif.tdfrac[dm][m]=-99999.0;
    ch4dmdif.mompfracplt[dm][m]=-99999.0;
    ch4dmdif.d13oxidplt[dm][m]=-99999.0;

   } // end for non-wetland

  else // wetland
     {

       /*     //assume same days for rice paddy!!! llc 09/19/2016 ========================llc for Jinsha test!!! all of them will use input to replace later

     double rice_root = 0.001;//Rice plant root depth, which grows throw time after transplanting until tillering. Before transplanting and after harvesting, the value is 0.001 meter.
     double f_orgm;// For different years influence of organic matter content in soil on production, multiplier
    double rice_d1[2]; //transplanting date
    double rice_d2[2]; //Tillering data
    double rice_d3[2]; //harvest date

    
    if(dyr <= 21){
      f_orgm = 2.0;
      for(i=0;i<2;i++){
          rice_d1[i]=0.0;
          rice_d2[i]=0.0;
          rice_d3[i]=0.0;
      }
    }
    else if(dyr == 22){
      if(dm < 8) {f_orgm = 5.0;}
      else {f_orgm = 20.0;}
      rice_d1[0] = 403.0;
      rice_d2[0] = 416.0;
      rice_d3[0] = 625.0;
      rice_d1[1] = 804.0;
      rice_d2[1] = 817.0;
      rice_d3[1] = 1017.0;
    }
    else if(dyr == 23){
      if(dm < 8) {f_orgm = 5.0;}
      else {f_orgm = 20.0;}
      rice_d1[0] = 419.0;
      rice_d2[0] = 501.0;
      rice_d3[0] = 709.0;
      rice_d1[1] = 807.0;
      rice_d2[1] = 822.0;
      rice_d3[1] = 1112.0;
    }
//    else if(dyr == 24){f_orgm = 10.0;}

    if(((dm+1)*100+m+1 >= rice_d1[0]) && ((dm+1)*100+m+1 <= rice_d3[0])){
        if((dm+1)*100+m+1 >= rice_d1[0] && (dm+1)*100+m+1 <= rice_d2[0]) {rice_root = 0.05+0.25/(rice_d2[0]-rice_d1[0])*((dm+1)*100+m+1-rice_d1[0]);}
        else {rice_root = 0.30;}      
    }//crop1

    if(((dm+1)*100+m+1 >= rice_d1[1]) && ((dm+1)*100+m+1 <= rice_d3[1])){
        if((dm+1)*100+m+1 >= rice_d1[1] && (dm+1)*100+m+1 <= rice_d2[1]) {rice_root = 0.05+0.25/(rice_d2[1]-rice_d1[1])*((dm+1)*100+m+1-rice_d1[1]);}
        else {rice_root = 0.30;}      
    }//crop2
 //   printf("%i,%i,%i,%f,\n",dyr,dm,m,rice_root);


       soil.rootz=rice_root;

       */     
     //==========================================================================

//     atms.stw[dm][m] = 100.0; // for test
     double I0, Ta_wt; //radiance w/s
     I0 = atms.nirr[dm][m]/0.2388*pow(10,4)/86400.0; // w/s
     Ta_wt = atms.tair[dm][m] + 273.15;
     int zzz;
     double Rous = 2.455342*1000.0;
     double Cps = 1.115299*1000.0;
     double Kss = 1.280640;
     double Porosity = soil.pctpor/100.0;
//     printf("Porosity = %f,10000*Ttop = %f,\n",Porosity,10000*wthermal.sed_topflux);

//    if(atms.stw[dm][m] > 10.0){
//      printf("stw!!!!!!!!!!!!!! %f,\n",atms.stw[dm][m]);
//      wthermal.Wthermalmain(atms.stw[dm][m]/100.0, I0, 0.5, lat, Ta_wt, sedthermal.Tsed[0], atms.prec[dm][m]/1000.0, hyd.vap[dm][m], atms.clds[dm][m]); //llc
//      hydm.watertable[dm][m] = 0;
//      sedthermal.Sedmain(wthermal.sed_topflux, Rous, Cps, Porosity, Kss, 1.0);
//    }
//    else{
//      for(zzz=0;zzz<10;zzz++) wthermal.Twater[zzz] = Ta_wt;
//      for(zzz=0;zzz<10;zzz++) sedthermal.Tsed[zzz] = atms.tair[dm][m]+ 273.15;
//    } 


    

     //========================================llc 55555 start to use internal loop for more accurate methane diffusion
     double dt=1.0; //time step hours (0.0,24.0]
     double rdt=24.0; //time step hours
     long int tn;  //time number   
     int stwzone;  

     
     //llc test for soil rootz!!!!!!!!!!!!!!

     //   soil.rootz=0.6;
     //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// initail some values
     stwzone = int (ceil(atms.stw[dm][m]/10.0)); //llc notice stw input should be mm

// llc need to change the thermal module !! 08/22/2016
//   for ( i = 0; i < 400; i++){  
//        ch4dmpro.intersoilt[i] = atms.tair[dm][m];  //input soil temp directly
//   }
     //beginning of ch4 consumption with no inundatonal proportion

  //*diffusion coefficient within the whole column (surface to the low boundary)
     ch4dmdif.EffdfSM(hydm.intersoilm, hydm.intersoilsatsm, totalnodes); 

    if ( hydm.watertable[dm][m] > 0.0) {
    satzone = int (ceil(hydm.watertable[dm][m] / 10.0));		
    for ( i = satzone; i < ceil((ch4dmpro.lowb[veg.cmnt] / 10.0)); i++)
      {
         ch4dmdif.sat = 1;
         ch4dmdif.fdfs[i] = ch4dmdif.Diffusivity(soil.pctsand, soil.pctsilt, soil.pctclay, ch4dmdif.sat);
      }
    for ( i = 0; i < satzone; i++)
       {
         ch4dmdif.sat = 0;
         ch4dmdif.fdfs[i] = ch4dmdif.Diffusivity(soil.pctsand, soil.pctsilt, soil.pctclay, ch4dmdif.sat);
       }
    }
    else {
    ch4dmdif.sat = 1;
      for ( i = 0; i < ceil((ch4dmpro.lowb[veg.cmnt] / 10.0)); i++)
        {
          ch4dmdif.fdfs[i] = ch4dmdif.Diffusivity(soil.pctsand, soil.pctsilt, soil.pctclay, ch4dmdif.sat);
        }
    }
	 

    // oxidation occurred between surface and low boundary for each 1 cm
     ch4dmoxi.consp = 0.0;
     pch4dmoxi.consp = 0.0;
     ch4dmpro.prod = 0.0;
     ch4dmebu.ebuflx[dm][m] = 0.0;
     ch4dmplant.ch4pltflx[dm][m] = 0.0;
     ch4dmdif.ch4flx = 0.0;
     ch4dmplant.tveg = 1.0;

     for ( i = 0; i < int (ceil(ch4dmpro.lowb[veg.cmnt] /10.0)); i++)
     {
     ch4dmdif.ch4oxir[i] = 0.0;
     ch4dmdif.ch4pror[i] = 0.0;
     ch4dmdif.ch4ebur[i] = 0.0;
     ch4dmdif.ch4patr[i] = 0.0;
     ch4dmdif.ch4poxir[i] = 0.0;
     ch4dmdif.ch4disl[i] = 0.0;
     }


     // **. for soil oxidation
      ch4dmoxi.oxygenC(ch4dmoxi.afp[veg.cmnt], ch4dmpro.lowb[veg.cmnt]);
    // ***. Oxidation between water table and the soil surface
      pch4dmoxi.oxygenC(pch4dmoxi.afp[veg.cmnt], ch4dmpro.lowb[veg.cmnt]);



   for ( tn = 0; tn < int(rdt/dt); tn++ )
   {

// llc, methane produce and transport in soil begin!! 
     depthz = 0.0;
     for ( i = 0; i < int (ch4dmpro.lowb[veg.cmnt] /10.0); i++)
      {

//      if (ch4dmdif.ch4flx > 0) printf("%f,\n",ch4dmdif.ch4con[i]);

      ch4dmoxi.fmct = ch4dmoxi.EffectMC(ch4dmdif.ch4con[i], ch4dmoxi.kc[veg.cmnt]);

//      ch4dmoxi.oxygenC(ch4dmoxi.afp[veg.cmnt], ch4dmpro.lowb[veg.cmnt]);  //move to initial part by llc
      ch4dmoxi.foxyt = ch4dmoxi.EffectOXY(ch4dmoxi.oxygenc[i], ch4dmoxi.ko[veg.cmnt]);
      ch4dmoxi.fstt = ch4dmoxi.EffectST(ch4dmpro.intersoilt[i], ch4dmoxi.och4q10[veg.cmnt], ch4dmoxi.oxiref[veg.cmnt]);

   // using soil moisture for each 1 cm to drive the process
      ch4dmoxi.fsmt = ch4dmoxi.EffectSM(ch4dmoxi.mvmin[veg.cmnt], ch4dmoxi.mvmax[veg.cmnt], ch4dmoxi.mvopt[veg.cmnt],
      hydm.intersoilm[i]);

      depthz = (i+1) * 10.0;
      ch4dmpro.ehlt = ch4dmpro.RedoxP(hydm.watertable[dm][m], depthz, soil.pcfldcap, veg.cmnt, ch4dmpro.lowb[veg.cmnt]);
      ch4dmoxi.frxt = ch4dmoxi.EffectRX(ch4dmpro.ehlt);
      ch4dmoxi.fctt = ch4dmoxi.EffectCT(icult);
      ch4dmoxi.ch4oxirate[i] = ch4dmoxi.MethaneOR(ch4dmoxi.omax[veg.cmnt], ch4dmoxi.fmct, ch4dmoxi.foxyt, ch4dmoxi.fstt,
                  ch4dmoxi.fsmt,ch4dmoxi.frxt, ch4dmoxi.fctt )*dt; //llc for dt timestep, oxidation,uM/dt hr
      ch4dmdif.ch4oxir[i] = ch4dmoxi.ch4oxirate[i]; //llc
     // consumption at the upland soils
      ch4dmoxi.consp = ch4dmoxi.consp + ch4dmoxi.ch4oxirate[i] * 0.001 * 1.0; // uM hr-1 > u mol cm-3 hr-1

      } // end for for


	
  // by considering oxidation, the acutual ch4 was uptaked into soil (mg m-2 day-1)

//     ch4dmdif.ch4flx = ch4dmdif.ACH4flxandCon(ch4dmdif.fdf, ch4dmpro.lowb[veg.cmnt]);



    // end of the consumption module

      // water table above soil surface, methanogenesis occured above the low boundary, oxidation only occured as rhizopherix zone
      // transport will include diffusion and ebullision and plant aieded emissions,
     if ( hydm.watertable[dm][m] < 0.0) 
       {

 //      ch4dmdif.ch4emis[dm][m] = 0.0; //llc add for test !! need revise definitely
       }
      else // water table below soil surface
      // for methanogenesis below water table and above low boundary
       {

        satzone = int (ceil(hydm.watertable[dm][m] / 10.0));
        depthz =0.0;

        for ( i = 0.0; i < ceil((ch4dmpro.lowb[veg.cmnt] / 10.0)); i++)
         {    
            if ( ch4dmpro.suborg[dm][m] <= 0.0)  ch4dmpro.suborg[dm][m] = 0.01;
	
            ch4dmpro.fsomt = ch4dmpro.EffectOM(ch4dmpro.maxfresh[veg.cmnt], ch4dmpro.suborg[dm][m]); //llc pro test
            //printf("test production,%f,%f,\n",ch4dmpro.maxfresh[veg.cmnt],ch4dmpro.suborg[dm][m]);
            depthz = (i+1.0) * 10.0; //llc fix
            
         
 
            ch4dmpro.fcdist = ch4dmpro.EffectOMD(veg.cmnt, depthz-satzone*10.0, soil.rootz-satzone*0.01, ch4dmpro.lowb[veg.cmnt]-satzone*0.01); //llc fix!!

            //printf("%i  T=%f,vegt=%i,Q10=%f,refT=%f,\n",i,ch4dmpro.intersoilt[i],veg.cmnt,ch4dmpro.pmethaneq[veg.cmnt],ch4dmpro.proref[veg.cmnt]);
            ch4dmpro.fmstt = ch4dmpro.EffectST( ch4dmpro.intersoilt[i], ch4dmpro.pmethaneq[veg.cmnt],ch4dmpro.proref[veg.cmnt], veg.cmnt);

           //ch4dmpro.fmstt = ch4dmpro.EffectST( atms.tsoil[dm][m], ch4dmpro.pch4q10[veg.cmnt],ch4dmpro.proref[veg.cmnt]);
            ch4dmpro.fpht =  ch4dmpro.EffectPH(ph);
	
            ch4dmpro.ehlt = ch4dmpro.RedoxP(hydm.watertable[dm][m], depthz, soil.pcfldcap, veg.cmnt, ch4dmpro.lowb[veg.cmnt]);

            ch4dmpro.frxt = ch4dmpro.EffectRX(ch4dmpro.ehlt);

            ch4dmpro.ch4rate[i] = ch4dmpro.MethanePR( ch4dmpro.mgo[veg.cmnt], ch4dmpro.fsomt, ch4dmpro.fcdist,
                                ch4dmpro.fmstt,ch4dmpro.fpht,ch4dmpro.frxt)*dt;   // uM h-1    llc for finer timpstep, production
//llc test03://////////////


            //printf("%i,%i,%f,%f,\n",i,satzone,soil.rootz,ch4dmpro.ch4rate[i]);  
	    //break;	    
//           ch4dmpro.ch4rate[i] = ch4dmpro.ch4rate[i]*f_orgm;//llc for Jinsha test!!!
           ch4dmpro.ch4rate[i] = ch4dmpro.ch4rate[i];//llc for cuini itu
//////////////////
            ch4dmdif.ch4pror[i] = ch4dmpro.ch4rate[i]; //llc


            ch4dmpro.prod = ch4dmpro.prod + ch4dmpro.ch4rate[i]*0.001*1.0; // uM hr-1 > u mol cm-3 hr-1
	    
	    //if(i==70) {
	    //printf(" %3.5f %3.5f %3.5f %3.5f %3.5f %3.5f \n", ch4dmpro.fsomt, ch4dmpro.fcdist,ch4dmpro.fmstt,ch4dmpro.fpht,ch4dmpro.frxt, ch4dmpro.ch4rate[i]);}

         }



  // ebullition occurred between water table and lower boundary
        ch4dmebu.ch4thresh = ch4dmebu.threshold();

     ch4dmdif.ch4ebur_p = 0.0;
     for (i = ceil((ch4dmpro.lowb[veg.cmnt] / 10.0))-1; i >= 0 ; i--)
      {
//      printf("concentration = %f, threshold = %f, \n",ch4dmdif.ch4con[i], ch4dmebu.ch4thresh);
	//llc test for threthhold (uM)*************************
	ch4dmebu.ch4thresh = 500.0;
	//****************************************************
      ch4dmebu.ch4ebuflx[i] = ch4dmebu.CH4ebuR(ch4dmdif.ch4con[i], ch4dmebu.ch4thresh )*dt; //llc for finer timpstep, ebullition
      ch4dmdif.ch4ebur[i] = ch4dmebu.ch4ebuflx[i]; //llc     
      ch4dmebu.ebuflx[dm][m] = ch4dmebu.ebuflx[dm][m]+ ch4dmdif.ch4ebur[i]*0.001 * 1.0; // uM hr-1 > u mol cm-3 hr-1
     //integration for the water zone to get total ch4 ebullition flux
      }



   z =0.0;
   for (i = satzone; i < ceil((ch4dmpro.lowb[veg.cmnt] / 10.0)); i++)  //llc fixed
    {
      z = (i+1.0) * 10.0;
 //     ch4dmpro.ch4rate[i] = ch4dmpro.ch4rate[i] - ch4dmebu.ch4ebuflx[i]; // subtract the ebullition rate for plant-aided

      ch4dmplant.froott = ch4dmplant.froot(soil.rootz, z); //llc for test
      ch4dmplant.fgrowt = ch4dmplant.fgrow(ch4dmpro.intersoilt[i]);
      ch4dmplant.ch4plantr[i] = ch4dmplant.CH4plR(ch4dmplant.tveg, ch4dmplant.froott, ch4dmplant.fgrowt, ch4dmdif.ch4con[i])*dt; //llc for finer timpstep, PA transport

//llc test02://////////////

      ch4dmplant.ch4plantr[i] = ch4dmplant.ch4plantr[i]; //llc test

//////////////////
      // the change of ch4 concentration at ith layer
//      ch4dmpro.ch4rate[i] = ch4dmpro.ch4rate[i] - ch4dmplant.ch4plantr[i]- ch4dmebu.ch4ebuflx[i]; 
//      ch4dmdif.ch4ratesat[i] = ch4dmpro.ch4rate[i];

     // Rhisopheric oxidation account for 40% of ch4plantr[i], the rest is transported
      ch4dmplant.ch4plantr[i] = ch4dmplant.ch4plantr[i] * 0.4; // consider the addtional 40% oxidation for the total oxidation
      ch4dmdif.ch4patr[i] = ch4dmplant.ch4plantr[i]; //llc
      ch4dmplant.ch4pltflx[dm][m] = ch4dmplant.ch4pltflx[dm][m] + ch4dmplant.ch4plantr[i]*0.001*1.0; // uM hr-1 > u mol cm-3 hr-1
   }


    // to redistribute the ch4 in the soil profile
  //   ch4dmdif.ch4flx = ch4dmdif.BCH4flxandCon(ch4dmpro.lowb[veg.cmnt],hydm.watertable[dm][m] );

//llc remove for test!!!

  // 2. Oxidation between water table and the soil surface
    depthz = 0.0;
    for ( i = 0; i < satzone; i++)
    {
      pch4dmoxi.fmct = pch4dmoxi.EffectMC(ch4dmdif.ch4con[i], pch4dmoxi.kc[veg.cmnt]);
      pch4dmoxi.foxyt = pch4dmoxi.EffectOXY(ch4dmoxi.oxygenc[i], ch4dmoxi.ko[veg.cmnt]);
      pch4dmoxi.fstt = pch4dmoxi.EffectST(ch4dmpro.intersoilt[i], pch4dmoxi.och4q10[veg.cmnt],pch4dmoxi.oxiref[veg.cmnt]);

      pch4dmoxi.fsmt = ch4dmoxi.EffectSM(pch4dmoxi.mvmin[veg.cmnt], pch4dmoxi.mvmax[veg.cmnt], pch4dmoxi.mvopt[veg.cmnt],
                    hydm.unsatthetaWL[i]);

      depthz = (i+1) * 10.0;
      ch4dmpro.ehlt = ch4dmpro.RedoxP(hydm.watertable[dm][m], depthz, soil.pcfldcap, veg.cmnt,ch4dmpro.lowb[veg.cmnt] );
      pch4dmoxi.frxt = pch4dmoxi.EffectRX(ch4dmpro.ehlt);

      pch4dmoxi.fctt = pch4dmoxi.EffectCT(icult);
      pch4dmoxi.ch4oxirate[i] = pch4dmoxi.MethaneOR(pch4dmoxi.omax[veg.cmnt], pch4dmoxi.fmct, pch4dmoxi.foxyt, pch4dmoxi.fstt,
                  pch4dmoxi.fsmt,pch4dmoxi.frxt, pch4dmoxi.fctt )*dt;  //llc for finer time step poxidation !!!!!!!!!! need revise!!!!!!!!!!! llc 11/20/2017, replace oxi_c to omax; 
      ch4dmdif.ch4poxir[i] = pch4dmoxi.ch4oxirate[i]; //llc

      pch4dmoxi.consp = pch4dmoxi.consp + pch4dmoxi.ch4oxirate[i] * 0.001 * 1.0; // uM hr-1 > u mol cm-3 hr-1
    }


 // 3. implement diffusion to calculate the concentration and eflux at equllibrium state
     ch4dmdif.ch4flx = ch4dmdif.ch4flx + ch4dmdif.FCH4flxandCon(ch4dmpro.lowb[veg.cmnt],hydm.watertable[dm][m], atms.tsoil[dm][m],dt);
    
//     if(ch4dmdif.ch4flx < -200) printf("!!!error: %f,%f,%f,\n",hydm.watertable[dm][m], atms.tsoil[dm][m], atms.prec[dm][m]); 
    } // ended of else of water table below soil surface

   } //======================================================================================internal loop end


    //llc move to here for consumption

      // added on 17 July 2003, Q. Zhuang, revised by llc
     if (atms.tsoil[dm][m] < -1.0) ch4dmoxi.consp = 0.0; // assume under lower temperature (< -1.0), there is no consumption
    //only a proportion of the grid cell
     if ((frin >= 99999.0) || (frin <= -99999.0)) frin = 10000.0;   //llc fix < to <=
     ch4dmdif.ch4cons[dm][m] = ch4dmoxi.consp * (1.0 - (frin / 10000.0)) * pow(10,4) * pow(10,-6) * 16.0 * pow(10,3); //u mol cm-2 day-1 to mg m-2 day-1
     if ((ch4dmdif.ch4cons[dm][m] < -999999.0) || (ch4dmdif.ch4cons[dm][m] > 999999.0))
       ch4dmdif.ch4cons[dm][m] = -999999.0;

    ch4dmpro.prod = ch4dmpro.prod * pow(10,4) * pow(10,-6) * 16.0 * pow(10,3); //u mol cm-2 day-1 to mg m-2 day-1;
    ch4dmebu.ebuflx[dm][m] = ch4dmebu.ebuflx[dm][m] * pow(10,4) * pow(10,-6) * 16.0 * pow(10,3); //u mol cm-2 day-1 to mg m-2 day-1;
    ch4dmplant.ch4pltflx[dm][m] = ch4dmplant.ch4pltflx[dm][m] * pow(10,4) * pow(10,-6) * 16.0 * pow(10,3); //u mol cm-2 day-1 to mg m-2 day-1;
    ch4dmdif.ch4emis[dm][m] =   ch4dmdif.ch4flx - ch4dmebu.ebuflx[dm][m] - ch4dmplant.ch4pltflx[dm][m];  //llc 
   if(-ch4dmdif.ch4emis[dm][m] > 2.0*ch4dmpro.prod){ch4dmdif.ch4emis[dm][m] = -ch4dmpro.prod;} ////llc for Jinsha test!!!

//=====================================================================================
// Youmi Oh added methane isotope module on May 20 2018
//=====================================================================================
// main fluxes needed for isotope calculation:
// methane emission - ch4dpro.prod (mg/m2/day)
// methane consumption in wetland - pch4dmoxi.consp* pow(10,4) * pow(10,-6) * 16.0 * pow(10,3) (mg/m2/day)
// methane ebullition - ch4dmebu.ebuflx (mg/m2/day) POSITIVE to air
// methane diffusion - ch4dmdif.ch4flx (mg/m2/day) NEGATIVE to air
// methane plant-mediated transport - ch4dmplant.ch4pltflx (mg/m2/day) POSITIVE to air

//   double d13ch4_init, d13ch4_prod_hm, d13ch4_prod_am, d13ch4_prod;
//   double mo_mp_frac, d13ch4_oxid;
//   double d13ch4_tp, d13ch4_td, d13ch4_te, tp_frac, td_frac, te_frac, d13ch4_final, dif_pos, oxid_sfc;

// Step 0. setup fractionation factors, C4 portion, and % of hydrogenotrophic methanogen
// later this factor will be calibrated and simulated according to the equations
// delta unit is permil 

// fractionation factors has a form of ch4dmpro.alpha[veg.cmnt]
// currently I use default values from Deng 2017 but will be calibrated for different vegetation types
//   double alpha_am = 1.016; // acetoclastic methanogen
//   double alpha_hm = 1.045; // hydrogenotrophic methanogen
//   double alpha_mo = 1.022; // methane oxidation
//   double alpha_tp = 1.008; // plant-mediated transport
//   double alpha_te = 1.000; // ebullition
//   double alpha_td = 1.001; // diffusion

// TEST SITE 1: Canada (lat 56N, long -98.5)
//   double c4_frac = 0.  ; // Still (2003)
//   double hm_frac = 0.6 ; // calibrated by the multiple regression of pH, soil carbon, and latitude

// TEST SITE 2: Costa Rica (lat 10.5N, long -85.5)
//   double c4_frac = 0.5 ; 
//   double hm_frac = 0.35 ;


// after adding global c4 frac file, now is c4 (%) 
   double c4_frac = c4 * 0.01;
   double oxid_sfc, dif_pos, d13ch4_prod_hm,d13ch4_prod_am,d13ch4_tp,d13ch4_te,d13ch4_td;

    ch4dmdif.d13init[dm][m]=0.0;
    ch4dmdif.d13prod[dm][m]=0.0;
    ch4dmdif.d13oxid[dm][m]=0.0;
    ch4dmdif.d13final[dm][m]=0.0;
    ch4dmdif.mompfrac[dm][m]=0.0;
    ch4dmdif.tpfrac[dm][m]=0.0;
    ch4dmdif.tefrac[dm][m]=0.0;
    ch4dmdif.tdfrac[dm][m]=0.0;
    ch4dmdif.mompfracplt[dm][m]=0.0;
    ch4dmdif.d13oxidplt[dm][m]=0.0;

   // fraction of hydrogenotrophic methanogen (Feb 19 2019 Youmi Oh)
   double hm_frac;
   double lat_step1 = 60; //test jun 16 youmi oh
   double lat_step2 = 0; //20
   // based on multiple regression analysis of data from Holmes (2014)
   // updated on may 30 using a proper TC
   if (lat > lat_step1) {
     hm_frac = 0.033*lat +5.865*(lat-lat_step1) -9.554*ph -1.031*toc +108.583; //toc to 35 (test mar 2019 youmi oh)
   } else if (lat > lat_step2) {
     hm_frac = 0.033*lat -9.554*ph -1.031*toc +108.583;
   } else {
     hm_frac = -0.033*lat -9.554*ph -1.031*toc +108.583;} //assume it for now that it is same as hm_frac at the equator, to verify it we need data

   if (hm_frac > 100.0) hm_frac = 100.0;
   if (hm_frac < 0.0) hm_frac = 0.0; // lower boundary mar 2019 youmi oh

// Step 1: d13CH4 after methane production
   ch4dmdif.d13init[dm][m] = -27*(1-c4_frac) -13*(c4_frac); //we can change this part or assume it
   d13ch4_prod_hm = ch4dmdif.d13init[dm][m] - 1000*log(ch4dmpro.alpha_hm[veg.cmnt]);
   d13ch4_prod_am = ch4dmdif.d13init[dm][m] - 1000*log(ch4dmpro.alpha_am[veg.cmnt]);
   ch4dmdif.d13prod[dm][m] = ((hm_frac*0.01)*d13ch4_prod_hm) + ((1-(hm_frac*0.01))*d13ch4_prod_am);

// Step 2-1: d13CH4 after methane oxidation from diffusion
   oxid_sfc = pch4dmoxi.consp * pow(10,4) * pow(10,-6) * 16.0 * pow(10,3); //u mol cm-2 day-1 to mg m-2 day-1

   //recalculated produced methane: account for emitted amount + two oxidation processes
   ch4dmpro.prod = -ch4dmdif.ch4emis[dm][m] + oxid_sfc + ch4dmplant.ch4pltflx[dm][m]*0.66;
   //printf("%i,%i,%i,%f %f %f %f \n",dyr,dm,m,ch4dmpro.prod, -ch4dmdif.ch4emis[dm][m],oxid_sfc,ch4dmplant.ch4pltflx[dm][m]*0.66); 

   ch4dmdif.mompfrac[dm][m] = oxid_sfc / ch4dmpro.prod; //0.35;
   if (ch4dmdif.mompfrac[dm][m] > 1.0) { ch4dmdif.mompfrac[dm][m] = 1.0; }
   if (ch4dmdif.mompfrac[dm][m] < 0.0) { ch4dmdif.mompfrac[dm][m] = 0.0; }
   ch4dmdif.d13oxid[dm][m] = (ch4dmdif.d13prod[dm][m]-1000*ch4dmdif.mompfrac[dm][m]*((1/ch4dmpro.alpha_mo[veg.cmnt])-1))/(ch4dmdif.mompfrac[dm][m]*((1/ch4dmpro.alpha_mo[veg.cmnt])-1)+1);

// Step 2-2: d13CH4 after methane oxidation from plant-mediated transport - 40% oxidized, 60% emitted
   //ch4dmplant.ch4pltflx[dm][m] = ch4dmplant.ch4pltflx[dm][m] * pow(10,4) * pow(10,-6) * 16.0 * pow(10,3); //u mol cm-2 day-1 to mg m-2 day-1;
   ch4dmdif.mompfracplt[dm][m] = ch4dmplant.ch4pltflx[dm][m]*0.66 / ch4dmpro.prod;
   if (ch4dmdif.mompfracplt[dm][m] > 1.0) {ch4dmdif.mompfracplt[dm][m] = 1.0;}
   if (ch4dmdif.mompfracplt[dm][m] < 0.0) { ch4dmdif.mompfracplt[dm][m] = 0.0; } 
   ch4dmdif.d13oxidplt[dm][m] = (ch4dmdif.d13prod[dm][m]-1000*ch4dmdif.mompfracplt[dm][m]*((1/ch4dmpro.alpha_mo[veg.cmnt])-1))/(ch4dmdif.mompfracplt[dm][m]*((1/ch4dmpro.alpha_mo[veg.cmnt])-1)+1);

// Step 3: d13CH4 after methane transport
   d13ch4_tp = ch4dmdif.d13oxidplt[dm][m] - 1000*log(ch4dmpro.alpha_tp[veg.cmnt]);
   d13ch4_td = ch4dmdif.d13oxid[dm][m] - 1000*log(ch4dmpro.alpha_td[veg.cmnt]);
   d13ch4_te = ch4dmdif.d13prod[dm][m] - 1000*log(ch4dmpro.alpha_te[veg.cmnt]);
   
   if (ch4dmdif.ch4emis[dm][m] < 0.0) { // flux to air
     if ( ch4dmdif.ch4flx > 0.0 ) { 
       dif_pos = 0.0; 
     } else {
       dif_pos = ch4dmdif.ch4flx; }  
     ch4dmdif.tpfrac[dm][m] = -ch4dmplant.ch4pltflx[dm][m] / (dif_pos - ch4dmebu.ebuflx[dm][m] - ch4dmplant.ch4pltflx[dm][m]); 
     ch4dmdif.tdfrac[dm][m] = dif_pos / (dif_pos - ch4dmebu.ebuflx[dm][m] - ch4dmplant.ch4pltflx[dm][m]); 
     ch4dmdif.tefrac[dm][m] = -ch4dmebu.ebuflx[dm][m] / (dif_pos - ch4dmebu.ebuflx[dm][m] - ch4dmplant.ch4pltflx[dm][m]); 
     ch4dmdif.d13final[dm][m] = (ch4dmdif.tpfrac[dm][m]*d13ch4_tp) + (ch4dmdif.tdfrac[dm][m]*d13ch4_td) + (ch4dmdif.tefrac[dm][m]*d13ch4_te);
     } else {
     ch4dmdif.tdfrac[dm][m] = 0.0;
     ch4dmdif.tefrac[dm][m] = 0.0; // no fractionation
     ch4dmdif.tpfrac[dm][m] = 1.0;
     ch4dmdif.d13final[dm][m]= ch4dmdif.d13oxidplt[dm][m]; //assume that when methane is not emitted, it is all consumed by LAM through diffusion
   }
   //printf("%i,%i,%i,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f \n",dyr,dm,m,c4_frac,hm_frac,ch4dmdif.d13init[dm][m],ch4dmdif.d13prod[dm][m],ch4dmdif.mompfrac[dm][m], ch4dmdif.mompfracplt[dm][m],ch4dmdif.d13oxid[dm][m],ch4dmdif.d13oxidplt[dm][m],ch4dmdif.tpfrac[dm][m],ch4dmdif.tdfrac[dm][m],ch4dmdif.tefrac[dm][m],ch4dmdif.d13final[dm][m],ch4dmdif.ch4emis[dm][m]); //Youmi Oh Test
   //printf("%f,%f,%f,%f,%f,%f \n", ch4dmpro.alpha_am[veg.cmnt],ch4dmpro.alpha_hm[veg.cmnt],ch4dmpro.alpha_mo[veg.cmnt],ch4dmpro.alpha_tp[veg.cmnt],ch4dmpro.alpha_te[veg.cmnt],ch4dmpro.alpha_td[veg.cmnt]); //test
   //printf("%f,%f,%f,%f,%f,%f,%f \n", d13ch4_tp,d13ch4_td,d13ch4_te,ch4dmdif.tpfrac[dm][m],ch4dmdif.tdfrac[dm][m],ch4dmdif.tefrac[dm][m],ch4dmdif.d13final[dm][m]); //test

   //printf("%i,%i,%i,%f \n",dyr,dm,m,ch4dmdif.d13final[dm][m]); // Youmi Oh for calibration

//=====================================================================================

   //llc for monthly output

   /*

     int year = atms.tairyear[dyr];
     int days = daysnumber(dm, year);:

   if(m == days-1){

     double ch4_monthly=0.0;

     for(i=0;i<days;i++){ch4_monthly=ch4_monthly - ch4dmdif.ch4emis[dm][m];}
     ch4_monthly=ch4_monthly/float(days);
     printf("%i,%i,%f \n",dyr,dm,ch4_monthly); //llc test
     
   }
   */

   //  printf("%i,%i,%i,%f,%f,%f,%f,%f,%f,%f, \n",dyr,dm,m,ch4dmdif.ch4emis[dm][m],ch4dmdif.ch4flx,ch4dmebu.ebuflx[dm][m],ch4dmplant.ch4pltflx[dm][m],ch4dmpro.prod,ch4dmoxi.consp,pch4dmoxi.consp); //llc test

 //    printf("%f,%f,%f,%f,%f,\n",Ta_wt,ch4dmpro.intersoilt[stwzone+1],ch4dmpro.EffectST( ch4dmpro.intersoilt[stwzone+1], ch4dmpro.pmethaneq[veg.cmnt],ch4dmpro.proref[veg.cmnt], veg.cmnt),ch4dmpro.ch4rate[stwzone+1],ch4dmpro.prod);

   //***************************************************output llc*********************************
 //        printf("%f,%f,%f,%f,%f,\n",ch4dmdif.ch4emis[dm][m], -ch4dmdif.ch4flx,ch4dmpro.prod,ch4dmebu.ebuflx[dm][m],ch4dmplant.ch4pltflx[dm][m]);//llc output
 //  printf("%i,%i,%i,%f\n",dyr,dm,m,-ch4dmdif.ch4emis[dm][m]);//llc output

   //llc for soil concentration
   
   ch4dmdif.ch4sc[dm][m]=0.0;

   for (i = 0; i < ceil((soil.rootz*100.0)); i++) {
     ch4dmdif.ch4sc[dm][m]=ch4dmdif.ch4sc[dm][m]+ch4dmdif.ch4con[i];      
   }
   ch4dmdif.ch4sc[dm][m] = ch4dmdif.ch4sc[dm][m]/(soil.rootz*100.0)*22.4; //convert uM to ppmv


   /* //******************************************************************PMFB fluxes calculations llc, refer to IDL pro

   double dy=0.1,dx=0.02;
   double D_x=0.00000791,D_y=0.002796;
   double c_air=2.0/22.4*12.0;
   double ymax=5.0,xmax=40.0/100.0/2.0;
   int ny=int(ymax/dy),nx=int(xmax/dx);
   int nt=3000;
   double flux1[ny];
   double dt_max=(pow(dx,2.0)*pow(dy,2.0))/(2.0*(D_y*pow(dx,2.0)+D_x*pow(dy,2.0)));
   double pmfb_dt=dt_max-dt_max/10.0;
   double c_stem[2*(nx+1)][ny+1][nt+1];
   c_stem[:][0][:]=ch4dmdif.ch4sc[dm][m];
   c_stem[0][:][:]=c_air;
   c_stem[2*nx+1][:][:]=c_air;
   c_stem[:][ny+1][:]=c_air;
   double alpha=D_x*dt/pow(dx,2.0),beta=D_y*dt/pow(dy,2.0);
   int tt,xx,yy;

   for ( tt = 1; tt < nt+1; tt++ ){
     for(xx=1;xx<2*nx+1;xx++){
       for(yy=1;yy<ny+1;yy++){
	 c_stem[xx][yy][tt]= alpha*(c_stem[xx+1][yy][tt-1]+c_stem[xx-1][yy][tt-1]) + beta*(c_stem[xx][yy+1][tt-1]+c_stem[xx][yy-1][tt-1]) + (1-2*alpha-2*beta)*c_stem[xx][yy][tt-1];
       }
     }   
   }

   for (yy=1;yy<ny+1;yy++){
     flux1[yy-1]=D_x*(c_stem[1][yy][nt]-c_stem[0][yy][nt])/dx*3600.0;
   }

   double darea=2.0*3.14*xmax*0.1;
   double fluxpertree=0.0;
   for (yy=0;yy<ny;yy++){
     fluxpertree=fluxpertree+flux1[yy]*darea;
   }
   printf("fluxes = %f,\n",fluxpertree);
   
   //****************************************************************** */


   
   //  if(dyr > 20 ) {printf("%i,%i,%i,%f,%f,%f,\n",dyr,dm,m,hydm.watertable[dm][m],atms.prec[dm][m],ch4dmdif.ch4sc[dm][m]);}//llc test

    //    if(dyr == 32 && dm == 5 && m == 3) {

    // printf("Start methane soil concentration output for year=%i, month=%i, day=%i, lowb=%f (mm),stw=%f, \n ",dyr+2011-21,dm+1,m+1,ch4dmpro.lowb[veg.cmnt], atms.stw[dm][m]);

    //   for (i = 0; i < ceil((ch4dmpro.lowb[veg.cmnt] / 10.0)); i++) {

    //   printf("%i,%f,\n",i,ch4dmdif.ch4con[i]);
     
    //   }

     
    // }
   
   /*

   if(dyr == 23 && dm == 6 && m == 18) {

     printf("Start methane soil concentration output for year=%i, month=%i, day=%i, lowb=%f (mm), rootz=%f, stw=%f,\n ",dyr+2011-21,dm+1,m+1,ch4dmpro.lowb[veg.cmnt], soil.rootz, atms.stw[dm][m]);
     //    printf("water situation: watertable=%f,\n",hydm.watertable[dm][m]);//llc test

     for (i = 0; i < ceil((ch4dmpro.lowb[veg.cmnt] / 10.0)); i++) {

       printf("%i,%f,\n",i,ch4dmdif.ch4con[i]);
       //    printf("%f,%f,%f,%f,%f,%f,%f \n",ch4dmdif.ch4pror[i], ch4dmdif.ch4ebur[i],ch4dmdif.ch4patr[i],ch4dmdif.ch4oxir[i],ch4dmdif.ch4poxir[i], hydm.intersoilm[i],hydm.intersoilsatsm[i]); //llc test
       
       //     printf("%f",ch4dmplant.ch4plantr[i]);//test llc
     }


     
   }

      if(dyr == 23 && dm == 8 && m == 15) {

	printf("Start methane soil concentration output for year=%i, month=%i, day=%i, lowb=%f (mm), stw=%f, \n ",dyr+2011-21,dm+1,m+1,ch4dmpro.lowb[veg.cmnt], atms.stw[dm][m]);

     for (i = 0; i < ceil((ch4dmpro.lowb[veg.cmnt] / 10.0)); i++) {

       printf("%i,%f,\n",i,ch4dmdif.ch4con[i]);
       
     }

     
   }

      if(dyr == 24 && dm == 3 && m == 10) {

     printf("Start methane soil concentration output for year=%i, month=%i, day=%i, lowb=%f (mm),stw=%f, \n ",dyr+2011-21,dm+1,m+1,ch4dmpro.lowb[veg.cmnt], atms.stw[dm][m]);

     for (i = 0; i < ceil((ch4dmpro.lowb[veg.cmnt] / 10.0)); i++) {

       printf("%i,%f,\n",i,ch4dmdif.ch4con[i]);
       
     }

     
   }

    if(dyr == 24 && dm == 5 && m == 3) {

     printf("Start methane soil concentration output for year=%i, month=%i, day=%i, lowb=%f (mm),stw=%f, \n ",dyr+2011-21,dm+1,m+1,ch4dmpro.lowb[veg.cmnt], atms.stw[dm][m]);

     for (i = 0; i < ceil((ch4dmpro.lowb[veg.cmnt] / 10.0)); i++) {

       printf("%i,%f,\n",i,ch4dmdif.ch4con[i]);
       
     }

     
   }
   */
   
   //*********************************************************************************************
	 //   printf("%i, %i, %i,\n",dyr,dm,m);
//    printf("%f,%f,%f,%f,%f,\n",ch4dmdif.ch4emis[dm][m], -ch4dmdif.ch4flx,atms.tsoil[dm][m],ch4dmebu.ebuflx[dm][m],ch4dmplant.ch4pltflx[dm][m]);

 //4. percentage of area of the grid cell inundated
      if ((frin >= 99999.0) || (frin <= -99999.0)) frin = 10000.0; //llc fix < to <=
      ch4dmdif.ch4emis[dm][m] = ch4dmdif.ch4emis[dm][m] * (frin / 10000.0);
      ch4dmpro.prod = ch4dmpro.prod * (frin / 10000.0);
      ch4dmebu.ebuflx[dm][m] = ch4dmebu.ebuflx[dm][m] * (frin / 10000.0);
      ch4dmplant.ch4pltflx[dm][m] = ch4dmplant.ch4pltflx[dm][m] * (frin / 10000.0);
      
  //    printf("ch4emis=%f, ch4flx=%f, pro=%f, ebu=%f,plt=%f,\n",ch4dmdif.ch4emis[dm][m], ch4dmdif.ch4flx,ch4dmpro.prod,ch4dmebu.ebuflx[dm][m],ch4dmplant.ch4pltflx[dm][m]);//llc


   if ((ch4dmdif.ch4emis[dm][m] < -999999.0) || (ch4dmdif.ch4emis[dm][m] > 999999.0))
       ch4dmdif.ch4emis[dm][m] = -999999.0;
  
 } //end for wetland

   //    printf("model results: %i,%i,%i,%f,%f,\n",dyr,dm,m,ch4dmdif.ch4emis[dm][m], atms.tair[dm][m]);//llctest

 // total eflfuxes for the gridcell
  ch4dmdif.ch4tot[dm][m] = ch4dmdif.ch4emis[dm][m] + ch4dmdif.ch4cons[dm][m];

  if ((ch4dmdif.ch4tot[dm][m] < -999999.0) || (ch4dmdif.ch4tot[dm][m] > 999999.0))
     ch4dmdif.ch4tot[dm][m] = -999999.0;

 // Determine previous two day's air temperatures with the following
    switch (dm)
    {
    case 0:  if (m==0)
              {
               atms.prevtair = atms.tair[1][0];
               atms.prev2tair = atms.tair[1][1];
              }
              else
               {
                if (m ==1){
               atms.prevtair = atms.tair[0][29];
               atms.prev2tair = atms.tair[0][30];
                 }
               else
                {
               atms.prevtair = atms.tair[0][m-1];
               atms.prev2tair = atms.tair[0][m-2];
                }
               }
             break;

    default:
             if (m==0)
              {
               atms.prevtair = atms.tair[dm][0];
               atms.prev2tair = atms.tair[dm][1];
              }
              else
               {
                if (m ==1){
               atms.prevtair = atms.tair[dm][29];
               atms.prev2tair = atms.tair[dm][30];
                 }
               else
                {
               atms.prevtair = atms.tair[dm][m-1];
               atms.prev2tair = atms.tair[dm][m-2];
                }
               }
             break;
      }

 

  // Determine contribution of snowmelt to soil moisture
//??? Think about this also Jan/07/2003
  soil.snowinf[dm][m] = soil.snowmelt(elev, atms.tair[dm][m],
                                   atms.prevtair, y[I_SNWPCK]);

//  monthxclm(veg.cmnt, veg.topt, dm, m);

};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************* */

void TTEM::getsitecd(ofstream& rflog1)
{

  char ecd[80];

  cout << "Enter name of the site (.ECD) data file with the parameter values:";
  cout << endl;
  fpara >> ecd;

  rflog1 << "Enter name of the site (.ECD) data file with the parameter values:";
  rflog1 << ecd << endl << endl;

  getsitecd(ecd);

};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************* */

void TTEM::getsitecd(const int& numcmnt, ofstream& rflog1)
{

  int dv;
  char ecd[80];

  cout << "Enter name of the site (.ECD) data file with the parameter values  for cmnt" << endl;
  rflog1 << "Enter name of the site (.ECD) data file with the parameter values cmnt" << endl;
  for (dv = 0; dv < numcmnt; dv++)
  {
    cout << (dv+1) << ": ";
    fpara >> ecd;

    rflog1 << (dv+1) << ": " << ecd << endl;

    getsitecd(dv, ecd);
  }
  rflog1 << endl;

};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************* */

void TTEM::getsitecd(char ecd[80])
{

  const int NUMVAR = 52;
  char dummy[NUMVAR][10];
  ifstream infile;
  int i;
  int dcmnt;

  int sitetveg[MAXCMNT];
  int sitewsoil[MAXCMNT];
  long update[MAXCMNT];
  char sitevegtype[MAXCMNT][31];
  char sitename[MAXCMNT][17];
  char sitetext[MAXCMNT][14];
  float sitecol[MAXCMNT];
  float siterow[MAXCMNT];
  t_snowpack=0.0;
  infile.open(ecd, ios::in);

  for (i = 0; i < NUMVAR; i++) { infile >> dummy[i]; }
  for (dcmnt = 0; dcmnt < MAXCMNT; dcmnt++)
  {
    infile >> sitetveg[dcmnt] >> sitevegtype[dcmnt];
    infile >> sitecol[dcmnt] >> siterow[dcmnt];
    infile >> sitename[dcmnt] >> sitetext[dcmnt] >> sitewsoil[dcmnt];
    infile >> vegca[dcmnt] >> vegcb[dcmnt];
    infile >> strna[dcmnt] >> strnb[dcmnt];
    infile >> solca[dcmnt] >> solcb[dcmnt];
    infile >> solna[dcmnt] >> solnb[dcmnt];
    infile >> avlna[dcmnt] >> avlnb[dcmnt];
    infile >> stona[dcmnt] >> stonb[dcmnt];
    infile >> veg.unleaf12[dcmnt];
    infile >> veg.initleafmx[dcmnt];      // Changed by DWK on 19991028
    infile >> veg.cmaxcut[dcmnt];
    infile >> veg.cmax1a[dcmnt] >> veg.cmax1b[dcmnt];
    infile >> veg.cmax2a[dcmnt] >> veg.cmax2b[dcmnt];
    infile >> veg.cfall[dcmnt];
    infile >> veg.kra[dcmnt] >> veg.krb[dcmnt];
    infile >> microbe.kda[dcmnt] >> microbe.kdb[dcmnt];
    infile >> microbe.lcclnc[dcmnt] >> microbe.propftos[dcmnt];
    infile >> veg.nmaxcut[dcmnt];
    infile >> veg.nmax1a[dcmnt] >> veg.nmax1b[dcmnt];
    infile >> veg.nmax2a[dcmnt] >> veg.nmax2b[dcmnt];
    infile >> veg.nfall[dcmnt];
    infile >> microbe.nupa[dcmnt] >> microbe.nupb[dcmnt];
    infile >> soil.nloss[dcmnt];
    infile >> microbe.nfixpar[dcmnt];
    infile >> veg.initcneven[dcmnt] >> veg.cnmin[dcmnt];
    infile >> veg.c2na[dcmnt] >> veg.c2nb[dcmnt] >> veg.c2nmin[dcmnt];
    infile >> microbe.cnsoil[dcmnt];
    infile >> update[dcmnt];

//    veg.initcneven[i] = veg.cneven[i];
//    veg.adjc2n = 1.0 + (veg.dc2n * (atms.co2[11] - atms.initco2));
//    veg.cneven[i] = veg.initcneven[i] * veg.adjc2n;
  }

  infile.close();

};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************* */

void TTEM::getsitecd(const int& dv, char ecd[80])
{
  // Function added by DWK on 20000102

  char dummy[12];
  // string changed to char[80] by DWK on 20000210
  char sitename[80];
  float sitecol;
  float siterow;
  long updated;

  fecd[dv].open(ecd,ios::in);

  if (!fecd[dv])
  {
    cerr << endl << "Cannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  fecd[dv] >> dummy >> veg.cmnt;
  fecd[dv] >> dummy >> veg.cmnt_name;
  fecd[dv] >> dummy >> sitename;
  fecd[dv] >> dummy >> sitecol;
  fecd[dv] >> dummy >> siterow;
  fecd[dv] >> dummy >> updated;

  fecd[dv] >> dummy >> vegca[veg.cmnt];
  fecd[dv] >> dummy >> vegcb[veg.cmnt];
  fecd[dv] >> dummy >> strna[veg.cmnt];
  fecd[dv] >> dummy >> strnb[veg.cmnt];
  fecd[dv] >> dummy >> solca[veg.cmnt];
  fecd[dv] >> dummy >> solcb[veg.cmnt];
  fecd[dv] >> dummy >> solna[veg.cmnt];
  fecd[dv] >> dummy >> solnb[veg.cmnt];
  fecd[dv] >> dummy >> avlna[veg.cmnt];
  fecd[dv] >> dummy >> avlnb[veg.cmnt];
  fecd[dv] >> dummy >> stona[veg.cmnt];
  fecd[dv] >> dummy >> stonb[veg.cmnt];

  fecd[dv] >> dummy >> veg.unleaf12[veg.cmnt];
  // veg.prevleafmx changed to veg.initleafmx by DWK on 20000130
  fecd[dv] >> dummy >> veg.initleafmx[veg.cmnt];
  fecd[dv] >> dummy >> veg.cmaxcut[veg.cmnt];
  fecd[dv] >> dummy >> veg.cmax1a[veg.cmnt];
  fecd[dv] >> dummy >> veg.cmax1b[veg.cmnt];
  fecd[dv] >> dummy >> veg.cmax2a[veg.cmnt];
  fecd[dv] >> dummy >> veg.cmax2b[veg.cmnt];
  fecd[dv] >> dummy >> veg.cfall[veg.cmnt];
  fecd[dv] >> dummy >> veg.kra[veg.cmnt];
  fecd[dv] >> dummy >> veg.krb[veg.cmnt];
  fecd[dv] >> dummy >> microbe.kda[veg.cmnt];
  fecd[dv] >> dummy >> microbe.kdb[veg.cmnt];
  fecd[dv] >> dummy >> microbe.lcclnc[veg.cmnt];
  fecd[dv] >> dummy >> microbe.propftos[veg.cmnt];
  fecd[dv] >> dummy >> veg.nmaxcut[veg.cmnt];
  fecd[dv] >> dummy >> veg.nmax1a[veg.cmnt];
  fecd[dv] >> dummy >> veg.nmax1b[veg.cmnt];
  fecd[dv] >> dummy >> veg.nmax2a[veg.cmnt];
  fecd[dv] >> dummy >> veg.nmax2b[veg.cmnt];
  fecd[dv] >> dummy >> veg.nfall[veg.cmnt];
  fecd[dv] >> dummy >> microbe.nupa[veg.cmnt];
  fecd[dv] >> dummy >> microbe.nupb[veg.cmnt];
  fecd[dv] >> dummy >> soil.nloss[veg.cmnt];
  fecd[dv] >> dummy >> microbe.nfixpar[veg.cmnt];
  fecd[dv] >> dummy >> veg.initcneven[veg.cmnt];
  fecd[dv] >> dummy >> veg.cnmin[veg.cmnt];
  fecd[dv] >> dummy >> veg.c2na[veg.cmnt];
  fecd[dv] >> dummy >> veg.c2nb[veg.cmnt];
  fecd[dv] >> dummy >> veg.c2nmin[veg.cmnt];
  fecd[dv] >> dummy >> microbe.cnsoil[veg.cmnt];

  fecd[dv].close();

};

/* *************************************************************
************************************************************** */

void TTEM::initrun(Temstac& temstac)
{
	avlnflag=temstac.avlnflag;
	nfeed=temstac.nfeed;
	initbase=temstac.initbase;
	baseline=temstac.baseline;
	
	moistlim=temstac.moistlim;
	strteq=temstac.strteq;
	maxyears=temstac.maxyears;
	runsize=temstac.runsize;
	maxnrun=temstac.maxnrun;
	rheqflag=temstac.rheqflag;
		
	
	wtol=temstac.wtol;
	ctol=temstac.ctol;
 	ntol=temstac.ntol;
 	startyr=temstac.startyr;
 	endyr=temstac.endyr;
 	diffyr=temstac.diffyr;
    	

	
};

/* **************************************************************
************************************************************** */

void TTEM::initrun(ofstream& rflog1, const int& equil, Temstac& temstac)
{

  avlnflag = nfeed = rheqflag = 0;

/* **************************************************************
		  Run Model with Nitrogen Limitation?
************************************************************** */

  cout << endl << "Do you want to allow available N to fluctuate?" << endl;
  cout << "  Enter 0 for No" << endl;
  cout << "  Enter 1 for Yes: ";
  fpara >> avlnflag;

  rflog1 << endl << "Do you want to allow available N to fluctuate?" << endl;
  rflog1 << "  Enter 0 for No" << endl;
  rflog1 << "  Enter 1 for Yes: " << endl;
  rflog1 << "avlnflag = " << avlnflag << endl << endl;

  cout << endl << "Do you want nitrogen feedback on GPP?" << endl;
  cout << "  Enter 0 for No" << endl;
  cout << "  Enter 1 for Yes: ";
  fpara >> nfeed;

  rflog1 << endl << "Do you want nitrogen feedback on GPP?" << endl;
  rflog1 << "  Enter 0 for No" << endl;
  rflog1 << "  Enter 1 for Yes: " << endl;
  rflog1 << "nfeed = " << nfeed << endl << endl;

  baseline = initbase = 0;
  if (nfeed == 1)
  {
    cout << endl << "Do you want to solve for baseline soil nitrogen?" << endl;
    cout << "  Enter 0 for No" << endl;
    cout << "  Enter 1 for Yes: ";
    fpara >> initbase;
    baseline = initbase;

    rflog1 << endl << "Do you want to solve for baseline soil nitrogen?" << endl;
    rflog1 << "  Enter 0 for No" << endl;
    rflog1 << "  Enter 1 for Yes: " << endl;
    rflog1 << "baseline = " << baseline << endl << endl;
  }

/* **************************************************************
			 Run Model with Moisture Limitation?
************************************************************** */

  moistlim = 0;
  cout << endl << "Do you want to run the model with moisture limitation?" << endl;
  cout << "  Enter 0 for No" << endl;
  cout << "  Enter 1 for Yes: ";
  fpara >> moistlim;

  rflog1 << endl << "Do you want to run the model with moisture limitation?" << endl;
  rflog1 << "  Enter 0 for No" << endl;
  rflog1 << "  Enter 1 for Yes: " << endl;
  rflog1 << "moistlim = " << moistlim << endl << endl;


/* ***************************************************************
	       Details for Steady State Conditions
************************************************************** */


  maxyears = 0;
  maxnrun = 0;

  cout << endl << "How many years do you want to wait before checking equilibrium conditions? ";
  fpara >> strteq;

  rflog1 << endl;
  rflog1 << "How many years do you want to wait before checking equilibrium conditions? ";
  rflog1 << endl;
  rflog1 << "strteq = " << strteq << endl << endl;

  cout << endl << "Enter the maximum number of years for the model to run: ";
  fpara >> maxyears;

  rflog1 << endl << "Enter the maximum number of years for the model to run: ";
  rflog1 << endl;
  rflog1 << "maxyears = " << maxyears << endl << endl;

  runsize = maxyears;

  cout << endl << "Enter the maximum number of attempts to reach a solution: ";
  fpara >> maxnrun;

  rflog1 << endl;
  rflog1 << "Enter the maximum number of attempts to reach a solution: ";
  rflog1 << endl;
  rflog1 << "maxnrun = " << maxnrun << endl << endl;

  if (nfeed == 0)
  {
    cout << endl << "Do you want decomposition to come into equilibrium? ";
    cout << "  Enter 0 for No" << endl;
    cout << "  Enter 1 for Yes: ";
    fpara >> rheqflag;

    rflog1 << endl;
    rflog1 << "Do you want decomposition to come into equilibrium? " << endl;
    rflog1 << "  Enter 0 for No" << endl;
    rflog1 << "  Enter 1 for Yes: " << endl;
    rflog1 << "rheqflag = " << rheqflag << endl << endl;
  }

  wtol = 1000.0;
  cout << endl;
  cout << "What absolute tolerance do you want to use for checking equilibrium";
  cout << endl;
  cout << "of the water cycle? ";
  fpara >> wtol;

  rflog1 << endl;
  rflog1 << "What absolute tolerance do you want to use for checking equilibrium";
  rflog1 << endl;
  rflog1 << "of the water cycle? wtol = " << wtol << endl << endl;

  ctol = 1000.0;
  cout << endl;
  cout << "What absolute tolerance do you want to use for checking equilibrium";
  cout << endl;
  cout << "of the carbon cycle? ";
  fpara >> ctol;

  rflog1 << endl;
  rflog1 << "What absolute tolerance do you want to use for checking equilibrium";
  rflog1 << endl;
  rflog1 << "of the carbon cycle?" << endl;
  rflog1 << "ctol = " << ctol << endl << endl;

  ntol = 1000.0;
  if (nfeed == 1)
  {
    rheqflag = 1;
    cout << endl;
    cout << "What absolute tolerance do you want to use for checking equilibrium";
    cout << endl;
    cout << "of the nitrogen cycle? ";
    fpara >> ntol;

    rflog1 << endl;
    rflog1 << "What absolute tolerance do you want to use for checking equilibrium";
    rflog1 << endl;
    rflog1 << "of the nitrogen cycle?" << endl;
    rflog1 << "ntol = " << ntol << endl << endl;
  }

  if (equil == 0)
  {

    cout << endl << endl;
    cout << "What year do you want to start collecting output data? ";
    fpara >> startyr;

    rflog1 << endl << endl;
    rflog1 << "What year do you want to start collecting output data? ";
    rflog1 << "startyr = " << startyr << endl;

    cout << endl << endl;
    cout << "What year do you want to stop collecting output data? ";
    fpara >> endyr;

    rflog1 << endl << endl;
    rflog1 << "What year do you want to stop collecting output data? ";
    rflog1 << "endyr = " << endyr << endl;

    cout << "How often (x years) should data be collected after the initial year? ";
    fpara >> diffyr;

    rflog1 << "How often (x years) should data be collected after the initial year? ";
    rflog1 << "diffyr = " << diffyr << endl;

  }

	temstac.avlnflag=avlnflag;
	temstac.nfeed=nfeed;
	temstac.initbase=initbase;
	temstac.baseline=baseline;
	
	temstac.moistlim=moistlim;
	temstac.strteq=strteq;
	temstac.maxyears=maxyears;
	temstac.runsize=runsize;
	temstac.maxnrun=maxnrun;
	temstac.rheqflag=rheqflag;
		
	
	temstac.wtol=wtol;
	temstac.ctol=ctol;
 	temstac.ntol=ntol;
 	temstac.startyr=startyr;
 	temstac.endyr=endyr;
 	temstac.diffyr=diffyr;
    	

	


};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************** */

void TTEM::massbal(double y[NUMEQ], double prevy[NUMEQ])
{

  if ((y[I_SNWPCK] - prevy[I_SNWPCK]) != (y[I_SNWFAL] - y[I_SNWINF]))
  {
    y[I_SNWINF] = y[I_SNWFAL] - y[I_SNWPCK] + prevy[I_SNWPCK];
  }

/*  if ((y[I_AVLW] - prevy[I_AVLW]) != (y[I_SNWINF] + y[I_RAIN]
       - y[I_RPERC] - y[I_EET] - y[I_SPERC]))
  {
    y[I_SPERC] = y[I_SNWINF] + y[I_RAIN] - y[I_RPERC] - y[I_EET]
                 - y[I_AVLW] + prevy[I_AVLW];
  }
*/
  if ((y[I_RGRW] - prevy[I_RGRW]) != (y[I_RPERC1] - y[I_RRUN]))
  {
    y[I_RRUN] = y[I_RPERC1] - y[I_RGRW] + prevy[I_RGRW];
  }

  if ((y[I_SGRW] - prevy[I_SGRW]) != (y[I_SPERC1] - y[I_SRUN]))
  {
    y[I_SRUN] = y[I_SPERC1] - y[I_SGRW] + prevy[I_SGRW];
  }

  if (y[I_WYLD] != y[I_RRUN] + y[I_SRUN])
  {
    y[I_WYLD] = y[I_RRUN] + y[I_SRUN];
  }
/************************* Carbon Cycle Balances **************************/

};


/* *************************************************************
************************************************************** */

void TTEM::resetODEflux(double y[])
{
  int i;

  for (i = MAXSTATE; i < NUMEQ; i++) { y[i] = 0.0; }

};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************** */

void TTEM::resetYrFlux(void)
{

  int dm;
  int m, days;

  // Annual water storage
//  soil.yravlh2o = 0.0;
  soil.yrrgrndh2o = 0.0;
  soil.yrsnowpack = 0.0;
  soil.yrsgrndh2o = 0.0;
 // soil.yrsmoist = 0.0;
 // soil.yrpctp = 0.0;
 // soil.yrvsm = 0.0;

 // added for 3-box hydm

  soil.yravlh2o1 = 0.0;
  soil.yravlh2o2 = 0.0;
  soil.yravlh2o3 = 0.0;

  soil.yrsmoist1 = 0.0;
  soil.yrsmoist2 = 0.0;
  soil.yrsmoist3 = 0.0;

  soil.yrpctp1 = 0.0;
  soil.yrpctp2 = 0.0;
  soil.yrpctp3 = 0.0;

  soil.yrvsm1 = 0.0;
  soil.yrvsm2 = 0.0;
  soil.yrvsm3 = 0.0;

  // Annual carbon fluxes
  // Annual water fluxes

  atms.yrrain = 0.0;
//  soil.yrrperc = 0.0;
  soil.yrrrun = 0.0;
  atms.yrsnowfall = 0.0;
  soil.yrsnowinf = 0.0;
//  soil.yrsperc = 0.0;
  soil.yrsrun = 0.0;
//  atms.yrpet = 0.0;
//  atms.yreet = 0.0;
  soil.yrh2oyld = 0.0;

  atms.yrpet3 = 0.0;
  atms.yreet3 = 0.0;

   // added for hydrology model

  hyd.yrhevap = 0.0;
  hyd.yrhtrans = 0.0;
  hyd.yrsevap = 0.0;
  hyd.yrsnowsub = 0.0;
  hyd.yrsubcan = 0.0;

     // for soil temperature
  atms.yrfrontd =0.0;
  atms.yrthawbegin =0.0;
  atms.yrthawend =0.0;
  atms.yrtsoil = 0.0;
  atms.yrdst5 = 0.0;
  atms.yrdst10 = 0.0;
  atms.yrdst20 = 0.0;
  atms.yrdst50 = 0.0;
  atms.yrdst100 = 0.0;
  atms.yrdst200 = 0.0;

};


/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************** */

void TTEM::setELMNTflux(void)
{

  // Initialize carbon, nitrogen and water fluxes including
  // ODE state variables (i.e., y[])
  int dm;
  int m, days;

  int year = 1992;

  for (dm = 0; dm < CYCLE; dm++)
  {
    // Initialize carbon fluxes in natural ecosystems to zero
        days = daysnumber(dm, year);
      for (m=0; m< days; m++)
    {
    y[I_RAIN] = 0.0;

    y[I_RRUN] = soil.rrun[dm][m] = 0.0;
    y[I_SNWFAL] = 0.0;
    y[I_SNWINF] = soil.snowinf[dm][m] = 0.0;

    y[I_SRUN] = soil.srun[dm][m] = 0.0;

    y[I_WYLD] = soil.h2oyld[dm][m] = 0.0;

    // added for 3-box hydrology
    y[I_PET3] = 0.0;
    y[I_EET3] = atms.eet3[dm][m] = 0.0;

//    y[I_LYPERC] = hydm.lyperc[dm][m] = 0.0;
//    y[I_LYPERC1] = hydm.lyperc1[dm][m] = 0.0;
//    y[I_LYPERC2] = hydm.lyperc2[dm][m] = 0.0;

//    y[I_RPERC1] = soil.rperc1[dm][m] = 0.0;
//    y[I_RPERC2] = soil.rperc2[dm][m] = 0.0;
//    y[I_RPERC3] = soil.rperc3[dm][m] = 0.0;

//    y[I_SPERC1] = soil.sperc1[dm][m] = 0.0;
//    y[I_SPERC2] = soil.sperc2[dm][m] = 0.0;
//    y[I_SPERC3] = soil.sperc3[dm][m] = 0.0;

    y[I_TRANS] = hyd.htrans[dm][m] = 0.0;
    y[I_SEVAP] = hyd.soil_evap[dm][m] = 0.0;
    y[I_SNOWSUB] = hyd.snowsub[dm][m] = 0.0;
    y[I_SUBCAN] = hyd.sub_from_canopy[dm][m] = 0.0;

    y[I_WT] = hydm.watertable[dm][m] = 0.0;


// for soil temperature
    y[I_TSOIL] = atms.tsoil[dm][m]=0.0;
    y[I_DST5] = atms.dst5[dm][m]=0.0;
    y[I_DST10] = atms.dst10[dm][m]=0.0;
    y[I_DST20] = atms.dst20[dm][m]=0.0;
    y[I_DST50] = atms.dst50[dm][m]=0.0;
    y[I_DST100] = atms.dst100[dm][m]=0.0;
    y[I_DST200] = atms.dst200[dm][m]=0.0;
    y[I_FRONTD] = atms.frontd[dm][m]=0.0;
    y[I_THAWBE] = atms.thawbe[dm][m]=0.0;
    y[I_THAWEND] = atms.thawend[dm][m]=0.0;

    // in case  for isotoe youmi oh
    //y[I_D13INIT] = ch4dmdif.d13init[dm][m]=0.0;
    //y[I_D13PROD] = ch4dmdif.d13prod[dm][m]=0.0;
    //y[I_D13OXID] = ch4dmdif.d13oxid[dm][m]=0.0;
    //y[I_D13FINAL] = ch4dmdif.d13final[dm][m]=0.0;
    //y[I_MOMPFRAC] = ch4dmdif.mompfrac[dm][m]=0.0;
    //y[I_TPFRAC] = ch4dmdif.tpfrac[dm][m]=0.0;
    //y[I_TEFRAC] = ch4dmdif.tefrac[dm][m]=0.0;
    //y[I_TDFRAC] = ch4dmdif.tdfrac[dm][m]=0.0;
   }
  }  // end of days
};

/* *************************************************************
************************************************************** */


/* *************************************************************
************************************************************* */

void TTEM::setMonth(int& dm, double y[], int& m)
{

  // Water pools
/*
  soil.avlh2o[dm][m] = y[I_AVLW];
  soil.rgrndh2o[dm][m] = y[I_RGRW];
  soil.snowpack[dm][m] = y[I_SNWPCK];
  soil.sgrndh2o[dm][m] = y[I_SGRW];

 // New  Hydrological Model
  soil.avlh2o1[dm][m] = y[I_AVLW1];
  soil.avlh2o2[dm][m] = y[I_AVLW2];
  soil.avlh2o3[dm][m] = y[I_AVLW3];

  soil.moist1[dm][m] = y[I_MOIST1];
  soil.moist2[dm][m] = y[I_MOIST2];
  soil.moist3[dm][m] = y[I_MOIST3];

  soil.pctp1[dm][m] = y[I_PCTP1];
  soil.pctp2[dm][m] = y[I_PCTP2];
  soil.pctp3[dm][m] = y[I_PCTP3];

  soil.vsm1[dm][m] = y[I_VSM1];
  soil.vsm2[dm][m] = y[I_VSM2];
  soil.vsm3[dm][m] = y[I_VSM3];
 */
 // sign values for each day

  soil.vsm1[dm][m] = hydm.h2osoi[0];
  soil.vsm2[dm][m] = hydm.h2osoi[1];
  soil.vsm3[dm][m] = hydm.h2osoi[2];
  soil.vsm4[dm][m] = hydm.h2osoi[3];
  soil.vsm5[dm][m] = hydm.h2osoi[4];
  soil.vsm6[dm][m] = hydm.h2osoi[5];

  // The following is set up for methane production, pctp will be between 0 - 1
  soil.pctp1[dm][m] =  soil.vsm1[dm][m] / (soil.totpor1 / 100.0);
  soil.pctp2[dm][m] =  soil.vsm2[dm][m] / (soil.totpor2 / 100.0);
  soil.pctp3[dm][m] =  soil.vsm3[dm][m] / (soil.totpor3 / 100.0);


  atms.rain[dm][m] = y[I_RAIN];
  atms.snowfall[dm][m] = y[I_SNWFAL];
  soil.snowinf[dm][m] = y[I_SNWINF];
  soil.h2oyld[dm][m] = y[I_WYLD];

  atms.pet3[dm][m] = y[I_PET3];
  atms.eet3[dm][m] = y[I_EET3];

  hyd.htrans[dm][m] = y[I_TRANS];
  hyd.soil_evap[dm][m] = y[I_SEVAP];
  hyd.snowsub[dm][m] = y[I_SNOWSUB];
  hyd.sub_from_canopy[dm][m] = y[I_SUBCAN];

  hydm.surinfl[dm][m] = y[I_INFIL];
  hydm.surrunoff[dm][m] = y[I_SRUNOFF];
  hydm.bdrai[dm][m] = y[I_DRAIN];

  hydm.watertable[dm][m] = y[I_WT];
//  ch4dmdif.totalflx[dm][m] = y[I_TFLX];
  ch4dmdif.ch4cons[dm][m] = y[I_CH4CON];
  ch4dmdif.ch4sc[dm][m] = y[I_CH4SC];//llc porewater
  ch4dmdif.ch4emis[dm][m] = y[I_CH4EMI];
  ch4dmdif.ch4tot[dm][m] = y[I_TOTFLX];


  // added for soil thermal model
  atms.tsoil[dm][m]=  y[I_TSOIL];
  atms.dst5[dm][m]=   y[I_DST5];
  atms.dst10[dm][m]=  y[I_DST10];
  atms.dst20[dm][m]=  y[I_DST20];
  atms.dst50[dm][m]=  y[I_DST50];
  atms.dst100[dm][m]= y[I_DST100];
  atms.dst200[dm][m]= y[I_DST200];
  atms.frontd[dm][m]= y[I_FRONTD];
  atms.thawbe[dm][m]= y[I_THAWBE];
  atms.thawend[dm][m]= y[I_THAWEND];

  //added for isotope
  ch4dmdif.d13init[dm][m] = y[I_D13INIT];
  ch4dmdif.d13prod[dm][m] = y[I_D13PROD];
  ch4dmdif.d13oxid[dm][m] = y[I_D13OXID];
  ch4dmdif.d13final[dm][m] = y[I_D13FINAL];
  ch4dmdif.mompfrac[dm][m] = y[I_MOMPFRAC];
  ch4dmdif.tpfrac[dm][m] = y[I_TPFRAC];
  ch4dmdif.tefrac[dm][m] = y[I_TEFRAC];
  ch4dmdif.tdfrac[dm][m] = y[I_TDFRAC];

  //added for plant oxidation
  //ch4dmdif.mompfracplt[dm][m] = y[I_MOMPFRACPLT];
  //ch4dmdif.d13oxidplt[dm][m] = y[I_D13OXIDPLT];

  soil.yrpctp1 += y[I_PCTP1];
  soil.yrpctp2 += y[I_PCTP2];
  soil.yrpctp3 += y[I_PCTP3];

  soil.yrvsm1 += y[I_VSM1];
  soil.yrvsm2 += y[I_VSM2];
  soil.yrvsm3 += y[I_VSM3];

   // Update sum of annual water fluxes
  atms.yrrain += y[I_RAIN];
//  soil.yrrperc += y[I_RPERC];
  soil.yrrrun += y[I_RRUN];
  atms.yrsnowfall += y[I_SNWFAL];
  soil.yrsnowinf += y[I_SNWINF];
//  soil.yrsperc += y[I_SPERC];
  soil.yrsrun += y[I_SRUN];
//  atms.yrpet += y[I_PET];
//  atms.yreet += y[I_EET];
  soil.yrh2oyld += y[I_WYLD];

//  soil.yrrperc1 += y[I_RPERC1];
//  soil.yrrperc2 += y[I_RPERC2];
//  soil.yrrperc3 += y[I_RPERC3];
//  soil.yrsperc1 += y[I_SPERC1];
//  soil.yrsperc2 += y[I_SPERC2];
//  soil.yrsperc3 += y[I_SPERC3];

  atms.yrpet3 += y[I_PET3];
  atms.yreet3 += y[I_EET3];

//  hydm.yrlyperc += y[I_LYPERC];
//  hydm.yrlyperc1 += y[I_LYPERC1];
//  hydm.yrlyperc2 += y[I_LYPERC2];


};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

void TTEM::setPrevState(double prevState[],double currentState[])
{
  for (int i = 0; i < NUMEQ; i++) { prevState[i] = currentState[i]; }

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************** */

int TTEM::stepyr(const int& dyr, const int& itype, int& intflag, double& tol)
{

  int dm;
  int mintflag;
  int m, days;

  int year = atms.tairyear[dyr];

  // Reset annual fluxes to zero

  resetYrFlux();

  for (dm = 0; dm < CYCLE; dm++)
  {
    days = daysnumber(dm, year);
    for (m=0; m< days; m++)
    {
       if (initFlag == 1)
    {
      if (atms.tco2flag != 0) { atms.co2[dm][m] = atms.tco2[dyr][dm][m]; }
	  if (atms.tch4flag != 0) { atms.ch4[dm][m] = atms.tch4[dyr][dm][m]; }
      if (atms.ttairflag != 0) { atms.tair[dm][m] = atms.ttair[dyr][dm][m]; }
      if (atms.tprecflag != 0) { atms.prec[dm][m] = atms.tprec[dyr][dm][m]; }
      if (atms.tlaiflag  != 0) {atms.GISlai[dm][m] = atms.tGISlai[dyr][dm][m];}  // for reading in GIS lai

        //added for hydrology model by QZ
       if (hyd.vapflag != 0) { hyd.vap[dm][m] = hyd.tvap[dyr][dm][m]; }
   /*
      if (ag.tlulcflag != 0)
      {
        if (ag.RAP0flag == 0)
        {
	  ag.potnpp[dm][m] = ag.tpotnpp[itype][dyr][dm][m];
        }
        else { ag.potnpp[dm][m] = 0.0; }
      }
      */
    }

    // Get environmental conditions for month "dm"

   // calculate snowpack for the specific year

	 atms.precsplt(atms.prec[dm][m], atms.tair[dm][m], hyd.rainthrough[dm][m], soil.snowthrough[dm][m]);

     switch (dm)
     {
     case 0:  if (m==0)
              {
               atms.prevtair = atms.tair[1][0];
               atms.prev2tair = atms.tair[1][1];
              }
              else
               {
                if (m ==1){
               atms.prevtair = atms.tair[0][29];
               atms.prev2tair = atms.tair[0][30];
                 }
               else
                {
               atms.prevtair = atms.tair[0][m-1];
               atms.prev2tair = atms.tair[0][m-2];
                }
               }
             break;

    default:
             if (m==0)
              {
               atms.prevtair = atms.tair[dm][0];
               atms.prev2tair = atms.tair[dm][1];
              }
              else
               {
                if (m ==1){
               atms.prevtair = atms.tair[dm][29];
               atms.prev2tair = atms.tair[dm][30];
                 }
               else
                {
               atms.prevtair = atms.tair[dm][m-1];
               atms.prev2tair = atms.tair[dm][m-2];
                }
               }
             break;
       }

    soil.snowinf[dm][m] = soil.snowmelt(elev, atms.tair[dm][m], atms.prevtair, y[I_SNWPCK]);
//    soil.snowpack[dm][m]= atms.snowfall[dm][m] - soil.snowinf[dm][m];
    soil.snowpack[dm][m]= soil.snowthrough[dm][m] - soil.snowinf[dm][m];

    if (soil.snowpack[dm][m] < 0.0) { soil.snowpack[dm][m] = 0.0; }

   if (stmflg == 1) {

     switch (dm) {

      case 0: sthermal.airt19= (atms.tair[0][m]+atms.tair[0][m+1])/2.0; // satisfy soil thermal model
              sthermal.airt29= atms.tair[0][m];
              sthermal.airt39= (atms.tair[0][m]+atms.tair[0][m+2])/2.0;
              break;
      case 11: if (!(m == 30))
              {
              sthermal.airt19= (atms.tair[11][m]+atms.tair[11][m+1])/2.0; // satisfy soil thermal model
              sthermal.airt29= atms.tair[11][m];
              sthermal.airt39= (atms.tair[11][m]+atms.tair[11][m+2])/2.0;
              }
              else
              {
              sthermal.airt19= (atms.tair[11][m]+atms.tair[10][29])/2.0; // satisfy soil thermal model
              sthermal.airt29= atms.tair[11][m];
              sthermal.airt39= (atms.tair[11][m]+atms.tair[10][28])/2.0;
              }
             break;
      default:sthermal.airt19= (atms.tair[dm][m]+atms.tair[dm][m+1])/2.0; // satisfy soil thermal model
             sthermal.airt29= atms.tair[dm][m];
             sthermal.airt39= (atms.tair[dm][m]+atms.tair[dm+1][m+2])/2.0;
            break;
         }

    switch (dm) {
     case 0: sthermal.hsnow19=(soil.snowpack[0][m]+soil.snowpack[0][m+1])/2.0/1000.0; // satisfy soil thermal model
             sthermal.hsnow29= soil.snowpack[0][m]/1000.0;
             sthermal.hsnow39= (soil.snowpack[0][m]+soil.snowpack[0][m+2])/2.0/1000.0;
             break;

     case 11: if (!(m == 30))
              {
              sthermal.hsnow19=(soil.snowpack[11][m]+soil.snowpack[11][m+1])/2.0/1000.0; // satisfy soil thermal model
              sthermal.hsnow29= soil.snowpack[11][m]/1000.0;
              sthermal.hsnow39= (soil.snowpack[11][m]+soil.snowpack[11][m+2])/2.0/1000.0;
              }
             else
               {
              sthermal.hsnow19=(soil.snowpack[11][m]+soil.snowpack[10][29])/2.0/1000.0; // satisfy soil thermal model
              sthermal.hsnow29= soil.snowpack[11][m]/1000.0;
              sthermal.hsnow39= (soil.snowpack[11][m]+soil.snowpack[10][28])/2.0/1000.0;
               }
              break;

     default: sthermal.hsnow19=(soil.snowpack[dm][m]+soil.snowpack[dm][m+1])/2.0/1000.0; // satisfy soil thermal model
              sthermal.hsnow29= soil.snowpack[dm][m]/1000.0;
              sthermal.hsnow39= (soil.snowpack[dm][m]+soil.snowpack[dm][m+2])/2.0/1000.0;
            break;
         }


    sthermal.is9 = 10;
    sthermal.ism19 = 9;
    sthermal.smass9 = 0.f;

   int i;

	for (i=1;i <=210; i++) {
    sthermal.t9[i] = 0;
  	sthermal.xfa9[i] = -1e10f;
	sthermal.xfb9[i] = 0.f;
	sthermal.water9[i] = 1.f;
	sthermal.dx9[i] = 0.f;
	sthermal.weight9[i] = 0.f; }


   sthermal.calcu_cdsnow = 0.2; // constant for equilibrium run --- an assumpition
   sthermal.water2 = soil.pctp2[dm][m]/100.0; // assume moss and organic have the same water content, 29/march/2001

  if (sthermal.soiltemp_(&sthermal.water2, &sthermal.calcu_cdsnow, &sthermal.airt19, &sthermal.airt29, &sthermal.airt39, &sthermal.hsnow19, &sthermal.hsnow29,
    &sthermal.hsnow39,sthermal.weight9, &sthermal.smass9, &sthermal.is9, &sthermal.ism19, sthermal.x9, sthermal.dx9,
     sthermal.xfb9, sthermal.xfa9,	sthermal.water9, sthermal.t9, &sthermal.tsoil,&sthermal.frontd,&sthermal.thawbegin,
    &sthermal.thawend,sthermal.diffsoilt, veg.cmnt) !=0)
    {
    printf("bad tem"); // getch();
    };



   //      ++kswitch;

      atms.frontd[dm][m]=sthermal.frontd;
      atms.thawbe[dm][m]=sthermal.thawbegin;
      atms.thawend[dm][m]=sthermal.thawend;

      atms.tsoil[dm][m]=sthermal.tsoil;
      atms.dst5[dm][m]=sthermal.diffsoilt[0];
      atms.dst10[dm][m]=sthermal.diffsoilt[1];
      atms.dst20[dm][m]=sthermal.diffsoilt[2];
      atms.dst50[dm][m]=sthermal.diffsoilt[3];
      atms.dst100[dm][m]=sthermal.diffsoilt[4];
      atms.dst200[dm][m]=sthermal.diffsoilt[5];

  /*** end of calling soil thermal model ***/
  } // stmflg ===1

//   getenviron(dm,m);

   mintflag = adapt(NUMEQ,y,tol,dm,m);

    if (mintflag == 1) { intflag = 1; }

    if (blackhol != 0) { qualcon[dyr][itype] = 10; }

  //  massbal(y,prevy);

    setPrevState(prevy,y);

    // Update carbon, nitrogen and water pools and fluxes from
    //  integrator results
    setMonth(dm, y,m);

    resetODEflux(y);
  }  // end of days
 }

  soil.yravlh2o /= 12.0;
  soil.yrrgrndh2o /= 12.0;
  soil.yrsnowpack /= 12.0;
  soil.yrsgrndh2o /= 12.0;
//  soil.yrsmoist /= 12.0;
//  soil.yrpctp /= 12.0;
//  soil.yrvsm /= 12.0;


  // added for 3-box hydrology

  soil.yravlh2o1 /= 12.0;
  soil.yravlh2o2 /= 12.0;
  soil.yravlh2o3 /= 12.0;

  soil.yrsmoist1 /= 12.0;
  soil.yrsmoist2 /= 12.0;
  soil.yrsmoist3 /= 12.0;

  soil.yrpctp1 /= 12.0;
  soil.yrpctp2 /= 12.0;
  soil.yrpctp3 /= 12.0;

  soil.yrvsm1 /= 12.0;
  soil.yrvsm2 /= 12.0;
  soil.yrvsm3 /= 12.0;

  atms.yrtsoil /= 12.0; // for soil temperature
  atms.yrfrontd /= 12.0; // for soil temperature
  atms.yrthawbegin /= 12.0; // for soil temperature
  atms.yrthawend /= 12.0; // for soil temperature

  if (endeq > 0) { ++endeq; }


  return endeq;

};


/* *************************************************************
************************************************************* */
// modified for Soil Thermal model

//int TTEM::transient(const int& dyr, const int& itype, double& tol)
int TTEM::transient(const int& dyr, const int& itype, double& tol, const int& RTIME)
{
  endeq = 0;

  if (atms.tco2flag == 1) { totyr = atms.co2year[dyr]; }
  else if (atms.ttairflag == 1) { totyr = atms.tairyear[dyr]; }
  else if (atms.tstwflag == 1) { totyr = atms.stwyear[dyr]; } //llc for wetland
  else if (atms.tsg_frinflag == 1) { totyr = atms.sg_frinyear[dyr]; } //llc for wetland
  else if (atms.tprecflag == 1) { totyr = atms.precyear[dyr]; }
  else if(atms.tch4flag == 1) { totyr = atms.ch4year[dyr]; }
//added for hydrology model by QZ
  else if (hyd.vapflag == 1) { totyr = hyd.vapyear[dyr]; }

  if (atms.ttairflag != 0) { atms.mxtair = atms.mxttair[dyr]; }
  if (atms.tprecflag != 0) { atms.yrprec = atms.yrtprec[dyr]; }
  // added for hydrology model by QZ
  if (hyd.vapflag != 0) { hyd.yrvap = hyd.yrtvap[dyr]; }

  if (ag.tlulcflag == 1)
  {
    ag.state = ag.tstate[dyr];
    ag.RAP = ag.tRAP[dyr];
  }

 // stepyr(dyr,itype, intflag, tol);
   transtepyr(dyr,itype, intflag, tol, RTIME);


  // Update annual agricultural product pools and fluxes

  ag.updateyr(dyr);

  if (totyr == startyr) { wrtyr = 0;}
  if (totyr > startyr) {++wrtyr; }

  return wrtyr;

};

// addition in order to
  int dm;
  int mintflag; //use RTIME for soil thermal model
int TTEM::transtepyr(const int& dyr, const int& itype, int& intflag, double& tol, const int& RTIME)
{

  int m, days;

  int year = atms.tairyear[dyr];

  initFlag = 1;  // always assume it is 1, 19 Oct 2003

  // Reset annual fluxes to zero

  resetYrFlux();

  // Convert natural vegetation to agriculture
  //calculate CDM
  // To correctly calculate CDM at monthly basis, need to integrate monthly tempeature from daily first- need to implemnt this, 6/March/2003


   double CDM;
   CDM = 0.0;
   for (dm = 0; dm < CYCLE; dm++)
    {
     days = daysnumber(dm, year);
     for (m=0; m< days; m++)
     CDM = CDM + (10.0 - atms.ttair[dyr][dm][m]);   // this should be changed if using CMD, to daily solution
    }

    for (dm = 0; dm < CYCLE; dm++)
    {

     days = daysnumber(dm, year);

     for (m=0; m< days; m++)   //llc daily
//     for (m=0; m< 1; m++)

       {
       if (initFlag == 1)
      {
       if (atms.tco2flag != 0) { atms.co2[dm][m] = atms.tco2[dyr][dm][m]; }
	   if (atms.tch4flag != 0) { atms.ch4[dm][m] = atms.tch4[dyr][dm][m]; }
       if (atms.ttairflag != 0) {atms.tair[dm][m] = atms.ttair[dyr][dm][m]; }
       if (atms.tstwflag != 0) {atms.stw[dm][m] = atms.tstw[dyr][dm][m]; } //llc for wetland
       if (atms.tsg_frinflag != 0) {atms.sg_frin[dm][m] = atms.tsg_frin[dyr][dm][m]; } //llc for wetland
       if (atms.tprecflag != 0) { atms.prec[dm][m] = atms.tprec[dyr][dm][m]; }
       if (atms.tlaiflag  != 0) {atms.GISlai[dm][m] = atms.tGISlai[dyr][dm][m];}  // for reading in GIS lai
	   ch4dmdif.aoch4 = atms.ch4[dm][m] * 0.001;		// atmospheric ch4 concentration (u mol cm-3)
        ch4dmpro.suborg[dm][m] = ch4dmpro.tsuborg[itype][dyr][dm][m]; // for NPP data

      //added for hydrology model by QZ
      if (hyd.vapflag != 0) { hyd.vap[dm][m] = hyd.tvap[dyr][dm][m]; }

     }

       
      
  //llc for wetland parameter updated!!**********************************************
  int paran_wet=0;
  
  if((atms.tsg_frinflag != 0)) {frin = atms.sg_frin[dm][m];}
  //boreal
  if(veg.cmnt < 5 && (frin > 0 && frin <= 10000)){
    if(wet >=1 && wet <=5){
      paran_wet=int(wet);}
    else{     
      if(veg.cmnt == 1){paran_wet=2;}
      if(veg.cmnt == 2){paran_wet=2;}
      if(veg.cmnt == 3){paran_wet=2;}
      if(veg.cmnt == 4){paran_wet=1;}
    }
    //pro para
    ch4dmpro.mgo[veg.cmnt]=ch4dmpro.pro_para[paran_wet][1];
    ch4dmpro.kc[veg.cmnt]=ch4dmpro.pro_para[paran_wet][2];
    ch4dmpro.pmethaneq[veg.cmnt]=ch4dmpro.pro_para[paran_wet][3];
    ch4dmpro.oxi_c[veg.cmnt]=ch4dmpro.pro_para[paran_wet][4];
    ch4dmpro.maxfresh[veg.cmnt]=ch4dmpro.pro_para[paran_wet][5];
    ch4dmpro.lowb[veg.cmnt]=ch4dmpro.pro_para[paran_wet][6];
    ch4dmpro.proref[veg.cmnt]=ch4dmpro.pro_para[paran_wet][7];
    //poxi para
    pch4dmoxi.omax[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][1];
    pch4dmoxi.kc[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][2];
    pch4dmoxi.och4q10[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][3];
    pch4dmoxi.ko[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][4];
    pch4dmoxi.afp[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][5];
    pch4dmoxi.mvmax[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][6];
    pch4dmoxi.mvmin[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][7];
    pch4dmoxi.mvopt[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][8];
    pch4dmoxi.oxiref[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][9];
    // add for isotopes youmi
    // modified jun 14 2019 Youmi Oh
    //if (veg.cmnt == 4 && fabs(lat) < 70) paran_wet = 6.; //temperate boreal: 6
    ch4dmpro.alpha_am[veg.cmnt]=ch4dmpro.iso_para[paran_wet][1];
    ch4dmpro.alpha_hm[veg.cmnt]=ch4dmpro.iso_para[paran_wet][2];
    ch4dmpro.alpha_mo[veg.cmnt]=ch4dmpro.iso_para[paran_wet][3];
    ch4dmpro.alpha_tp[veg.cmnt]=ch4dmpro.iso_para[paran_wet][4];
    ch4dmpro.alpha_te[veg.cmnt]=ch4dmpro.iso_para[paran_wet][5];
    ch4dmpro.alpha_td[veg.cmnt]=ch4dmpro.iso_para[paran_wet][6];
  }

  //temperate
    if( (veg.cmnt == 5 || veg.cmnt == 6 ||  veg.cmnt == 11) && (frin > 0 && frin <= 10000)) {
       if(wet >=1 && wet <=5){
	 paran_wet=int(wet)+5;}
       else{
	 if(veg.cmnt == 5){paran_wet=6;}
	 if(veg.cmnt == 6){paran_wet=6;}
	 if(veg.cmnt == 11){paran_wet=8;}
       }
    //pro para
    ch4dmpro.mgo[veg.cmnt]=ch4dmpro.pro_para[paran_wet][1];
    ch4dmpro.kc[veg.cmnt]=ch4dmpro.pro_para[paran_wet][2];
    ch4dmpro.pmethaneq[veg.cmnt]=ch4dmpro.pro_para[paran_wet][3];
    ch4dmpro.oxi_c[veg.cmnt]=ch4dmpro.pro_para[paran_wet][4];
    ch4dmpro.maxfresh[veg.cmnt]=ch4dmpro.pro_para[paran_wet][5];
    ch4dmpro.lowb[veg.cmnt]=ch4dmpro.pro_para[paran_wet][6];
    ch4dmpro.proref[veg.cmnt]=ch4dmpro.pro_para[paran_wet][7];
    //poxi para
    pch4dmoxi.omax[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][1];
    pch4dmoxi.kc[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][2];
    pch4dmoxi.och4q10[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][3];
    pch4dmoxi.ko[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][4];
    pch4dmoxi.afp[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][5];
    pch4dmoxi.mvmax[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][6];
    pch4dmoxi.mvmin[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][7];
    pch4dmoxi.mvopt[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][8];
    pch4dmoxi.oxiref[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][9];   
    // add for isotopes youmi
    //paran_wet = 8.; // modified june 14 2019 Youmi Oh //temperate use 8
    // ???? feb 2020 
    ch4dmpro.alpha_am[veg.cmnt]=ch4dmpro.iso_para[paran_wet][1];
    ch4dmpro.alpha_hm[veg.cmnt]=ch4dmpro.iso_para[paran_wet][2];
    ch4dmpro.alpha_mo[veg.cmnt]=ch4dmpro.iso_para[paran_wet][3];
    ch4dmpro.alpha_tp[veg.cmnt]=ch4dmpro.iso_para[paran_wet][4];
    ch4dmpro.alpha_te[veg.cmnt]=ch4dmpro.iso_para[paran_wet][5];
    ch4dmpro.alpha_td[veg.cmnt]=ch4dmpro.iso_para[paran_wet][6];
  }
  
  //tropical
    if((veg.cmnt == 8 || veg.cmnt == 9 || veg.cmnt == 10|| veg.cmnt == 12) && (frin > 0 && frin <= 10000)) {
      if(wet >=1 && wet <=5){
	 paran_wet=int(wet)+10;}
       else{
	 if(veg.cmnt == 8){paran_wet=12;}
	 if(veg.cmnt == 9){paran_wet=13;}
	 if(veg.cmnt == 10){paran_wet=13;}
	 if(veg.cmnt == 12){paran_wet=13;}
       } 
    //pro para
    ch4dmpro.mgo[veg.cmnt]=ch4dmpro.pro_para[paran_wet][1];
    ch4dmpro.kc[veg.cmnt]=ch4dmpro.pro_para[paran_wet][2];
    ch4dmpro.pmethaneq[veg.cmnt]=ch4dmpro.pro_para[paran_wet][3];
    ch4dmpro.oxi_c[veg.cmnt]=ch4dmpro.pro_para[paran_wet][4];
    ch4dmpro.maxfresh[veg.cmnt]=ch4dmpro.pro_para[paran_wet][5];
    ch4dmpro.lowb[veg.cmnt]=ch4dmpro.pro_para[paran_wet][6];
    ch4dmpro.proref[veg.cmnt]=ch4dmpro.pro_para[paran_wet][7];   
    //poxi para
    pch4dmoxi.omax[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][1];
    pch4dmoxi.kc[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][2];
    pch4dmoxi.och4q10[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][3];
    pch4dmoxi.ko[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][4];
    pch4dmoxi.afp[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][5];
    pch4dmoxi.mvmax[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][6];
    pch4dmoxi.mvmin[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][7];
    pch4dmoxi.mvopt[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][8];
    pch4dmoxi.oxiref[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][9];
    // add for isotopes youmi
    ch4dmpro.alpha_am[veg.cmnt]=ch4dmpro.iso_para[paran_wet][1];
    ch4dmpro.alpha_hm[veg.cmnt]=ch4dmpro.iso_para[paran_wet][2];
    ch4dmpro.alpha_mo[veg.cmnt]=ch4dmpro.iso_para[paran_wet][3];
    ch4dmpro.alpha_tp[veg.cmnt]=ch4dmpro.iso_para[paran_wet][4];
    ch4dmpro.alpha_te[veg.cmnt]=ch4dmpro.iso_para[paran_wet][5];
    ch4dmpro.alpha_td[veg.cmnt]=ch4dmpro.iso_para[paran_wet][6];
    }    

    //grassland

    if((veg.cmnt == 7) && (frin > 0 && frin <= 10000)) {
      if(wet >=1 && wet <=5){
	if(fabs(lat) > 60.0) {paran_wet=int(wet);}
	if(fabs(lat) > 30.0 && fabs(lat) <= 60.0) {paran_wet=int(wet)+5;}
	if(fabs(lat) <= 30.0) {paran_wet=int(wet)+10;}
      }
      else{
	if(fabs(lat) > 60.0) {paran_wet=2;}
	if(fabs(lat) > 30.0 && fabs(lat) <= 60.0) {paran_wet=7;}
	if(fabs(lat) <= 30.0) {paran_wet=14;}
      } 
    //pro para
    ch4dmpro.mgo[veg.cmnt]=ch4dmpro.pro_para[paran_wet][1];
    ch4dmpro.kc[veg.cmnt]=ch4dmpro.pro_para[paran_wet][2];
    ch4dmpro.pmethaneq[veg.cmnt]=ch4dmpro.pro_para[paran_wet][3];
    ch4dmpro.oxi_c[veg.cmnt]=ch4dmpro.pro_para[paran_wet][4];
    ch4dmpro.maxfresh[veg.cmnt]=ch4dmpro.pro_para[paran_wet][5];
    ch4dmpro.lowb[veg.cmnt]=ch4dmpro.pro_para[paran_wet][6];
    ch4dmpro.proref[veg.cmnt]=ch4dmpro.pro_para[paran_wet][7];   
    //poxi para
    pch4dmoxi.omax[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][1];
    pch4dmoxi.kc[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][2];
    pch4dmoxi.och4q10[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][3];
    pch4dmoxi.ko[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][4];
    pch4dmoxi.afp[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][5];
    pch4dmoxi.mvmax[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][6];
    pch4dmoxi.mvmin[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][7];
    pch4dmoxi.mvopt[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][8];
    pch4dmoxi.oxiref[veg.cmnt]=pch4dmoxi.poxi_para[paran_wet][9];
    // add for isotopes youmi
    ch4dmpro.alpha_am[veg.cmnt]=ch4dmpro.iso_para[paran_wet][1];
    ch4dmpro.alpha_hm[veg.cmnt]=ch4dmpro.iso_para[paran_wet][2];
    ch4dmpro.alpha_mo[veg.cmnt]=ch4dmpro.iso_para[paran_wet][3];
    ch4dmpro.alpha_tp[veg.cmnt]=ch4dmpro.iso_para[paran_wet][4];
    ch4dmpro.alpha_te[veg.cmnt]=ch4dmpro.iso_para[paran_wet][5];
    ch4dmpro.alpha_td[veg.cmnt]=ch4dmpro.iso_para[paran_wet][6];
    }   


//printf("vege %i %f %f %f\n",veg.cmnt,ch4dmpro.alpha_am[veg.cmnt],ch4dmpro.alpha_hm[veg.cmnt],ch4dmpro.alpha_mo[veg.cmnt]);
//printf("llc test!!!!!!,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f\n",lat,frin,ch4dmpro.mgo[veg.cmnt],ch4dmpro.kc[veg.cmnt],ch4dmpro.pmethaneq[veg.cmnt],ch4dmpro.oxi_c[veg.cmnt],ch4dmpro.maxfresh[veg.cmnt],ch4dmpro.lowb[veg.cmnt],ch4dmpro.proref[veg.cmnt], pch4dmoxi.omax[veg.cmnt], pch4dmoxi.kc[veg.cmnt],pch4dmoxi.och4q10[veg.cmnt],pch4dmoxi.ko[veg.cmnt],pch4dmoxi.afp[veg.cmnt],pch4dmoxi.mvmax[veg.cmnt],pch4dmoxi.mvmin[veg.cmnt], pch4dmoxi.mvopt[veg.cmnt],pch4dmoxi.oxiref[veg.cmnt]);


  //********************************************************************************

   // Get environmental conditions for month "dm"
 	 atms.precsplt(atms.prec[dm][m], atms.tair[dm][m], hyd.rainthrough[dm][m], soil.snowthrough[dm][m]);

    switch (dm)
     {
     case 0:  if (m==0)
              {
               atms.prevtair = atms.tair[1][0];
               atms.prev2tair = atms.tair[1][1];
              }
              else
               {
                if (m ==1){
               atms.prevtair = atms.tair[0][29];
               atms.prev2tair = atms.tair[0][30];
                 }
               else
                {
               atms.prevtair = atms.tair[0][m-1];
               atms.prev2tair = atms.tair[0][m-2];
                }
               }
             break;

    default:
             if (m==0)
              {
               atms.prevtair = atms.tair[dm][0];
               atms.prev2tair = atms.tair[dm][1];
              }
              else
               {
                if (m ==1){
               atms.prevtair = atms.tair[dm][29];
               atms.prev2tair = atms.tair[dm][30];
                 }
               else
                {
               atms.prevtair = atms.tair[dm][m-1];
               atms.prev2tair = atms.tair[dm][m-2];
                }
               }
             break;
       }

    soil.snowinf[dm][m] = soil.snowmelt(elev, atms.tair[dm][m], atms.prevtair, y[I_SNWPCK]);

 //   soil.snowpack[dm][m]= atms.snowfall[dm][m] - soil.snowinf[dm][m];
    soil.snowpack[dm][m]= soil.snowthrough[dm][m] - soil.snowinf[dm][m];
    if (soil.snowpack[dm][m] < 0.0) { soil.snowpack[dm][m] = 0.0; }


  if (stmflg==1) {
// call soil thermal subroutine
/*    switch (dm) {
     case 0: if (dyr==0) {
             sthermal.airt19= atms.ttair[dyr][0][m]; // satisfy soil thermal model
             sthermal.airt29= (atms.ttair[dyr][0][m]+atms.ttair[dyr][0][m+1])/2.0;
             sthermal.airt39= (atms.ttair[dyr][0][m]+atms.ttair[dyr][0][m+2])/2.0; }
             else {
             sthermal.airt19= (atms.ttair[dyr-1][11][30]+atms.ttair[dyr][0][0])/2.0; // satisfy soil thermal model
             sthermal.airt29= atms.ttair[dyr][0][m];
             sthermal.airt39= (atms.ttair[dyr][0][m]+atms.ttair[dyr][0][m+1])/2.0;
              }
             break;
     case 11:if ( dyr<RTIME-3) {
             sthermal.airt19= (atms.ttair[dyr][11][m]+atms.ttair[dyr][11][m+1])/2.0; // satisfy soil thermal model
             sthermal.airt29= atms.ttair[dyr][11][m];
             sthermal.airt39= (atms.ttair[dyr][11][m]+atms.ttair[dyr+1][0][0])/2.0; }
             else {
             sthermal.airt19= (atms.ttair[dyr][CYCLE-2][m]+atms.ttair[dyr][11][m+1])/2.0; // satisfy soil thermal model
             sthermal.airt29= atms.ttair[dyr][11][m];
             sthermal.airt39= (atms.ttair[dyr][11][m]+atms.ttair[dyr][0][m+2])/2.0; }
             break;
     default: sthermal.airt19= (atms.ttair[dyr][dm-1][m]+atms.ttair[dyr][dm][m+1])/2.0; // satisfy soil thermal model
             sthermal.airt29= atms.ttair[dyr][dm][m];
             sthermal.airt39= (atms.ttair[dyr][dm][m]+atms.ttair[dyr][dm+1][m+1])/2.0;
             break;
         }
*/
//llc fix for daily version
     int l_days;

     if (m == 0) {
              if (dm == 0) {
                if(dyr == 0) {
                sthermal.airt19= atms.ttair[dyr][dm][m];
                sthermal.airt29= atms.ttair[dyr][dm][m+1];
                sthermal.airt39= atms.ttair[dyr][dm][m+2];
                }
                else {
                l_days = daysnumber(11, year-1);
                sthermal.airt19= atms.ttair[dyr-1][11][l_days-1];
                sthermal.airt29= atms.ttair[dyr][dm][m];
                sthermal.airt39= atms.ttair[dyr][dm][m+1];
                } 
              }               
              else {
              l_days = daysnumber(dm-1, year);
              sthermal.airt19= atms.ttair[dyr][dm-1][l_days-1];              
              sthermal.airt29= atms.ttair[dyr][dm][m];
              sthermal.airt39= atms.ttair[dyr][dm][m+1];
              }
     }
     else if (m == days -1) {
                  if (dm == 11) {
                    if (dyr == RTIME) {
                    sthermal.airt19= atms.ttair[dyr][dm][m-2]; 
                    sthermal.airt29= atms.ttair[dyr][dm][m-1];
                    sthermal.airt39= atms.ttair[dyr][dm][m]; 
                    }
                    else {
                    sthermal.airt19= atms.ttair[dyr][dm][m-1]; 
                    sthermal.airt29= atms.ttair[dyr][dm][m];
                    sthermal.airt39= atms.ttair[dyr+1][0][0]; 
                    }
                  }              
                  else {
                  sthermal.airt19= atms.ttair[dyr][dm][m-1]; 
                  sthermal.airt29= atms.ttair[dyr][dm][m];
                  sthermal.airt39= atms.ttair[dyr][dm+1][0];
                  }
     }
     else {  
              sthermal.airt19= atms.ttair[dyr][dm][m-1]; 
              sthermal.airt29= atms.ttair[dyr][dm][m];
              sthermal.airt39= atms.ttair[dyr][dm][m+1];
     }


     // using soil.snowpack, which is calculated from the WBM, to drive soil thermal model
     // convert mm to m for snow depth by dividing 1000, also assume the snow density is changed according to the snow classification, March,28, 2001, by Q. Z.
     // According to the vegetation type determine the wind speed, calculate cooling degree month (CDM) and daily averaged precipitation to determine the snow classication
     // snow classification determine the snow density, and therefore the snow depth, and snow thermal conductivity

     // determine the wind speed level
     int wind_speed; // high = 1; low =0.0

     switch (veg.cmnt) {
         case 1: wind_speed =1; break;
         case 2: wind_speed =1; break;
         case 3: wind_speed =0; break;
         case 4: wind_speed =0; break;
         case 5: wind_speed =0; break;
         case 6: wind_speed =1; break;
         case 7: wind_speed =1; break;
         case 8: wind_speed =1; break;
         case 9: wind_speed =0; break;
         case 10: wind_speed =1; break;
         case 11: wind_speed =0; break;
         case 12: wind_speed =1; break;
        }

     // determine the snow classes
     int snow_class;

     if (CDM < 50.0) snow_class = 6; // class Ephemeral
     else
       {
        if (CDM > 125.0) {
                    //     if (atms.prec[dm][m] / atms.daze[dm] >2.0)
                       if (atms.prec[dm][m] >2.0)
                           {
                           if (wind_speed ==1) snow_class = 1;
                           else  snow_class = 2;
                           }
                         else
                            {
                           if (wind_speed ==0) snow_class = 2;
                           else snow_class = 1;
                            }
                         }

        else {
           //   if (atms.prec[dm] / atms.daze[dm] <2.0)
              if (atms.prec[dm][m] < 2.0)
              {
               if (wind_speed ==1) snow_class = 4;
               else snow_class = 3;
              }
              else
               {
                if (wind_speed ==0) snow_class = 5;
                else snow_class = 5;
               }

            }
        }

// determine the snow denisty and snow thermal conductivity
  double snow_dens; // g mm-3

   switch (snow_class) {
   case 1: snow_dens = 0.28;  break;
   case 2: snow_dens = 0.225;  break;
   case 3: snow_dens = 0.25;  break;
   case 4: snow_dens = 0.25;  break;
   case 5: snow_dens = 0.30;  break;
   case 6: snow_dens = 0.35;  break;
   }

  sthermal.calcu_cdsnow = powl(10, (2.650 * snow_dens - 1.652));

  sthermal.water2 = soil.pctp2[dm][m]/100.0; // assume moss and organic have the same water content, 29/march/2001

  // end of the program of snow classification
/*
      switch (dm) {
     case 0: sthermal.hsnow19=(soil.snowpack[0][m]+soil.snowpack[0][m+1])/2.0/1000.0/snow_dens; // satisfy soil thermal model
             sthermal.hsnow29= soil.snowpack[0][m]/1000.0/snow_dens;
             sthermal.hsnow39= (soil.snowpack[0][m]+soil.snowpack[0][m+2])/2.0/1000.0/snow_dens;
             break;

     case 11: if (!(m == 30))
              {
              sthermal.hsnow19=(soil.snowpack[11][m]+soil.snowpack[11][m+1])/2.0/1000.0/snow_dens; // satisfy soil thermal model
              sthermal.hsnow29= soil.snowpack[11][m]/1000.0/snow_dens;
              sthermal.hsnow39= (soil.snowpack[11][m]+soil.snowpack[11][m+2])/2.0/1000.0/snow_dens;
              }
             else
               {
              sthermal.hsnow19=(soil.snowpack[11][m]+soil.snowpack[10][29])/2.0/1000.0/snow_dens; // satisfy soil thermal model
              sthermal.hsnow29= soil.snowpack[11][m]/1000.0/snow_dens;
              sthermal.hsnow39= (soil.snowpack[11][m]+soil.snowpack[10][28])/2.0/1000.0/snow_dens;
               }
              break;

     default: sthermal.hsnow19=(soil.snowpack[dm][m]+soil.snowpack[dm][m+1])/2.0/1000.0/snow_dens; // satisfy soil thermal model
              sthermal.hsnow29= soil.snowpack[dm][m]/1000.0/snow_dens;
              sthermal.hsnow39= (soil.snowpack[dm][m]+soil.snowpack[dm][m+2])/2.0/1000.0/snow_dens;
            break;
         }
*/
//llc fix for daily version


     if (m == 0) {
            if (dm == 0) {
              sthermal.hsnow19= soil.snowpack[dm][m]; 
              sthermal.hsnow29= soil.snowpack[dm][m+1];
              sthermal.hsnow39= soil.snowpack[dm][m+2];
              }
              else {
              l_days = daysnumber(dm-1, year);
              sthermal.hsnow19= soil.snowpack[dm-1][l_days-1]; 
              sthermal.hsnow29= soil.snowpack[dm][m];
              sthermal.hsnow39= soil.snowpack[dm][m+1];
              }
     }
     else if (m == days -1) {
            if (dm == 11) {
              sthermal.hsnow19= soil.snowpack[dm][m-2]; 
              sthermal.hsnow29= soil.snowpack[dm][m-1];
              sthermal.hsnow39= soil.snowpack[dm][m];
            }
            else {
            sthermal.hsnow19= soil.snowpack[dm][m-1]; 
            sthermal.hsnow29= soil.snowpack[dm][m];
            sthermal.hsnow39= soil.snowpack[dm+1][0];
            }
     }
     else {
            sthermal.hsnow19= soil.snowpack[dm][m-1]; 
            sthermal.hsnow29= soil.snowpack[dm][m];
            sthermal.hsnow39= soil.snowpack[dm][m+1];
     }

    int i;

    sthermal.is9 = 10;
    sthermal.ism19 = 9;
    sthermal.smass9 = 0.f;

	for (i=1;i <=210; i++) {
    sthermal.t9[i] = 0;
  	sthermal.xfa9[i] = -1e10f;
	sthermal.xfb9[i] = 0.f;
	sthermal.water9[i] = 1.f;
	sthermal.dx9[i] = 0.f;
	sthermal.weight9[i] = 0.f; }

// Need to change the soil moisture (water content for organic layer), snow thermal conductivity based on the snow classification ??

     if (sthermal.soiltemp_(&sthermal.water2, &sthermal.calcu_cdsnow, &sthermal.airt19, &sthermal.airt29, &sthermal.airt39, &sthermal.hsnow19, &sthermal.hsnow29, &sthermal.hsnow39,sthermal.weight9, &sthermal.smass9, &sthermal.is9, &sthermal.ism19, sthermal.x9, sthermal.dx9, sthermal.xfb9, sthermal.xfa9,
		sthermal.water9, sthermal.t9, &sthermal.tsoil,&sthermal.frontd,&sthermal.thawbegin,&sthermal.thawend,sthermal.diffsoilt,veg.cmnt) !=0)
      { printf("bad tem");
  //      getch();
        };

//      printf("airt19=%f,airt29=%f,airt39=%f,hsnow19=%f,hsnow29=%f,hsnow39=%f,\n");
    //  ++ integer (kswitch);

      atms.frontd[dm][m]=sthermal.frontd;
      atms.thawbe[dm][m]=sthermal.thawbegin;
      atms.thawend[dm][m]=sthermal.thawend;

      atms.tsoil[dm][m]=sthermal.tsoil;
      atms.dst5[dm][m]=sthermal.diffsoilt[0];
      atms.dst10[dm][m]=sthermal.diffsoilt[1];
      atms.dst20[dm][m]=sthermal.diffsoilt[2];
      atms.dst50[dm][m]=sthermal.diffsoilt[3];
      atms.dst100[dm][m]=sthermal.diffsoilt[4];
      atms.dst200[dm][m]=sthermal.diffsoilt[5];

     } //stmflg ==1
   /*** end of calling soil thermal model ***/

  //    printf("dyr=%i,dm=%i,m=%i,tair=%f, stw=%f, prec=%f, \n",dyr,dm,m,atms.tair[dm][m],atms.stw[dm][m],atms.prec[dm][m]); //llc

   

    getenviron(dm,m,dyr);
    //printf("%i,%i,%i,%f,%f,\n",dyr,dm,m,ch4dmdif.ch4cons[dm][m],ch4dmdif.ch4emis[dm][m]);
    //calibration nov 2020 youmi oh

    mintflag = adapt(NUMEQ,y,tol,dm,m);

    if (mintflag == 1) { intflag = 1; }

    if (blackhol != 0) { qualcon[dyr][itype] = 10; }

//    massbal(y,prevy);

    setPrevState(prevy,y);

    // Update carbon, nitrogen and water pools and fluxes from
    //  integrator results

 //  for (m =0; m < days; m++)
    setMonth(dm, y,m);    //llc fix for daily
  if(dyr > 20) {
    double sm_out[6];
    if (veg.cmnt == 9) { 
      if ((dyr == 23 && dm == 11) || (dyr == 24)) {
      sm_out[0]=hydm.InterpolatSM(30);
      sm_out[1]=hydm.InterpolatSM(50);
      sm_out[2]=hydm.InterpolatSM(90);
      sm_out[3]=hydm.InterpolatSM(160);
      sm_out[4]=hydm.InterpolatSM(230);
      sm_out[5]=hydm.InterpolatSM(300);  
      }
      else {
      sm_out[0]=hydm.InterpolatSM(20);
      sm_out[1]=hydm.InterpolatSM(30);
      sm_out[2]=hydm.InterpolatSM(60);
      sm_out[3]=hydm.InterpolatSM(110);
      sm_out[4]=hydm.InterpolatSM(160);
       sm_out[5]=hydm.InterpolatSM(210);  
      }
    }
    if (veg.cmnt == 7) { 
      if ((dyr == 23 && dm == 11) || (dyr == 24)) {
      sm_out[0]=hydm.InterpolatSM(20);
      sm_out[1]=hydm.InterpolatSM(40);
      sm_out[2]=hydm.InterpolatSM(80);
      sm_out[3]=hydm.InterpolatSM(150);
      sm_out[4]=hydm.InterpolatSM(220);
      sm_out[5]=hydm.InterpolatSM(290);  
      }
      else {
      sm_out[0]=hydm.InterpolatSM(10);
      sm_out[1]=hydm.InterpolatSM(20);
      sm_out[2]=hydm.InterpolatSM(50);
      sm_out[3]=hydm.InterpolatSM(100);
      sm_out[4]=hydm.InterpolatSM(150);
      sm_out[5]=hydm.InterpolatSM(200);  
      }
    }
//  printf("%i,%i,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%i\n",dyr,dm,atms.tair[dm][m],sm_out[0],sm_out[1],sm_out[2],sm_out[3],sm_out[4],sm_out[5],atms.dst10[dm][m],atms.dst20[dm][m],atms.dst50[dm][m],veg.cmnt);  //llc
  }
//    printf("%i,\n",veg.cmnt);
    resetODEflux(y);

  }  // end of days
 }
// exit(-1);

  //soil.yravlh2o /= 12.0;
  soil.yrrgrndh2o /= 12.0;
  soil.yrsnowpack /= 12.0;
  soil.yrsgrndh2o /= 12.0;
//  soil.yrsmoist /= 12.0;
//  soil.yrpctp /= 12.0;
 // soil.yrvsm /= 12.0;

   // added for 2-box hydrology

  soil.yravlh2o1 /= 12.0;
  soil.yravlh2o2 /= 12.0;
  soil.yravlh2o3 /= 12.0;

  soil.yrsmoist1 /= 12.0;
  soil.yrsmoist2 /= 12.0;
  soil.yrsmoist3 /= 12.0;

  soil.yrpctp1 /= 12.0;
  soil.yrpctp2 /= 12.0;
  soil.yrpctp3 /= 12.0;

  soil.yrvsm1 /= 12.0;
  soil.yrvsm2 /= 12.0;
  soil.yrvsm3 /= 12.0;

  atms.yrtsoil /= 12.0; // for soil temperature
  atms.yrfrontd /= 12.0; // for soil temperature
  atms.yrthawbegin /= 12.0; // for soil temperature
  atms.yrthawend /= 12.0; // for soil temperature

  if (endeq > 0) { ++endeq; }

  return endeq;

};

