/*****************************************************************
Methane Dynamics
Q. Zhuang, 19/Feb/2003
/***************************************************************** */

#if !defined(METHANEPRO_H)
  #include "methanepro.hpp"
#endif

// Methane production rate occurred between the water table and the lower boundary
// the soil column is devided as 5 cm depth interval
//double CH4DMPRO::MethanePR(const double& mgo, const double& fsom, const double& fcdis, const double& fmst,
//              const double& fph, const double& frx)
double CH4DMPRO::MethanePR(const double& mgo,  double fsom,  double fcdis,  double fmst,
               double fph,  double frx)

 {
 double methanepr; // rate of methane production at depth z and time t
// double mgo; maximum methane production rate, uMh-1; assume 0.3 umh-1 for Alaska tundra (walter et al., )
  methanepr = mgo * fsom * fcdis * fmst * fph * frx;

//  printf("mgo=%f,fsom=%f,fcdis=%f,fmst=%f,fph=%f,frx=%f,\n",mgo,fsom,fcdis,fmst,fph,frx);

 return methanepr;
 }

// Effects of organic matter to methanogenesis
//double CH4DMPRO::EffectOM(const double& maxfresh, const double& vegNPP, const double& kc, const double& residsub)
double CH4DMPRO::EffectOM(const double& maxfresh, const double& vegNPP)
{
 double fsom;
 double freshorg; // fresh organic matter from the vegetation

//vegNPP is either presrcibed or simulated from TEM
// maxfresh is parameter for the site, annual max value (gc m-2 yr-1)
//Kc -- half saturation constant of methanogenic acetate consumption 0.1 mM, Segers and kengen, 1998
// See also for above at Fulkusaki et al., 1990, 0.1mM converse to uM = 100 uM
// residsub -- residual substrate availability for methanogenesis

// freshorg = residsub + vegNPP;
// fsom = maxfresh * freshorg / (kc + freshorg);
   if (vegNPP <= 0.0) freshorg = 0.01 * maxfresh;
   else freshorg = maxfresh + vegNPP;
//   fsom = 1.0 + (freshorg / maxfresh);
  fsom = freshorg / maxfresh;

 return fsom;
}

// Effects of organic matter distribution in the soil to methanogenesis
double CH4DMPRO::EffectOMD(const double& vegtype, const double& depthz, const double& rootd, const double& lowb)
{

 double fcdis; // the index of organic matter distribution as function of the rooting depth and upper and lower boundary
 double rtz;

 // for vegetated area, vegetation type (2-34)
 // hydm_xtext() produce rooting depth, as meter, need to transfer to mm = 1000* rootz
 // lowb -- lower boundary -- parameter say, 1000mm, 1m

  rtz = rootd * 1000.0;  // converse m to mm for rooting depth

  if (vegtype != 0)
  {
    if ( (depthz <= rtz) && (depthz > 0.0) ) fcdis = 1.0;
    if ( (depthz > rtz) && (depthz < lowb) )
     {
      fcdis = exp( - (depthz - rtz) / 10.0);
      }
  }
  else // unvegetated area
   {
    fcdis = 0.875 * exp(- depthz / 10.0);
   }


 return fcdis;
}

// Effects of soil temperature to methanogenesis
//double CH4DMPRO::EffectST(const double& soilt, const double& pch4q10)
double CH4DMPRO::EffectST( double soilt, double pch4q10,  double proref, const int& vegtype)
{
  double fmst;
  double tt;
//  double tref = 10.0; // reference soil temperature for methanogenesis, 7
// ch4q10 is a coefficient with a constant, (0.6 as used in Walter et al., )
//  fmst = exp (soilt) * pow (pch4q10, (soilt - tref) / 10.0);

  tt = (soilt - proref) / 10.0;

  fmst = pow(pch4q10, tt);

//  printf(" %f %f %f %f %f\n", pch4q10, tt, soilt, proref, fmst );

  return fmst;

}

//Interpolating soil temperature to obtain every 1 cm depth soil temperatures with Lagrange method
// Numerical method of computation and FORTRAN lanuage, Xianyi Zheng, 1986
double CH4DMPRO::InterpolatST(const double& dst1, const double& dst2,const double& dst3,
                const double& dst4, const double& dst5, const double& dst6,  double x)
{
  double f, p;
  int i, j;
  double x0[6], y0[6];

    x0[0] = 5.0;
    x0[1] = 10.0;
    x0[2] = 20.0;
    x0[3] = 50.0;
    x0[4] = 100.0;
    x0[5] = 200.0;

    y0[0] = dst1;
    y0[1] = dst2;
    y0[2] = dst3;
    y0[3] = dst4;
    y0[4] = dst5;
    y0[5] = dst6;

  //youmi 2020 isotope
  // test mar 2020 due to low emission
  /* f = 0.0;
  for (i = 0; i < 6; i++)
  {
   p = 1.0;
   for (j =0 ; j < 6; j++)
   {
    if (i!=j) p = p * (1.0/x - x0[j]) / (x0[i] - x0[j]);
   }

   f = f + p * y0[i];
  } */

   // added by Licheng Liu, August 2018
   //     //linear interpolation llc
    f=0.0;
    if(x <= x0[1]) {f=y0[0]+(y0[1]-y0[0])*(x-x0[0])/(x0[1]-x0[0]);}
    if(x > x0[1] && x <= x0[2]) {f=y0[1]+(y0[2]-y0[1])*(x-x0[1])/(x0[2]-x0[1]);}
    if(x > x0[2] && x <= x0[3]) {f=y0[2]+(y0[3]-y0[2])*(x-x0[2])/(x0[3]-x0[2]);}
    if(x > x0[3] && x <= x0[4]) {f=y0[3]+(y0[4]-y0[3])*(x-x0[3])/(x0[4]-x0[3]);}
    if(x > x0[4]) {f=y0[4]+(y0[5]-y0[4])*(x-x0[4])/(x0[5]-x0[4]);}

 return f;

}

// Effects of soil PH to methanogenesis
// need reading in soil pH, similar to elevation
double CH4DMPRO::EffectPH(const double& soilph)
{
// const double phmin = 5.5;
 const double phmin = 3.0;
 const double phmax = 9.0;
 const double phopt = 7.5;

 double fph;
 double v1, v2, v3;

  v1 = soilph - phmin;
  v2 = soilph - phmax;
  v3 = soilph - phopt;

  fph = v1 * v2 / (v1 * (v2 - pow(v3,2.0)));
  return fph;

}


// Effects of soil redox potential to methanogenesis
double CH4DMPRO::EffectRX(const double& ehl)
{
 double frxp;

 if (ehl <= -200.0) frxp = 1.0;
 else
 {
 if ((ehl > -200) && (ehl <= -100.0)) frxp = -0.01 * ehl - 1;
 if (ehl >= -100.0) frxp = 0.0;
 }

 return frxp;
}

// calculate the redox potential
double CH4DMPRO::RedoxP(const double& watertable, const double& depthz, const double& wfpsl,
       const int& vegtype, const double& lowb)
{
 double ehl;
 double wfps;  // 0 - 1.0  as percentage

// depthz -- depth z
// wfpsl -- the water filled pore space -- pctp
// const double CR = 100.0; // daily variation of redox potential (mvday-1) Zhang et al., set up as 100
 const double CR = 200.0; // daily variation of redox potential (mvday-1)

 double AL;
 double FRD = 0.0013;  // area of the cross section of a typical fine root (cm2)
 // McClaugherty et al., 1982 estimates fine root length per m2 ground area = 1300/130 (mm-2)
 // the above translate to root length density (cm root cm-3 soil) by assuming the rooting depth 100cm;
 // RLDL = 0.001 cm root cm-3 soil
 double RLDL = 0.001;
 double PA; // between 0 to 1.0, grasses and sedges are good transport =1.0; tree = 0.5; mosses =0.0

 wfps = wfpsl /100.0;

 if (vegtype == 7)
     { PA = 1.0;}
 else
  {
   if (vegtype == 1) PA = 0.0;
   else PA = 0.5;
  }

 AL = FRD * PA * RLDL;

// if (depthz <= watertable)
 if ((depthz <= lowb ) && (depthz > watertable))
  {
   ehl = CR * (AL - 1.0);
  }
 else
  {
   ehl = CR * (AL + 1.0 - wfps);
  }

  return ehl;
}


// get methane production ecd
void CH4DMPRO::getecdch4pro(char ecd[80])
{
  getch4pro(ecd);

}

//added isotope parameter youmi 2020
void CH4DMPRO::getecdch4iso(char ecd[80])
{
  getch4iso(ecd);

}

void CH4DMPRO::getecdch4pro(ofstream& rflog1)
{

  char ecd[80];

  cout << "Enter name of the file with methane production parameter values (.ECD):" << endl;
  fpara >> ecd;

  rflog1 << "Enter name of the file with methane production parameter values (.ECD):";
  rflog1 << ecd << endl << endl;

  getch4pro(ecd);

};

//added youmi isotope
void CH4DMPRO::getecdch4iso(ofstream& rflog1)
{

  char ecd[80];

  cout << "Enter name of the file with methane isotope parameter values (.ECD):" << endl;
  fpara >> ecd;

  rflog1 << "Enter name of the file with methane isotope parameter values (.ECD):";
  rflog1 << ecd << endl << endl;

  getch4iso(ecd);

};


void CH4DMPRO::getch4pro(char ecd[80])
{

  const int NUMVAR = 10;
  char dummy[35][40];
  ifstream infile;
  int i;
  int dcmnt;

  long update[35];

  infile.open(ecd, ios::in);

  if (!infile)
  {
    cerr << "\nCannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  for (i = 0; i < NUMVAR; i++) { infile >> dummy[i]; }
  for (dcmnt = 1; dcmnt < 15+1; dcmnt++) //LLC for calibrated parameters
  {
  infile >> dummy[dcmnt] >> dummy[dcmnt]>> mgo[dcmnt] >> kc[dcmnt]>> pmethaneq[dcmnt]
            >> oxi_c[dcmnt] >> maxfresh[dcmnt] >> lowb[dcmnt] >> proref[dcmnt] >> update[dcmnt];
  
  pro_para[dcmnt][1]=mgo[dcmnt]; //LLC for calibrated parameters
  pro_para[dcmnt][2]=kc[dcmnt];
  pro_para[dcmnt][3]=pmethaneq[dcmnt];
  pro_para[dcmnt][4]=oxi_c[dcmnt];
  pro_para[dcmnt][5]=maxfresh[dcmnt];
  pro_para[dcmnt][6]=lowb[dcmnt];
  pro_para[dcmnt][7]=proref[dcmnt];

// cout << mgo[dcmnt] << kc[dcmnt] << tpch4q10[dcmnt] << oxi_c[dcmnt] << maxfresh[dcmnt] << lowb[dcmnt] << proref[dcmnt]<< endl;

  }
  infile.close();

};

//added for isotope youmi
void CH4DMPRO::getch4iso(char ecd[80])
{

  const int NUMVAR = 9;
  char dummy[35][40];
  ifstream infile;
  int i;
  int dcmnt;

  long update[35];

  infile.open(ecd, ios::in);

  if (!infile)
  {
    cerr << "\nCannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  for (i = 0; i < NUMVAR; i++) { infile >> dummy[i]; }
  for (dcmnt = 1; dcmnt < 15+1; dcmnt++) //LLC for calibrated parameters
  {
  infile >> dummy[dcmnt] >> dummy[dcmnt]>> alpha_am[dcmnt] >> alpha_hm[dcmnt]>> alpha_mo[dcmnt]
            >> alpha_tp[dcmnt] >> alpha_te[dcmnt] >> alpha_td[dcmnt] >> update[dcmnt];

  iso_para[dcmnt][1]=alpha_am[dcmnt]; //LLC for calibrated parameters
  iso_para[dcmnt][2]=alpha_hm[dcmnt];
  iso_para[dcmnt][3]=alpha_mo[dcmnt];
  iso_para[dcmnt][4]=alpha_tp[dcmnt];
  iso_para[dcmnt][5]=alpha_te[dcmnt];
  iso_para[dcmnt][6]=alpha_td[dcmnt];

// cout << mgo[dcmnt] << kc[dcmnt] << tpch4q10[dcmnt] << oxi_c[dcmnt] << maxfresh[dcmnt] << lowb[dcmnt] << proref[dcmnt]<< endl;

   }
     infile.close();

     };


void CH4DMPRO::getch4pro(ofstream& rflog1) {

  const int NUMVAR = 10;
  char dummy[NUMVAR][40];
  ifstream infile;
  int i;
  int dcmnt;
  char ecd[20];

  int update[12];

  infile.open(ecd, ios::in);

  cout << "Enter name of methane production (.ECD) data file with parameter values:" << endl;
  fpara >> ecd;

  rflog1 << "Enter name of methane production(.ECD) data file with parameter values:" << ecd << endl << endl;

  infile.open(ecd, ios::in);

  if (!infile) {
    cerr << "\nCannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  for (i = 0; i < NUMVAR; i++) { infile >> dummy[i]; }
  for (dcmnt = 1; dcmnt < 15+1; dcmnt++) //LLC for calibrated parameters
  {
  infile >> dummy[0] >> dummy[0]>> mgo[dcmnt] >> kc[dcmnt]>> pmethaneq[dcmnt]
              >> oxi_c[dcmnt] >> maxfresh[dcmnt] >> lowb[dcmnt] >> proref[dcmnt] >> update[dcmnt];
  
  pro_para[dcmnt][1]=mgo[dcmnt]; //LLC for calibrated parameters
  pro_para[dcmnt][2]=kc[dcmnt];
  pro_para[dcmnt][3]=pmethaneq[dcmnt];
  pro_para[dcmnt][4]=oxi_c[dcmnt];
  pro_para[dcmnt][5]=maxfresh[dcmnt];
  pro_para[dcmnt][6]=lowb[dcmnt];
  pro_para[dcmnt][7]=proref[dcmnt];

  }

  infile.close();

};

//added for isotope youmi
void CH4DMPRO::getch4iso(ofstream& rflog1) {

  const int NUMVAR = 9;
  char dummy[NUMVAR][40];
  ifstream infile;
  int i;
  int dcmnt;
  char ecd[20];

  int update[12];

  infile.open(ecd, ios::in);

  cout << "Enter name of methane isotope (.ECD) data file with parameter values:" << endl;
  fpara >> ecd;

  rflog1 << "Enter name of methane isotope (.ECD) data file with parameter values:" << ecd << endl << endl;

  infile.open(ecd, ios::in);

  if (!infile) {
    cerr << "\nCannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  for (i = 0; i < NUMVAR; i++) { infile >> dummy[i]; }
  for (dcmnt = 1; dcmnt < 15+1; dcmnt++) //LLC for calibrated parameters
  {
  infile >> dummy[dcmnt] >> dummy[dcmnt]>> alpha_am[dcmnt] >> alpha_hm[dcmnt]>> alpha_mo[dcmnt]
            >> alpha_tp[dcmnt] >> alpha_te[dcmnt] >> alpha_td[dcmnt] >> update[dcmnt];

  iso_para[dcmnt][1]=alpha_am[dcmnt]; //LLC for calibrated parameters
  iso_para[dcmnt][2]=alpha_hm[dcmnt];
  iso_para[dcmnt][3]=alpha_mo[dcmnt];
  iso_para[dcmnt][4]=alpha_tp[dcmnt];
  iso_para[dcmnt][5]=alpha_te[dcmnt];
  iso_para[dcmnt][6]=alpha_td[dcmnt];

  }

  infile.close();

};


