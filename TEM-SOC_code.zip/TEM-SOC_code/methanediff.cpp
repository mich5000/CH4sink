/*****************************************************************
Methane Dynamics ---- Methane diffusion
Q. Zhuang, 11/March/2003
J.Tang, add initialization for array co, which could otherwise cause incorrect ch4con
/***************************************************************** */

#if !defined(METHANEDIFF_H)
  #include "methanediff.hpp"
#endif


//llc add for methane initail set up
void CH4DMDIF::premethane()  
{

	int i;
	for(i = 0; i < 400 ; i ++)
	{
                ch4con[i] = 0.0001;
                ch4con_b[i] = 0.0001;
	}
        pre_stw = 0.0;




}


double CH4DMDIF::Diffusivity(const double& sand, const double& silt, const double& clay, int satyorn)

 {

// See Walter et al., 2001
 const double d1 = 0.2; // diffusion coefficient of CH4 in the air and unsaturated soil (0.2 cm-2 s-1)
 const double d2 = 0.2* pow(10,-4); // diffusion coefficient of CH4 in the saturated soil and water (cm-2 s-1)
 const double dd = 0.66;  // a tortuosity coefficient, suggesting that the apparent path is about two-thirds the length of the real average path of diffusion in the soil
 const double pvsand = 0.45; // relative volume of coarse pores in sandy soils
 const double pvsilt = 0.20; // silt soils
 const double pvclay = 0.14; // clay soils

 double diffu; // rate of methane oxidation rate at depth z and time t
 double ftxt;

  ftxt = (sand * pvsand + silt * pvsilt + clay * pvclay) * 0.01;

  if (satyorn == 0)  diffu = d1 * dd * ftxt;
  else diffu = d2 * dd * ftxt;

 // printf("df=%f,dd=%f,ftxt=%f",diffu,dd,ftxt);
 return diffu;

}

//moisture effect on diffusitivity
void CH4DMDIF::EffdfSM(const double sm[], const double smsat[], const int& nodes)
{
	//sm, actual soil moisture
	//saturated soil moisture
	int i;
	for(i = 0; i < nodes + 1; i ++)
	{
		sm2dif[i] = -pow((sm[i] - 0.01)/(smsat[i]-0.01),2.0) + 1.0;
		sm2dif[i] = sm2dif[i] > 0.01 ? sm2dif[i] : 0.01;
//		cout <<"sm2dif["<<i<<"]="<<sm2dif[i]<<" sm["<<i<<"]="<<sm[i]<<" smsat["<<i<<"]="<<smsat[i]<<endl;
	}
//	cin.get();



}

// calculate the CH4 concentration profile and fluxes
//double CH4DMDIF::CH4flxandCon(const double& df[], const double& pr[], const double& cr[], const double& lowb )
double CH4DMDIF::CH4flxandCon(const double& ddf, const double& lowb )

{

 const int MAXN = 400; //maximum nodes
 int nodes; // number of nodes, which is related to low boundary (lowb)
 const double x = 1.0; // depth step 10mm or 1cm
// const double aoc = 0.076; // atmospheric ch4 concentration (uM)
// const double aoc = 0.076 * 0.001; // atmospheric ch4 concentration (u mol cm-3)

 double a[MAXN],b[MAXN],c[MAXN], d[MAXN];
 double u[MAXN]; // u mol cm-3
 double k[MAXN]; // conductivity
 double co[MAXN] ={0.0}; //concentration
 double z[MAXN]; //depth
 double df[MAXN];//diffusion

 int i;
 double ch4flx;

 nodes = int (ceil(lowb / 10.0));

 z[0] = 0.0;
 for (i = 0; i < nodes+1; i++)
  {
	df[i] = ddf * sm2dif[i];
   z[i+1] = z[i] + x;
  }

// k[0] = k_zero;
 k[0] = df[0] / 1.0;
 co[0] = aoch4;  

 for (i =1; i < nodes+1; i++)
  {
   u[i] = 0.0;
   if (i < nodes+1) k[i] = df[i] / (z[i+1] - z[i]); // llc not right
   else k[i] = 0.0;
   a[i+1] = -k[i];
   b[i] = k[i-1] + k[i];
   c[i] = -k[i];
   d[i] = u[i];
  }

  d[1] = d[1] + k[0] * co[0];
  for (i = 1; i < nodes; i++)
   {
    c[i] = c[i] / b[i];
    d[i] = d[i] / b[i];
    b[i+1] = b[i+1] - a[i+1]*c[i];
    d[i+1] = d[i+1] - a[i+1]*d[i];
    }

  co[nodes]= d[nodes] / b[nodes];
//  cout <<d[nodes] <<","<< b[nodes]<<","<<co[nodes+1]<<endl;
  for (i = nodes-1; i > 0; i--) //llc fix
   {
    co[i] = d[i] - c[i] * co[i+1];
//	cout <<d[i]<<","<< c[i]<<","<<co[i+1]<<endl;
    ch4con[i] = co[i] / 0.001;  // converse to uM
   }

  // surface flux of methane, positive indicates flux to soil

  ch4flx = - df[1] * (co[1] - co[0]) / 1.0;  // u mol cm-2 s-1

  ch4flx = ch4flx * pow(10,4); // u mol m-2 s-1;
  ch4flx = ch4flx * pow(10,-6); // mol m-2 s-1;
  ch4flx = ch4flx * 16; // g m-2 s-1;
  ch4flx = ch4flx * 8.64 * pow(10,4); // g m-2 day-1;
  ch4flx = ch4flx * pow(10,3); // mg m-2 day-1;

  return ch4flx;
 }

double CH4DMDIF::ACH4flxandCon(const double& ddf, const double& lowb )

{

 const int MAXN = 400; //maximum nodes
 int nodes; // number of nodes, which is related to low boundary (lowb)
 const double x = 1.0; // depth step 10mm or 1cm
// const double aoc = 0.076; // atmospheric ch4 concentration (uM)
// const double aoc = 0.076 * 0.001; // atmospheric ch4 concentration (u mol cm-3)

 double a[MAXN],b[MAXN],c[MAXN], d[MAXN], u[MAXN];
 double k[MAXN]; // conductivity
 double co[MAXN]={0.0}; //concentration
 double z[MAXN]; //depth
 double df[MAXN];//diffusion

 int i;
 double ch4flx;

 nodes = int (ceil(lowb / 10.0));

 z[0] = 0.0;
 for (i = 0; i < nodes; i++)
  {
   	df[i] = ddf * sm2dif[i];
   z[i+1] = z[i] + x;
  }

// k[0] = k_zero;
 k[0] = df[0] / 1.0;
 co[0] = aoch4;

 for (i =1; i < nodes+1; i++)
  {
	
   u[i] =  - ch4oxirate1[i] * pow(10,-3) / (3.6 * pow(10,3));  // u mol cm-3 s-1
   if (i < nodes+1) k[i] = df[i] / (z[i+1] - z[i]);
   else k[i] =0.0;
   a[i+1] = -k[i];
   b[i] = k[i-1] + k[i];
   c[i] = -k[i];
   d[i] = u[i];
  }

  d[1] = d[1] + k[0] * co[0];
  for (i=1; i < nodes; i++)
   {
    c[i] = c[i] /b[i];
    d[i] = d[i] / b[i];
    b[i+1] = b[i+1] -a[i+1]*c[i];
    d[i+1] = d[i+1] -a[i+1]*d[i];
    }

  co[nodes]= d[nodes]/b[nodes];

  for (i = nodes; i > 0; i--)
   {
    co[i] = d[i] - c[i] * co[i+1];
    ch4con[i] = co[i] / 0.001;  // converse to uM

   }

  // surface flux of methane, positive indicates flux to soil

  ch4flx = - df[1] * (co[1] - co[0]) / 1.0;  // u mol cm-2 s-1

  ch4flx = ch4flx * pow(10,4); // u mol m-2 s-1;
  ch4flx = ch4flx * pow(10,-6); // mol m-2 s-1;
  ch4flx = ch4flx * 16; // g m-2 s-1;
  ch4flx = ch4flx * 8.64 * pow(10,4); // g m-2 day-1;
  ch4flx = ch4flx * pow(10,3); // mg m-2 day-1;

//  cout <<ch4flx<<","<<ddf<<","<<lowb<<",";
  return ch4flx;
 }


//llc add for final diffusion=========================================================================================

double CH4DMDIF::FCH4flxandCon(const double& lowb,const double& watertable, const double& soilt, const double& dt)

{

 const int MAXN = 400; //maximum nodes
 int nodes; // number of nodes, which is related to low boundary (lowb)
 const double x = 1.0; // depth step 10mm or 1cm
// const double aoc = 0.076; // atmospheric ch4 concentration (uM)
// const double aoc = 0.076 * 0.001; // atmospheric ch4 concentration (u mol cm-3)

 double a[MAXN],b[MAXN],c[MAXN], d[MAXN];
 double u[MAXN]; // u mol cm-3
 double k1[MAXN],k2[MAXN]; // conductivity  k1 = C-, k2=C+
 double z[MAXN]; //depth
 double df[MAXN];//diffusivity

 int i;
 double ch4flx;
 double alpha[MAXN],deltat;
 double c1[MAXN], d1[MAXN]; //llc fix for c1, d1

 nodes = int (ceil(lowb / 10.0));
 deltat = dt*3600.0;

 z[0] = 0.0;

//!!!!!!! note: we should know that first layer ( i = 0) is atmosphere, which is different from the defination of ch4 concentration in soil (10mm depth when i=0)
 u[0] = aoch4;
 df[0] = fdfs[0] * sm2dif[0];
 alpha[0] = 0.0;
 for (i = 0; i < nodes; i++)
  {
    df[i+1] = fdfs[i] * sm2dif[i];
    z[i+1] = z[i] + x;  //cm
    u[i+1] = ch4con[i]*0.001;  // uM --> u mol cm-3 
    alpha[i+1] = (ch4pror[i] - ch4oxir[i] - ch4ebur[i] - ch4patr[i]-ch4poxir[i]) / 1000.0 / deltat;  //llc  uM/ dt hr > u mol cm-3 s
//   if(ch4con[nodes-1] > 500) printf("%f,%f,%f,\n",ch4disl[i],ch4ebur[i],ch4con[i]);
  }

 


 for (i = 0; i < nodes+1; i++)
  {


   if(i == 0) {
   k1[i] = 0.0;
//   k2[i] = 0.5*(df[i]+df[i+1])*deltat/(2.0*pow(x,2)); 
//   d[i] = deltat*alpha[i] + u[i]*(1.0-k1[i]-k2[i]) + u[i+1]*k2[i];
   k2[i] = 0.0; 
   d[i] = aoch4;
   }
   else if(i == nodes) {
   k1[i] = 0.5*(df[i]+df[i-1])*deltat/(2.0*pow(x,2)); 
   k2[i] = 0.0; 
   d[i] = deltat*alpha[i] + u[i-1]*k1[i] + u[i]*(1.0-k1[i]-k2[i]);
   }
   else {
   k1[i] = 0.5*(df[i]+df[i-1])*deltat/(2.0*pow(x,2));  //time step = dt * 3600 sec
   k2[i] = 0.5*(df[i]+df[i+1])*deltat/(2.0*pow(x,2)); 
   d[i] = deltat*alpha[i] + u[i-1]*k1[i] + u[i]*(1.0-k1[i]-k2[i]) + u[i+1]*k2[i];
   }

   a[i] = -k1[i];
   b[i] = 1.0 + k1[i] + k2[i];
   c[i] = -k2[i];

  }

  for (i=0; i < nodes+1; i++)
   {
    if (i == 0) {
    c1[i] = c[i] / b[i];
    d1[i] = d[i] / b[i];
    }
    else {
    c1[i] = c[i] / (b[i]-a[i]*c1[i-1]);  // c1[nodes] will not be used
    d1[i] = (d[i]-a[i]*d1[i-1]) / (b[i]-a[i]*c1[i-1]);
    }
   }

  u[nodes]= max(pow(10,-10),d1[nodes]);

  for (i = nodes-1; i >= 0; i--)
   {
    ch4con[i] = u[i+1]/ 0.001;  // converse to uM
    u[i] = max(pow(10,-10),d1[i] - c1[i] * u[i+1]);
   }

  // surface flux of methane, positive indicates flux to soil

  ch4flx = - df[1] * (u[1] - u[0]) / 1.0;  // u mol cm-2 s-1
  ch4flx = ch4flx * pow(10,4); // u mol m-2 s-1;
  ch4flx = ch4flx * pow(10,-6); // mol m-2 s-1;
  ch4flx = ch4flx * 16; // g m-2 s-1;
  ch4flx = ch4flx * deltat; // g m-2 dt hr-1;
  ch4flx = ch4flx * pow(10,3); // mg m-2 dt hr-1;
//  printf("%f,%f,%f,%f,\n",ch4flx,df[1],u[1],u[0]);
//  if (ch4flx < -50.0) printf("!!!! error\n");
  if (soilt < 0.0) { ch4flx = 0.001;}
  return ch4flx;
 }

/*
// get methane production ecd
void CH4DMDIF::getecdch4dif(char ecd[80])
{
  getch4dif(ecd);

}

void CH4DMDIF::getecdch4dif(ofstream& rflog1)
{

  char ecd[80];

  cout << "Enter name of the file with methane oxidation parameter values (.ECD):" << endl;
  fpara >> ecd;

  rflog1 << "Enter name of the file with methane oxidation parameter values (.ECD):";
  rflog1 << ecd << endl << endl;

  getch4dif(ecd);

};

void CH4DMDIF::getch4dif(char ecd[80])
{

  const int NUMVAR = 11;
  char dummy[35][40];
  ifstream infile;
  int i;
  int dcmnt;

  long update[35];

  infile.open(ecd, ios::in);

  if (!infile)
  {
    cerr << "\nCannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  for (i = 0; i < NUMVAR; i++) { infile >> dummy[i]; }
  for (dcmnt = 1; dcmnt < 35; dcmnt++)
  {
  infile >> dummy[dcmnt] >> dummy[dcmnt]>> omax[dcmnt] >> kc[dcmnt]>> och4q10[dcmnt]
            >> ko[dcmnt] >> afp[dcmnt] >> mvmax[dcmnt] >> mvmin[dcmnt] >> mvopt[dcmnt] >> update[dcmnt];

  }
  infile.close();

};


void CH4DMDIF::getch4dif(ofstream& rflog1) {

  const int NUMVAR = 11;
  char dummy[NUMVAR][40];
  ifstream infile;
  int i;
  int dcmnt;
  char ecd[20];

  int update[12];

  infile.open(ecd, ios::in);

  cout << "Enter name of methane oxidation (.ECD) data file with parameter values:" << endl;
  fpara >> ecd;

  rflog1 << "Enter name of methane oxidation(.ECD) data file with parameter values:" << ecd << endl << endl;

  infile.open(ecd, ios::in);

  if (!infile) {
    cerr << "\nCannot open " << ecd << " for data input" << endl;
    exit(-1);
  }

  for (i = 0; i < NUMVAR; i++) { infile >> dummy[i]; }
  for (dcmnt = 1; dcmnt < 35; dcmnt++)
  {
  infile >> dummy[0] >> dummy[0]>> omax[dcmnt] >> kc[dcmnt]>> och4q10[dcmnt]
            >> ko[dcmnt] >> afp[dcmnt] >> mvmax[dcmnt] >> mvmin[dcmnt] >> mvopt[dcmnt] >> update[dcmnt];
  }

  infile.close();

};
*/
