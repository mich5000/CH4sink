/* **************************************************************
*****************************************************************
POTCLM42.CPP - describes physical characteristics of the atmosphere
             - modified by DWK on 20000102
20000616 - DWK adds the enum variable sradkey to declaration in
           potsclm423e.hpp


           modify to get daily XGIRR,  Q. Zhuang, 29/Dec/2002

           Modify to new algorithms to get daily XGIRR, 03/February/2003, hold off
           
*****************************************************************
************************************************************** */

#if !defined(DAPOTCLM423_H)
  #include "dapotclm423e.hpp"
#endif

/* **************************************************************
************************************************************** */

Potsclm::Potsclm() : Atmosphere()
{

// Initialize predstr array

  strcpy(predstr[0],"GIRR");
  strcpy(predstr[1],"NIRR");
  strcpy(predstr[2],"PAR");
  strcpy(predstr[3],"CLDINESS");

};

/* **************************************************************
		     Public Functions
************************************************************** */

double Potsclm::mkclds(const double& girr, const double& nirr)
{

  double clouds;

  if (nirr >= (0.71 * girr)) { return clouds = 0.0; }
  else
  {
    clouds = 1.0 - (((nirr/girr) - 0.23)/0.48);
    clouds *= 100.0;
  }
  if (clouds > 100.0) { clouds = 100.0; }

  return clouds;

};


/* **************************************************************
************************************************************** */


/* **************************************************************
************************************************************** */
// to modify to daily output
double Potsclm::xgirr(const double& lat, const int& dm, double& sumday)
{

  const double pi = 3.141592654;                // Greek "pi"
  const double sp = 1368.0 * 3600.0 / 41860.0;  // solar constant

  double lambda;
  double sumd;
  double sig;
  double eta;
  double sinbeta;
  double sb;
  double sotd;
  int day;
  int hour;
  double gross;

  int tdm;

  tdm = dm;
  for (tdm = 0; tdm<31; tdm++)
  ndays[0] = 31;
  for (tdm = 31; tdm<59; tdm++)
  ndays[1] = 28;
  for (tdm = 59; tdm<90; tdm++)
  ndays[2] = 31;
  for (tdm = 90; tdm<120; tdm++)
  ndays[3] = 30;
  for (tdm = 120; tdm<151; tdm++)
  ndays[4] = 31;
  for (tdm = 151; tdm<181; tdm++)
  ndays[5] = 30;
  for (tdm = 181; tdm<212; tdm++)
  ndays[6] = 31;
  for (tdm = 212; tdm<243; tdm++)
  ndays[7] = 31;
  for (tdm = 243; tdm<273; tdm++)
  ndays[8] = 30;
  for (tdm = 273; tdm<304; tdm++)
  ndays[9] = 31;
  for (tdm = 304; tdm<334; tdm++)
  ndays[10] = 30;
  for (tdm = 334; tdm<365; tdm++)
  ndays[11] = 31;

  lambda = lat * pi / 180.0;

  gross = 0.0;
  for (day = 0; day < ndays[dm]; day++)
  {
    ++sumday;
    sumd = 0;
    sig = -23.4856*cos(2 * pi * (sumday + 10.0)/365.25);
    sig *= pi / 180.0;

    for (hour = 0; hour < 24; hour++)
    {
      eta = (double) ((hour+1) - 12) * pi / 12.0;
      sinbeta = sin(lambda)*sin(sig) + cos(lambda)*cos(sig)*cos(eta);
      sotd = 1 - (0.016729 * cos(0.9856 * (sumday - 4.0) * pi / 180.0));
      sb = sp * sinbeta / pow(sotd,2.0);
      if (sb >= 0.0) { sumd += sb; }
    }

    gross += sumd;
  }

  gross /= (double) ndays[dm];   //assume every day are with same gross radiation, Q. Zhuang, 29/Dec/2002

  return gross;

};

/* *************************************************************
************************************************************* */

// to implement Klein, 1977 for daily solar radiation
// to implement elevation dependent Antonic approach later
// need to further check it out
double Potsclm::xgirr_new(const double& lat, const int& dm)
{

  const double sp = 1354.0;  // solar constant with unit Wm-2
  double gross;
  double delta;
  int juliadays;
  double rule;
  double tt;
  // calculate the solar declination angle
  juliadays = dm ; // time step (dm) is a day, dm + 1 is julian days from 1 to 365
  delta = 23.45 * sin (360.0 * (284.0 + juliadays) / 365.0);
  tt =  - tan(lat) * tan(delta);
  if ( fabs (tt) >= 1.0) tt = 0.9;
  // calculate sunrise-sunset hour angle (degrees) Keith and Kreider, 1978)
  rule = acosl( tt);
  // daily solar radiation
  gross = sp * 458.37 * (1 + 0.33 * cos (360.0 * juliadays / 365.0)) *
           (cos(lat) * cos (delta) * sin (rule) + (rule / 57.296) * sin (lat) * sin (delta));

  return gross;

};

/* *************************************************************
************************************************************* */

/* *************************************************************
************************************************************* */

double Potsclm::xnirr(const double& clds, const double& girr)
{

  double nirr;

  if (clds >= 0.0)
  {
    nirr = girr * (0.251 + (0.509*(1.0 - clds/100.0)));
  }
  else { nirr = MISSING; }

  return nirr;

};

/* *************************************************************
************************************************************* */


/* *************************************************************
************************************************************* */

double Potsclm::xpar(const double& clds, const double& nirr)
{

  double par;

  if (clds >= 0.0)
  {
      par = nirr * ((0.2 * clds / 100.0) + 0.45);
  }
  else { par = MISSING; }

  return par;

};


