/*********************************************************
**********************************************************
waterthermal.cpp
Object describing thermal transport in water, specifically
for wetlands, rivers and lakes. Similar to method of Zeli Tan
2015 JAMES paper. 
Added by L. Liu, June 27 2016
**********************************************************
*********************************************************/
#if !defined(WATERTHERMAL_H)
  #include "waterthermal.hpp"
#endif


void WATERTHERMAL::Wthermalmain(double wdepth,double I0, double wind, double lat, double Ta, double Ts, double prec, double vaporp, double cloud)
{
     preset(wdepth);
// vaporp: mb, cloud, percentage
     double x1 = 0.0; //from t1
     double x2 = 86400.0; //to t2
     double eps = 0.1; //accuracy
     double h1 = 300.0; //first time step
     double hmin = 60.0; //minimum time step
     double Kss, temp, tmp;
     int ii;
     double vp, sw,lw;
     vp = vaporp;
     sw = I0;
     lw = wm.CalcThermalRadiation(Ta, vp, cloud/100.0);
     CalcIncidentSolarRadiation(I0,Ia,wdepth);
     CalcKh(wm.Twater, wm.Zw, wind, lat, Kh);
     CalcTopBottomHeatFlux(wm.Twater,Ta, Ts, vaporp, wind, cloud, prec);
     sed_topflux = btmflux;
//     for(ii=0;ii<NWLAYER;ii++){
//       printf("outside 10000*Kh[%i]=%f,\n",ii,10000*Kh[ii]);
//     }
     //daytime
     odeint(wm.Twater, NWLAYER, x1, x2/2.0, eps, h1, hmin);
     for(ii=0;ii<NWLAYER;ii++){
       Ia[ii]=0.0;
     }
     //nighttime
     odeint(wm.Twater, NWLAYER, x2/2.0, x2, eps, h1, hmin);


}

void WATERTHERMAL::preset(double wdepth)
{
     int i;
     double dz;
     dz = wdepth / double(NWLAYER);
     for(i=0;i<NWLAYER;i++){
       wm.Zw[i] = (i+1.0)*dz;
       Cvt[i] =  wm.Roul*wm.Cpl;
       wm.Az[i] = 1.0;
       Kh[i] = 0.0;
       Ia[i] = 0.0;
     }
}

void WATERTHERMAL::CalcIncidentSolarRadiation(double I0, double I[],double wdepth)
{
     double Hw = 0.0,yita,Ires, Ipt1, Ipt2, solar;
     int ii;
//considering no snow
      solar = (1-0.1)*I0;
      Ipt1 = solar*(1-0.4);
      Ipt2 = solar*(0.4);
      yita = 1.1925*pow(wdepth/100.0,-0.424);
      Ires = Ipt1;
      for(ii=0;ii<NWLAYER;ii++){
        if(Ires > wm.e8){
          I[ii] = Ipt1*exp(-yita*Hw);
          Ires = I[ii];
          Hw = Hw + wm.Zw[ii+1] -wm.Zw[ii];
        }
        else{
          Ires = 0.0;
          I[ii] = 0.0;
        }
      }
      I[0] = I[0] + Ipt2;
}

void WATERTHERMAL::CalcKh(double temp[],double depth[],double wind, double lat,double Kh[])
{
     double De[NWLAYER],Dm[NWLAYER];
     double density[NWLAYER]; //total heat diffusivity (m2/s)
     double frequency[NWLAYER]; 
     int ii;
     wm.CalcEddyDiffusivity(temp,depth,wind,lat*wm.Pi/180.0,De,density,frequency);
     CalcHeatConductivity(temp,Dm);
     for(ii=0;ii<NWLAYER;ii++){
       if(ii < NWLAYER-1) {
         Kh[ii]=De[ii]+Dm[ii]/Cvt[ii]; 
       }
       else{
         Kh[ii]=Dm[ii]/Cvt[ii];
       }
//       printf("10000*de=%f,dm=%f,10000*Kh=%f,\n",10000*De[ii],Dm[ii],10000*Kh[ii]);
     }
     wm.tmpKw[:] = Kh[:];
     
}

void WATERTHERMAL::CalcHeatConductivity(double T[],double Dm[])
{
     int ii,temp;
     for(ii=0;ii<NWLAYER;ii++){
       temp=T[ii]-wm.T0;
       if(temp < wm.e8 && temp > -wm.e8) {
         Dm[ii] = 1.0/(1.0/wm.Kw0);
       }
       else if(temp > wm.e8){
         Dm[ii] = 0.558+2.223e-3*temp-1.797e-5*pow(temp,2.0);
       }
       else{
         Dm[ii] = 1.16*(1.91 - 8.66e-3*temp + 2.97e-5*pow(temp,2.0));
       }         
     }     
}


//cloud need to be within [0,1], prec unit need to be m
void WATERTHERMAL::CalcTopBottomHeatFlux(double Twater[], double Ta, double Ts,double vaporp, double wind, double cloud,double prec) 
{
      double lw_net,lh_net,sh_net,runoff_net;
      double Ttop, Hsa;
      Ttop = wm.Twater[0];
      Hsa = wind*0.4;
      //no snow, ice
      lw_net = wm.Elw*wm.CalcThermalRadiation(Ta,vaporp,cloud/100.0)-wm.Elw*wm.Stefan*pow(Ttop,4.0);
      lh_net = wm.CalcLatentHeat(vaporp,Ttop,wind);
      sh_net = wm.CalcSensibleHeat(Ta,Ttop,wind);
      runoff_net = wm.Cpl*wm.Roul*(Ta-Ttop)*prec/86400.0; //not considering Ta<T0, llc fix for /s
      topflux = (lw_net + sh_net + lh_net + runoff_net) / Cvt[0];
   //   printf("qt=(%f+%f+%f+%f)/%f,\n",lw_net,sh_net,lh_net,runoff_net,Cvt[0]);
      btmflux = Kh[NWLAYER-1]*(Ts-wm.Twater[NWLAYER-1])/(wm.Zw[NWLAYER-1]/2.0+0.1/2.0);
}


void WATERTHERMAL::derivs(double x, double temp[], double dtemp[])
{
     double qb,qt,dT1,dT2,dZ1,dZ2;
     double a,b,rr,Iab,Hf;
     int ii,matter; 
     qb = btmflux; 
     qt = topflux; 
    // for(ii=0;ii<NWLAYER;ii++){
   //  printf("========insideequ=%f,%f,%f,%f,%f,\n",Ia[ii],m_Zw[ii],wm.Az[ii],Cvt[ii],10000*Kh[ii]);
    // printf("Twater[%i]=%f,\n",ii,temp[ii]);}
     for(ii=0;ii<NWLAYER;ii++) {
       if(ii == 0) {
         dZ1 = wm.Zw[ii+1]-wm.Zw[ii];
         Iab = (Ia[ii]*wm.Az[ii] - Ia[ii+1]*wm.Az[ii+1]) / dZ1 / wm.Az[ii] / Cvt[ii];
         a = (0.5*(Kh[ii+1]+Kh[ii])) * (0.5*(wm.Az[ii]+wm.Az[ii+1]));
         dT1 = (temp[ii+1] - temp[ii]) / dZ1;
         dtemp[ii] = (a*dT1 + qt*wm.Az[ii]) / dZ1 / wm.Az[ii] + Iab;
     //    printf("top%f,%f,%f,%f,%f,%f,\n",a,dT1,qt,Iab,dtemp[ii],temp[ii]); //llc test
       }
       else if(ii == NWLAYER-1){
         dZ1 = wm.Zw[ii] - wm.Zw[ii-1];
         Iab = (Ia[ii-1]*wm.Az[ii-1] + Ia[ii]*wm.Az[ii]) / dZ1 / wm.Az[ii] / Cvt[ii];
         b = (0.5*(Kh[ii-1]+Kh[ii])) * (0.5*(wm.Az[ii-1]+wm.Az[ii]));
         dT2 = (temp[ii] - temp[ii-1]) / dZ1;
         dtemp[ii] = (qb*wm.Az[ii] - b*dT2) / dZ1 / wm.Az[ii] + Iab;
    //     printf("bot%f,%f,%f,%f,%f,%f,\n",b,dT2,qb,Iab,dtemp[ii],temp[ii]); //llc test
       }
       else {
         dZ1 = wm.Zw[ii+1] - wm.Zw[ii];
         dZ2 = wm.Zw[ii] - wm.Zw[ii-1];
         Iab = (Ia[ii-1]*wm.Az[ii-1] - Ia[ii+1]*wm.Az[ii+1]) / (dZ1 + dZ2) / wm.Az[ii] / Cvt[ii];
         a = (0.5*(Kh[ii+1]+Kh[ii])) * (0.5*(wm.Az[ii]+wm.Az[ii+1]));
         b = (0.5*(Kh[ii-1]+Kh[ii])) * (0.5*(wm.Az[ii-1]+wm.Az[ii]));
         dT1 = (temp[ii+1] - temp[ii]) / dZ1;
         dT2 = (temp[ii] - temp[ii-1]) / dZ2;
//llc right now did not consider horizontal heat flux
   /*      if (IncorpHorizHeatFlow()){
           rr = sqrt(lake_info%area) * (lake_info%basin - m_Zw(ii)) / lake_info%basin;
           rr = max(rr, 0.1);
           Hf = Kh(NWLAYER+1) * (temp(ii) - T0) / rr;
         }
         else{
         Hf = pow(10.0,-8.0);
         }
   */
         dtemp[ii] = 2.0 * (a*dT1 - b*dT2) / (dZ1 + dZ2) / wm.Az[ii] + Iab;
       //  printf("%f,%f,%f,%f,%f,%f,%f,\n",a,b,dT1,dT2,Iab,dtemp[ii],temp[ii]); //llc test
       }
     }
     //    printf(",,\n");
}

