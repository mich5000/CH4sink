
/*********************************************************
**********************************************************
Methane dynamics -- Q. Zhuang, 19/Feb/2003

**********************************************************
*********************************************************/
class PCH4DMOXI {

	public:

/******************************************************
			public Functions
******************************************************/
    void    getecdch4oxi(ofstream& rflog1);
    void    getch4oxi(char ecd[80]);
    void    getch4oxi(ofstream& rflog1);
    void    getecdch4oxi(char ecd[80]);

    double MethaneOR(const double& omax, const double& fmc, const double& foxy, const double& fst,
              const double& fsm, const double& frx, const double& fct );
    double EffectMC(const double& ch4con, const double& km);
    void   oxygenC(const double& afp, const double& lowb );
    double EffectOXY(const double& oxyc, const double& ko);
    double EffectST(const double& soilt, const double& och4q10, const double& oxiref);
//    double EffectSM(const double& rainthrough, const double& snowmelt, const double& et, const double& soilm);
    double EffectSM(const double& mvmin, const double& mvmax, const double& mvopt, const double& soilm);
    double EffectRX(const double& ehl);
    double EffectCT(const double& icul);


/**************************************************************
			Public Variables
**************************************************************/

  double omax[35], kc[35],och4q10[35],ko[35], amax[35], afp[35];
  double mvmin[35], mvmax[35], mvopt[35];  // volumetric soil moisture (cm-3/cm-3, %)
  double oxiref[35]; // reference temperature (oC)

  double poxi_para[35][10];//llc for save paras

  double tsuborg[MAXRTIME][CYCLE][31]; // to store fresh organic carbon for methane
  double suborg[CYCLE][31]; // to store fresh organic carbon for methane

  double oxygenc[400]; // to store the oxygen concentration (every 10 mm)

  double fmct;
  double foxyt;
  double fstt;
  double fsmt;
  double frxt;
  double fctt;

  double ch4oxirate[400];  // hourly

  double dailyconsp[CYCLE][31]; // daily consumption
  double consp; // hourly integration

};
