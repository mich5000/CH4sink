#if !defined(C_H)
#define C_H
#endif

#if !defined(A_H)
  #include "A.hpp"
#endif

class CC {

      public:

      void func();

};
