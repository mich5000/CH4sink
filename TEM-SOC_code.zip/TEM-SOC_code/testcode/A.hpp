#if !defined(A_H)
#define A_H
#endif

int NSLAYER[5];
