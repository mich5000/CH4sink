#if !defined(A_H)
  #include "A.hpp"
#endif

void AA::runAA()
{
     func();
}
