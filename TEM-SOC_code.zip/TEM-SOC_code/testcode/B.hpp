#if !defined(B_H)
#define B_H
#endif

extern int NSLAYER[5];

class BB {
  void func();

}
