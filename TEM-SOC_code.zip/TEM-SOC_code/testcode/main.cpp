#include<mpi.h>
#include<stdio.h>
#include<iostream>
#include<fstream>
#include <fcntl.h>
#include<iomanip>
#include<cstdlib>
#include<cmath>
#include<ctype.h>
#include<string.h>
#include<time.h>
#include <values.h>


int main(int argc, char* argv[])
{
  double a[5][2];
  double b[5][2];
  int ii,jj;
  for(ii=0;ii<5;ii++){
    for(jj=0;jj<2;jj++){
      a[ii][jj]=double(ii);
      b[ii][jj]=double(ii+1);
    }
  }
  a[0:2][:] =  3.5;
  for(ii=0;ii<5;ii++){
    printf("%f,%f,%f\n",a[ii][0],a[ii][1], sizeof(a[:][:]));
  }

  
}
