#if !defined(B_H)
  #include "B.hpp"
#endif

void BB::func()
{
  int ii;
  for(ii=0;ii<5;ii++){
  printf("NSLAYER = %i,\n",NSLAYER[ii]);
  }
}
