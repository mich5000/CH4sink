#if !defined(C_H)
  #include "C.hpp"
#endif

void CC::func()
{
  int ii;
  for(ii=0;ii<5;ii++){
    NSLAYER[ii]=ii+1;
  }

}
