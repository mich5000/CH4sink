
/*********************************************************
**********************************************************
Methane dynamics -- Q. Zhuang, 19/Feb/2003

**********************************************************
*********************************************************/
class CH4DMPLANT {

	public:

/******************************************************
			public Functions
******************************************************/

    double CH4plR(const double& tveg, const double& froot, const double& fgrow,
                    const double& ch4con );
    double froot(const double& rootd, const double& z);
    double fgrow(const double& soilt);


/**************************************************************
			Public Variables
**************************************************************/

  double ch4plantr[200];
  double froott, fgrowt;
  double ch4pltflx[CYCLE][31];
  double tveg;
};
